# Test runner script for detailed BDD test results

Write-Host "=== Running RetrieveJourney Feature Tests ===" -ForegroundColor Green

# 1. Run with detailed console output
Write-Host "1. Running tests with detailed output..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=retrievejourney" --verbosity detailed

# 2. Generate HTML report
Write-Host "2. Generating HTML test report..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=retrievejourney" --logger "html;LogFileName=RetrieveJourney_TestResults.html"

# 3. Generate TRX report
Write-Host "3. Generating TRX test report..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=retrievejourney" --logger "trx;LogFileName=RetrieveJourney_TestResults.trx"

# 4. Run specific test categories
Write-Host "4. Running Happy Path tests..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=happy-path" --verbosity normal

Write-Host "5. Running Negative tests..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=negative" --verbosity normal

Write-Host "6. Running Validation tests..." -ForegroundColor Yellow
dotnet test checkinmanagement.BDD.csproj --filter "Category=validation" --verbosity normal

Write-Host "=== Test Results Generated ===" -ForegroundColor Green
Write-Host "Check the following files for detailed reports:" -ForegroundColor Cyan
Write-Host "- RetrieveJourney_TestResults.html (Human readable)" -ForegroundColor White
Write-Host "- RetrieveJourney_TestResults.trx (XML format)" -ForegroundColor White