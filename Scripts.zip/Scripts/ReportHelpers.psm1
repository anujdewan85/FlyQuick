# Template-based Report Generator Helper Functions

function Parse-TestResults {
    param([string]$HtmlContent)
    
    $testResults = @()
    
    # Enhanced regex to parse test results with better accuracy
    $leafDivPattern = '<div class="leaf-division">.*?<span class="(pass|fail|skip)">([^<]*)</span><span>\s*([^?]*?)??</span>.*?<span>([^<]*)</span>'
    $matches = [regex]::Matches($HtmlContent, $leafDivPattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
    
    foreach ($match in $matches) {
        $status = $match.Groups[1].Value
        $title = $match.Groups[3].Value.Trim()
        $duration = $match.Groups[4].Value.Trim()
        
        # Clean up title and extract parameters
        $cleanTitle = $title -replace '\([^)]*\)', '' -replace '?', ''
        $parameters = @{}
        
        # Extract parameters from parentheses
        if ($title -match '\((.*?)\)') {
            $paramString = $matches[1]
            $paramPairs = $paramString -split ', '
            foreach ($pair in $paramPairs) {
                if ($pair -match '(\w+): "([^"]*)"') {
                    $parameters[$matches[1]] = $matches[2]
                }
            }
        }
        
        # Categorize scenarios
        $category = "general"
        if ($cleanTitle -match "Successfully|valid PNR|retrieve journey with valid") { $category = "happy-path" }
        elseif ($cleanTitle -match "Fail|invalid|incorrect|wrong") { $category = "negative" }
        elseif ($cleanTitle -match "validation|boundary|conditions|empty|required") { $category = "validation" }
        elseif ($cleanTitle -match "case insensitive") { $category = "case-insensitive" }
        
        $testResults += @{
            Title = $cleanTitle.Trim()
            Status = $status
            Duration = $duration
            Parameters = $parameters
            Category = $category
        }
    }
    
    return $testResults
}

function Generate-ScenarioGroupHTML {
    param(
        [array]$Scenarios,
        [string]$GroupTitle,
        [string]$GroupDescription,
        [string]$IconClass,
        [string]$IconColor = "#28a745"
    )
    
    if ($Scenarios.Count -eq 0) { return "" }
    
    $scenarioItemsHtml = ""
    
    foreach ($scenario in $Scenarios) {
        $statusClass = switch ($scenario.Status) {
            "pass" { "status-passed" }
            "fail" { "status-failed" }
            "skip" { "status-skipped" }
            default { "status-passed" }
        }
        
        $statusText = switch ($scenario.Status) {
            "pass" { "Passed" }
            "fail" { "Failed" }
            "skip" { "Skipped" }
            default { "Passed" }
        }
        
        # Generate parameter data items
        $parameterHtml = ""
        foreach ($param in $scenario.Parameters.GetEnumerator()) {
            $parameterHtml += @"
                                <div class="data-item">
                                    <div class="data-label">$($param.Key)</div>
                                    <div class="data-value">$($param.Value)</div>
                                </div>
"@
        }
        
        # Generate appropriate tags
        $tags = @($scenario.Category, "api", "retrievejourney")
        $tagHtml = ""
        foreach ($tag in $tags) {
            $tagClass = if (@("happy-path", "negative", "validation", "api") -contains $tag) { "tag $tag" } else { "tag" }
            $tagHtml += "                                <span class=`"$tagClass`">$tag</span>`n"
        }
        
        # Generate steps (simplified for now)
        $stepsHtml = @"
                            <div class="steps">
                                <div class="step">
                                    <span class="step-keyword">Given</span>the flight check-in service is available
                                </div>
                                <div class="step">
                                    <span class="step-keyword">When</span>I call the retrieve journey endpoint
                                </div>
                                <div class="step">
                                    <span class="step-keyword">Then</span>the response should be validated
                                </div>
                            </div>
"@
        
        $scenarioItemsHtml += @"
                    <div class="scenario-item">
                        <div class="scenario-header">
                            <div class="scenario-title">$($scenario.Title)</div>
                            <div class="scenario-status">
                                <span class="status-badge $statusClass">$statusText</span>
                                <span class="scenario-duration">$($scenario.Duration)</span>
                            </div>
                        </div>
                        <div class="scenario-details">
                            <div class="test-data">
                                $parameterHtml
                            </div>
                            $stepsHtml
                            <div class="tags">
                                $tagHtml
                            </div>
                        </div>
                    </div>
"@
    }
    
    return @"
            <div class="scenario-group">
                <div class="scenario-group-header collapsible">
                    <div class="scenario-group-title">
                        <i class="$IconClass" style="color: $IconColor;"></i> $GroupTitle
                    </div>
                    <div class="scenario-group-description">
                        $GroupDescription
                    </div>
                </div>
                <div class="scenario-list content">
                    $scenarioItemsHtml
                </div>
            </div>
"@
}

function Update-TemplateWithResults {
    param(
        [string]$Template,
        [hashtable]$Statistics,
        [array]$TestResults
    )
    
    # Update statistics
    $updatedTemplate = $Template
    $updatedTemplate = $updatedTemplate -replace '<div class="stat-number total">\d+</div>', "<div class=`"stat-number total`">$($Statistics.Total)</div>"
    $updatedTemplate = $updatedTemplate -replace '<div class="stat-number passed">\d+</div>', "<div class=`"stat-number passed`">$($Statistics.Passed)</div>"
    $updatedTemplate = $updatedTemplate -replace '<div class="stat-number failed">\d+</div>', "<div class=`"stat-number failed`">$($Statistics.Failed)</div>"
    $updatedTemplate = $updatedTemplate -replace '<div class="stat-number">\d+%</div>', "<div class=`"stat-number`">$($Statistics.SuccessRate)</div>"
    
    # Group scenarios by category
    $happyPathScenarios = $TestResults | Where-Object { $_.Category -eq "happy-path" }
    $negativeScenarios = $TestResults | Where-Object { $_.Category -eq "negative" }
    $validationScenarios = $TestResults | Where-Object { $_.Category -eq "validation" }
    $caseInsensitiveScenarios = $TestResults | Where-Object { $_.Category -eq "case-insensitive" }
    
    # Generate scenario group HTML
    $allScenariosHtml = ""
    $allScenariosHtml += Generate-ScenarioGroupHTML $happyPathScenarios "Happy Path Scenarios" "Successful journey retrieval with valid inputs" "fas fa-check-circle" "#28a745"
    $allScenariosHtml += Generate-ScenarioGroupHTML $negativeScenarios "Negative Test Scenarios" "Error handling and validation scenarios" "fas fa-exclamation-triangle" "#ffc107"
    $allScenariosHtml += Generate-ScenarioGroupHTML $validationScenarios "Validation Scenarios" "Input validation and boundary testing" "fas fa-shield-alt" "#28a745"
    $allScenariosHtml += Generate-ScenarioGroupHTML $caseInsensitiveScenarios "Case Insensitive Scenarios" "Case insensitive data handling" "fas fa-font" "#17a2b8"
    
    # Replace scenarios section
    $scenariosPattern = '(?s)<div class="scenarios">.*?</div>(?=\s*<div class="footer">)'
    $replacement = @"
<div class="scenarios">
            $allScenariosHtml
        </div>
"@
    
    $updatedTemplate = $updatedTemplate -replace $scenariosPattern, $replacement
    
    # Update timestamp
    $currentTime = Get-Date -Format "MMMM dd, yyyy 'at' HH:mm:ss"
    $updatedTemplate = $updatedTemplate -replace 'Generated on: <span id="timestamp"></span>', "Generated on: $currentTime"
    
    return $updatedTemplate
}

# Export functions for use in main script
Export-ModuleMember -Function Parse-TestResults, Generate-ScenarioGroupHTML, Update-TemplateWithResults