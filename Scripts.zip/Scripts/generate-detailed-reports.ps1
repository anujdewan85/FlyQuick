﻿# Enhanced BDD Test Report Generator with detailed Template Integration

param(
    [Parameter(Mandatory=$false)]
    [string]$FeatureFilter = "Category=retrievejourney",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDir = "TestResults\Reports",
    
    [Parameter(Mandatory=$false)]
    [switch]$OpenReport = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$GenerateAllure = $false,
    
    [Parameter(Mandatory=$false)]
    [string]$TemplatePath = "Scripts\Template\detailed-report-template.html",
    
    [Parameter(Mandatory=$false)]
    [string]$ProjectPath = ""
)

Write-Host "🚀 Flight Check-in BDD Test Report Generator" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# Import the helper functions
$helperModulePath = Join-Path $PSScriptRoot "ReportHelpers.psm1"
if (Test-Path $helperModulePath) {
    Import-Module $helperModulePath -Force
    Write-Host "📦 Imported ReportHelpers module" -ForegroundColor Green
}

# 🔍 Auto-detect project file dynamically
function Get-ProjectFile {
    param([string]$ProjectPath = "")
    
    if ($ProjectPath -and (Test-Path $ProjectPath)) {
        Write-Host "✅ Using specified project file: $ProjectPath" -ForegroundColor Green
        return $ProjectPath
    }
    
    # Method 1: Look for .csproj in current directory
    $currentDirProjects = Get-ChildItem -Path "." -Filter "*.csproj" -ErrorAction SilentlyContinue
    if ($currentDirProjects.Count -eq 1) {
        Write-Host "🎯 Found project file in current directory: $($currentDirProjects[0].Name)" -ForegroundColor Green
        return $currentDirProjects[0].Name
    }
    
    # Fallback: Use hardcoded name but warn user
    Write-Host "⚠️ Could not auto-detect project file. Using fallback: checkinmanagement.BDD.csproj" -ForegroundColor Yellow
    Write-Host "💡 You can specify the project explicitly with -ProjectPath parameter" -ForegroundColor Cyan
    return "checkinmanagement.BDD.csproj"
}

# Get the dynamic project file path
$dynamicProjectPath = Get-ProjectFile $ProjectPath
Write-Host "🚀 Using project file: $dynamicProjectPath" -ForegroundColor Cyan

# Enhanced function to parse TRX file and extract ALL test data dynamically with GROUPING
function Parse-TrxFile {
    param([string]$TrxPath)
    
    if (!(Test-Path $TrxPath)) {
        Write-Host "⚠️  TRX file not found: $TrxPath" -ForegroundColor Yellow
        return @()
    }
    
    try {
        [xml]$trxContent = Get-Content $TrxPath
        $testResults = @()
        $scenarioGroups = @{
        }
        
        # Get test definitions and results
        $testDefinitions = $trxContent.TestRun.TestDefinitions.UnitTest
        $testResults_xml = $trxContent.TestRun.Results.UnitTestResult
        
        Write-Host "📋 Found $($testResults_xml.Count) test results in TRX file" -ForegroundColor Cyan
        
        foreach ($result in $testResults_xml) {
            $testId = $result.testId
            $testDef = $testDefinitions | Where-Object { $_.id -eq $testId }
            
            if ($testDef) {
                # Extract test name and clean it up
                $testName = $testDef.name
                $displayName = $result.testName
                
                # Extract the base scenario name (without parameters)
                $baseScenarioName = $displayName
                if ($displayName -match '^(.+?)\s*\(') {
                    $baseScenarioName = $matches[1].Trim()
                }
                
                # DYNAMIC parameter extraction - no hardcoding!
                $parameters = @{
                }
                
                # Method 1: Extract from test name if it contains parentheses with parameters
                if ($testName -match '\(([^)]+)\)') {
                    $paramString = $matches[1]
                  #  Write-Host "🔍 Found parameters in test name: $paramString" -ForegroundColor Gray
                    
                    # Parse parameter key-value pairs using regex to handle the format: key: "value"
                    $paramMatches = [regex]::Matches($paramString, '(\w+):\s*"([^"]*)"')
                    
                    foreach ($match in $paramMatches) {
                        $paramName = $match.Groups[1].Value
                        $paramValue = $match.Groups[2].Value
                        
                        # Clean up parameter name and value
                        $cleanParamName = $paramName.Trim()
                        $cleanParamValue = $paramValue.Trim()
                        
                        if ($cleanParamName -and $cleanParamValue -and $cleanParamValue -ne "System.String[]") {
                            $parameters[$cleanParamName] = $cleanParamValue
                           # Write-Host "📝 Extracted parameter: $cleanParamName = $cleanParamValue" -ForegroundColor Gray
                        }
                    }
                    
                    # If regex parsing didn't work, try alternative parsing for arrays and other formats
                    if ($parameters.Count -eq 0) {
                        # Look for array parameters like: exampleTags: []
                        $arrayMatches = [regex]::Matches($paramString, '(\w+):\s*\[\]')
                        foreach ($match in $arrayMatches) {
                            $paramName = $match.Groups[1].Value.Trim()
                            $parameters[$paramName] = "[]"
                         #   Write-Host "📝 Extracted array parameter: $paramName = []" -ForegroundColor Gray
                        }
                        
                        # Look for non-quoted parameters like: statusCode: 200
                        $nonQuotedMatches = [regex]::Matches($paramString, '(\w+):\s*([^,"\[\]]+?)(?=,|\s*$)')
                        foreach ($match in $nonQuotedMatches) {
                            $paramName = $match.Groups[1].Value.Trim()
                            $paramValue = $match.Groups[2].Value.Trim()
                            
                            if ($paramName -and $paramValue -and !$parameters.ContainsKey($paramName)) {
                                $parameters[$paramName] = $paramValue
                          #      Write-Host "📝 Extracted non-quoted parameter: $paramName = $paramValue" -ForegroundColor Gray
                            }
                        }
                    }
                }
                
                # Method 2: Try to extract from display name if it contains parameter values
                if ($parameters.Count -eq 0 -and $displayName -match '\(([^)]+)\)') {
                    $displayParams = $matches[1]
                    Write-Host "🔍 Trying to parse from display name: $displayParams" -ForegroundColor Gray
                    
                    # Parse parameter key-value pairs from display name using the same regex approach
                    $paramMatches = [regex]::Matches($displayParams, '(\w+):\s*"([^"]*)"')
                    
                    foreach ($match in $paramMatches) {
                        $paramName = $match.Groups[1].Value.Trim()
                        $paramValue = $match.Groups[2].Value.Trim()
                        
                        if ($paramName -and $paramValue -and $paramValue -ne "System.String[]") {
                            $parameters[$paramName] = $paramValue
                            Write-Host "📝 Extracted from display name: $paramName = $paramValue" -ForegroundColor Gray
                        }
                    }
                    
                    # Also handle non-quoted parameters and arrays
                    if ($parameters.Count -eq 0) {
                        # Look for array parameters like: exampleTags: []
                        $arrayMatches = [regex]::Matches($displayParams, '(\w+):\s*\[\]')
                        foreach ($match in $arrayMatches) {
                            $paramName = $match.Groups[1].Value.Trim()
                            $parameters[$paramName] = "[]"
                        }
                        
                        # Look for non-quoted parameters like: statusCode: 200
                        $nonQuotedMatches = [regex]::Matches($displayParams, '(\w+):\s*([^,"\[\]]+?)(?=,|\s*$)')
                        foreach ($match in $nonQuotedMatches) {
                            $paramName = $match.Groups[1].Value.Trim()
                            $paramValue = $match.Groups[2].Value.Trim()
                            
                            if ($paramName -and $paramValue -and !$parameters.ContainsKey($paramName)) {
                                $parameters[$paramName] = $paramValue
                            }
                        }
                    }
                }
                
                # Method 3: Extract any quoted strings from the display name as potential parameters
                if ($parameters.Count -eq 0) {
                    $quotedValues = [regex]::Matches($displayName, '"([^"]*)"')
                    for ($i = 0; $i -lt $quotedValues.Count; $i++) {
                        $parameters["Data$($i + 1)"] = $quotedValues[$i].Groups[1].Value
                    }
                }
                
                # Determine category based on test name and traits - DYNAMIC!
                $category = "general"
                $traits = @()
                
                # Extract traits from test categories
                if ($testDef.TestCategory -and $testDef.TestCategory.TestCategoryItem) {
                    foreach ($categoryItem in $testDef.TestCategory.TestCategoryItem) {
                        if ($categoryItem.TestCategory) {
                            $traits += $categoryItem.TestCategory
                        }
                    }
                }
                
                # Smart category detection based on traits and names
                if ($traits -contains "happy-path" -or $displayName -match "Successfully|Success|Valid|Correct") { 
                    $category = "happy-path" 
                }
                elseif ($traits -contains "negative" -or $displayName -match "Fail|Invalid|Incorrect|Wrong|Error") { 
                    $category = "negative" 
                }
                elseif ($traits -contains "validation" -or $traits -contains "boundary-testing" -or $displayName -match "Validation|Boundary|Conditions|Empty|Required|Format") { 
                    $category = "validation" 
                }
                elseif ($traits -contains "case-insensitive" -or $displayName -match "Case.*Insensitive|case.*insensitive") { 
                    $category = "case-insensitive" 
                }
                
                # Extract duration
                $duration = if ($result.duration) {
                    $timespan = [TimeSpan]::Parse($result.duration)
                    "$([math]::Round($timespan.TotalMilliseconds))ms"
                } else { "0ms" }
                
                # Extract error information if test failed
                $errorInfo = ""
                if ($result.outcome.ToLower() -eq "failed" -and $result.Output.ErrorInfo.Message) {
                    $errorInfo = $result.Output.ErrorInfo.Message
                }
                
                # Create example object for this test execution
                $testExample = @{
                    Parameters = $parameters
                    Status = $result.outcome.ToLower()
                    Duration = $duration
                    ErrorInfo = $errorInfo
                    FullTestName = $displayName
                }
                
                # Group by base scenario name
                if (-not $scenarioGroups.ContainsKey($baseScenarioName)) {
                    $scenarioGroups[$baseScenarioName] = @{
                        Title = $baseScenarioName
                        Category = $category
                        Traits = $traits
                        Examples = @()
                        OverallStatus = "passed"
                        TotalDuration = 0
                        PassedCount = 0
                        FailedCount = 0
                        SkippedCount = 0
                    }
                }
                
                # Add this example to the scenario group
                $scenarioGroups[$baseScenarioName].Examples += $testExample
                
                # Update overall statistics for the scenario group
                switch ($result.outcome.ToLower()) {
                    "passed" { $scenarioGroups[$baseScenarioName].PassedCount++ }
                    "failed" { 
                        $scenarioGroups[$baseScenarioName].FailedCount++
                        $scenarioGroups[$baseScenarioName].OverallStatus = "failed"
                    }
                    "skipped" { $scenarioGroups[$baseScenarioName].SkippedCount++ }
                }
                
                # Add duration to total
                if ($result.duration) {
                    $timespan = [TimeSpan]::Parse($result.duration)
                    $scenarioGroups[$baseScenarioName].TotalDuration += $timespan.TotalMilliseconds
                }
                
               # Write-Host "✅ Grouped test: $baseScenarioName with example ($($parameters.Count) parameters)" -ForegroundColor Green
            }
        }
        
        # Convert grouped scenarios to final result format
        foreach ($scenarioName in $scenarioGroups.Keys) {
            $group = $scenarioGroups[$scenarioName]
            
            # Calculate average duration
            $avgDuration = if ($group.Examples.Count -gt 0) {
                "$([math]::Round($group.TotalDuration / $group.Examples.Count))ms"
            } else { "0ms" }
            
            # Determine final status
            if ($group.FailedCount -gt 0) { $finalStatus = "failed" }
            elseif ($group.SkippedCount -eq $group.Examples.Count) { $finalStatus = "skipped" }
            else { $finalStatus = "passed" }
            
            $testResults += @{
                Title = $group.Title
                Status = $finalStatus
                Duration = $avgDuration
                Category = $group.Category
                Traits = $group.Traits
                Examples = $group.Examples
                PassedCount = $group.PassedCount
                FailedCount = $group.FailedCount
                SkippedCount = $group.SkippedCount
                TotalExamples = $group.Examples.Count
            }
        }
        
        Write-Host "📊 Successfully grouped $($testResults_xml.Count) individual tests into $($testResults.Count) scenarios" -ForegroundColor Green
        return $testResults
        
    } catch {
        Write-Host "❌ Error parsing TRX file: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Stack trace: $($_.ScriptStackTrace)" -ForegroundColor Red
        return @()
    }
}

# Enhanced function to generate scenario HTML from GROUPED test data with VISIBLE SUMMARIES
function Generate-RealScenarioHTML {
    param(
        [array]$Scenarios,
        [string]$GroupTitle,
        [string]$GroupDescription,
        [string]$IconClass,
        [string]$IconColor = "#28a745"
    )
    
    if ($Scenarios.Count -eq 0) { return "" }
    
    $scenarioItemsHtml = ""
    
    foreach ($scenario in $Scenarios) {
        $statusClass = switch ($scenario.Status) {
            "passed" { "status-passed" }
            "failed" { "status-failed" }
            "skipped" { "status-skipped" }
            default { "status-passed" }
        }
        
        $statusText = switch ($scenario.Status) {
            "passed" { "Passed" }
            "failed" { "Failed" }
            "skipped" { "Skipped" }
            default { "Passed" }
        }
        
        # Generate compact summary for title
        $compactSummary = ""
        if ($scenario.TotalExamples -gt 1) {
            $compactSummary = " ($($scenario.TotalExamples) examples"
            if ($scenario.FailedCount -gt 0) {
                $compactSummary += ", $($scenario.FailedCount) failed"
            } else {
                $compactSummary += ", all passed"
            }
            $compactSummary += ")"
        }
        
        # Generate examples section with all test data sets - ALWAYS VISIBLE
        $examplesHtml = ""
        if ($scenario.Examples -and $scenario.Examples.Count -gt 0) {
            $examplesHtml = @"
                            <div class="examples-section" style="margin: 20px 0; background: linear-gradient(135deg, #ffffff, #f8f9fa); border: 1px solid #e9ecef; border-radius: 15px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
                                <h4 style="margin: 0 0 20px 0; color: #495057; font-size: 1.2em; font-weight: 700; border-bottom: 3px solid #007bff; padding-bottom: 12px; background: linear-gradient(135deg, #007bff, #0056b3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                                    <i class="fas fa-database" style="margin-right: 10px; color: #007bff; font-size: 1.1em;"></i>Test Dataset Analysis
                                    <span style="background: linear-gradient(135deg, #28a745, #20c997); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; font-size: 0.9em; font-weight: 600; margin-left: 10px;">($($scenario.TotalExamples) test cases)</span>
                                </h4>
"@
            
            # Add enhanced quick summary cards BEFORE the table with beautiful animations
            $examplesHtml += @"
                                <div class="quick-summary" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 15px; margin-bottom: 20px;">
                                    <div style="text-align: center; background: linear-gradient(135deg, #e3f2fd, #bbdefb); padding: 15px; border-radius: 12px; border-left: 5px solid #2196f3; box-shadow: 0 4px 8px rgba(33, 150, 243, 0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='translateY(-5px) scale(1.05)'" onmouseout="this.style.transform='translateY(0) scale(1)'">
                                        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                            <i class="fas fa-list-ol" style="color: #1976d2; font-size: 1.2em; margin-right: 8px;"></i>
                                            <div style="font-size: 1.6em; font-weight: bold; color: #1976d2;">$($scenario.TotalExamples)</div>
                                        </div>
                                        <div style="font-size: 0.9em; color: #424242; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Total Examples</div>
                                    </div>
                                    <div style="text-align: center; background: linear-gradient(135deg, #e8f5e8, #c8e6c9); padding: 15px; border-radius: 12px; border-left: 5px solid #4caf50; box-shadow: 0 4px 8px rgba(76, 175, 80, 0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='translateY(-5px) scale(1.05)'" onmouseout="this.style.transform='translateY(0) scale(1)'">
                                        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                            <i class="fas fa-check-circle" style="color: #388e3c; font-size: 1.2em; margin-right: 8px;"></i>
                                            <div style="font-size: 1.6em; font-weight: bold; color: #388e3c;">$($scenario.PassedCount)</div>
                                        </div>
                                        <div style="font-size: 0.9em; color: #424242; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Passed</div>
                                    </div>
                                    <div style="text-align: center; background: linear-gradient(135deg, #ffebee, #ffcdd2); padding: 15px; border-radius: 12px; border-left: 5px solid #f44336; box-shadow: 0 4px 8px rgba(244, 67, 54, 0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='translateY(-5px) scale(1.05)'" onmouseout="this.style.transform='translateY(0) scale(1)'">
                                        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                            <i class="fas fa-times-circle" style="color: #d32f2f; font-size: 1.2em; margin-right: 8px;"></i>
                                            <div style="font-size: 1.6em; font-weight: bold; color: #d32f2f;">$($scenario.FailedCount)</div>
                                        </div>
                                        <div style="font-size: 0.9em; color: #424242; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Failed</div>
                                    </div>
                                    <div style="text-align: center; background: linear-gradient(135deg, #fff8e1, #ffecb3); padding: 15px; border-radius: 12px; border-left: 5px solid #ff9800; box-shadow: 0 4px 8px rgba(255, 152, 0, 0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='translateY(-5px) scale(1.05)'" onmouseout="this.style.transform='translateY(0) scale(1)'">
                                        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                            <i class="fas fa-pause-circle" style="color: #f57c00; font-size: 1.2em; margin-right: 8px;"></i>
                                            <div style="font-size: 1.6em; font-weight: bold; color: #f57c00;">$($scenario.SkippedCount)</div>
                                        </div>
                                        <div style="font-size: 0.9em; color: #424242; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Skipped</div>
                                    </div>
                                    <div style="text-align: center; background: linear-gradient(135deg, #f3e5f5, #e1bee7); padding: 15px; border-radius: 12px; border-left: 5px solid #9c27b0; box-shadow: 0 4px 8px rgba(156, 39, 176, 0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='translateY(-5px) scale(1.05)'" onmouseout="this.style.transform='translateY(0) scale(1)'">
                                        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                            <i class="fas fa-percentage" style="color: #7b1fa2; font-size: 1.2em; margin-right: 8px;"></i>
                                            <div style="font-size: 1.6em; font-weight: bold; color: #7b1fa2;">$([math]::Round($(if ($scenario.TotalExamples -gt 0) { ($scenario.PassedCount / $scenario.TotalExamples) * 100 } else { 0 })))%</div>
                                        </div>
                                        <div style="font-size: 0.9em; color: #424242; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Success Rate</div>
                                    </div>
                                </div>
"@
            
            # Create examples table with enhanced beautiful styling
            $examplesHtml += @"
                                <div class="examples-table" style="margin: 10px 0; overflow-x: auto; background: #fff; border-radius: 12px; border: 1px solid #dee2e6; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                    <table style="width: 100%; border-collapse: collapse; font-size: 0.95em;">
                                        <thead>
                                            <tr style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; position: sticky; top: 0; z-index: 10;">
"@
            
            # Get all unique parameter names from all examples and sort them for consistent display
            # Filter out array parameters and empty values for cleaner table display
            $allParamNames = @()
            foreach ($example in $scenario.Examples) {
                foreach ($paramName in $example.Parameters.Keys) {
                    $paramValue = $example.Parameters[$paramName]
                    # Only include parameters that are not arrays, empty, or system types
                    if ($allParamNames -notcontains $paramName -and 
                        $paramValue -ne "[]" -and 
                        $paramValue -ne "" -and 
                        $paramName -ne "exampleTags" -and
                        $paramValue -ne "System.String[]") {
                        $allParamNames += $paramName
                    }
                }
            }
            # Sort parameter names for consistent display order, with common parameters first
            $priorityOrder = @("pNR", "lastName", "email", "statusCode", "flightNumber", "origin", "destination", "errorMessage")
            $sortedParams = @()
            
            # Add priority parameters first (if they exist)
            foreach ($priority in $priorityOrder) {
                if ($allParamNames -contains $priority) {
                    $sortedParams += $priority
                }
            }
            
            # Add remaining parameters
            foreach ($param in ($allParamNames | Sort-Object)) {
                if ($sortedParams -notcontains $param) {
                    $sortedParams += $param
                }
            }
            
            $allParamNames = $sortedParams
            
            # Add header columns with enhanced styling
            foreach ($paramName in $allParamNames) {
                $displayName = switch ($paramName) {
                    "pNR" { "PNR" }
                    "statusCode" { "Status Code" }
                    "flightNumber" { "Flight #" }
                    "errorMessage" { "Error Message" }
                    "lastName" { "Last Name" }
                    "origin" { "From" }
                    "destination" { "To" }
                    default { 
                        # Convert camelCase to Title Case
                        $paramName -creplace '([a-z])([A-Z])', '$1 $2' -replace '^.', { $_.Value.ToUpper() }
                    }
                }
                $examplesHtml += "<th style='padding: 14px 10px; text-align: center; font-weight: 700; border-right: 1px solid rgba(255,255,255,0.3); text-transform: uppercase; letter-spacing: 0.5px; font-size: 0.85em;'>$displayName</th>"
            }
            $examplesHtml += "<th style='padding: 14px 10px; text-align: center; font-weight: 700; border-right: 1px solid rgba(255,255,255,0.3); text-transform: uppercase; letter-spacing: 0.5px; font-size: 0.85em;'><i class='fas fa-chart-line' style='margin-right: 5px;'></i>Result</th>"
            $examplesHtml += "<th style='padding: 14px 10px; text-align: center; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; font-size: 0.85em;'><i class='fas fa-clock' style='margin-right: 5px;'></i>Duration</th>"
            
            $examplesHtml += @"
                                            </tr>
                                        </thead>
                                        <tbody>
"@
            
            # Add data rows with enhanced beautiful styling and hover effects
            $rowIndex = 0
            foreach ($example in $scenario.Examples) {
                $rowIndex++
                $alternateRowStyle = if ($rowIndex % 2 -eq 0) { "background: #f8f9fa;" } else { "background: #ffffff;" }
                
                $rowStatusClass = switch ($example.Status) {
                    "passed" { "$alternateRowStyle border-left: 5px solid #28a745; box-shadow: inset 0 0 0 1px rgba(40, 167, 69, 0.1);" }
                    "failed" { "$alternateRowStyle border-left: 5px solid #dc3545; box-shadow: inset 0 0 0 1px rgba(220, 53, 69, 0.1);" }
                    "skipped" { "$alternateRowStyle border-left: 5px solid #ffc107; box-shadow: inset 0 0 0 1px rgba(255, 193, 7, 0.1);" }
                    default { "$alternateRowStyle border-left: 5px solid #6c757d;" }
                }
                
                $examplesHtml += "<tr style='$rowStatusClass transition: all 0.3s ease; cursor: pointer;' onmouseover='this.style.backgroundColor=`"#e3f2fd`"; this.style.transform=`"scale(1.01)`";' onmouseout='this.style.backgroundColor=`"$([regex]::Match($alternateRowStyle, "background: ([^;]+)").Groups[1].Value)`"; this.style.transform=`"scale(1)`";'>"
                
                # Add parameter values with enhanced styling
                foreach ($paramName in $allParamNames) {
                    $value = if ($example.Parameters.ContainsKey($paramName)) { 
                        $example.Parameters[$paramName] 
                    } else { 
                        "-" 
                    }
                    
                    # Clean up the value - remove extra quotes and handle empty values
                    if ($value -eq "[]" -or $value -eq "" -or $value -eq "System.String[]") {
                        $value = "-"
                    }
                    
                    # HTML escape the value
                    $value = $value -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;'
                    
                    # Special formatting for different parameter types
                    $cellStyle = "padding: 12px 10px; border-right: 1px solid #e9ecef; text-align: center; font-weight: 500;"
                    
                    if ($paramName -eq "statusCode" -or $paramName -match "status") {
                        if ($value -eq "200") {
                            $cellStyle += " color: #28a745; font-weight: 700; background: rgba(40, 167, 69, 0.1);"
                        } elseif ($value -match "^4\d\d$") {
                            $cellStyle += " color: #dc3545; font-weight: 700; background: rgba(220, 53, 69, 0.1);"
                        }
                    } elseif ($paramName -match "pNR|PNR") {
                        $cellStyle += " font-family: 'Courier New', monospace; background: #f1f3f4; font-weight: 600; letter-spacing: 1px;"
                    } elseif ($paramName -match "email") {
                        $cellStyle += " font-family: 'Courier New', monospace; color: #0066cc; font-size: 0.9em;"
                    } elseif ($paramName -match "flightNumber|flight") {
                        $cellStyle += " font-family: 'Courier New', monospace; font-weight: 600; color: #6f42c1; background: rgba(111, 66, 193, 0.1);"
                    } elseif ($paramName -match "lastName|name") {
                        $cellStyle += " font-weight: 600; color: #495057;"
                    } elseif ($paramName -match "errorMessage|error") {
                        $cellStyle += " font-style: italic; color: #dc3545; font-size: 0.9em; text-align: left; max-width: 200px; word-wrap: break-word;"
                    }
                    
                    $examplesHtml += "<td style='$cellStyle'>$value</td>"
                }
                
                # Add status with enhanced icons and styling
                $statusIcon = switch ($example.Status) {
                    "passed" { "✅" }
                    "failed" { "❌" }
                    "skipped" { "⏭️" }
                    default { "ℹ️" }
                }
                
                $statusBadgeStyle = switch ($example.Status) {
                    "passed" { "background: linear-gradient(135deg, #28a745, #20c997); color: white; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 2px 4px rgba(40, 167, 69, 0.3);" }
                    "failed" { "background: linear-gradient(135deg, #dc3545, #e74c3c); color: white; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3);" }
                    "skipped" { "background: linear-gradient(135deg, #ffc107, #ffca28); color: #212529; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; box-shadow: 0 2px 4px rgba(255, 193, 7, 0.3);" }
                    default { "background: linear-gradient(135deg, #6c757d, #5a6268); color: white; padding: 6px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;" }
                }
                
                $examplesHtml += "<td style='padding: 12px 10px; text-align: center; border-right: 1px solid #e9ecef;'><span style='$statusBadgeStyle'>$statusIcon $($example.Status)</span></td>"
                $examplesHtml += "<td style='padding: 12px 10px; text-align: center; font-family: `"Courier New`", monospace; font-weight: 600; color: #495057; background: #f8f9fa; border-radius: 8px; margin: 2px;'>$($example.Duration)</td>"
                $examplesHtml += "</tr>"
                
                # Add error row if failed with enhanced styling
                if ($example.Status -eq "failed" -and $example.ErrorInfo) {
                    $errorInfo = $example.ErrorInfo -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;'
                    $examplesHtml += @"
                        <tr style='background: linear-gradient(90deg, #fff5f5, #ffebee);'>
                            <td colspan='$($allParamNames.Count + 2)' style='padding: 15px 12px; color: #721c24; font-style: italic; border-bottom: 1px solid #f5c6cb; border-left: 5px solid #dc3545; border-radius: 0 8px 8px 0; background: linear-gradient(135deg, #f8d7da, #f5c6cb);'>
                                <div style='display: flex; align-items: center; gap: 10px;'>
                                    <i class='fas fa-exclamation-triangle' style='color: #dc3545; font-size: 1.2em;'></i>
                                    <div>
                                        <strong style='color: #721c24;'>Error Details:</strong>
                                        <div style='margin-top: 5px; font-family: monospace; background: #fff; padding: 8px; border-radius: 4px; border: 1px solid #f5c6cb;'>$errorInfo</div>
                                    </div>
                                </div>
                            </td>
                        </tr>
"@
                }
            }
            
            $examplesHtml += @"
                                        </tbody>
                                    </table>
                                </div>
                            </div>
"@
        } else {
            # Fallback for scenarios without examples
            $examplesHtml = @"
                            <div class="examples-section" style="margin: 15px 0; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px;">
                                <div style="text-align: center; color: #6c757d;">
                                    <i class="fas fa-info-circle" style="font-size: 2em; margin-bottom: 10px;"></i>
                                    <div style="font-weight: 600;">Parameterless Test</div>
                                    <div style="font-size: 0.9em;">This scenario doesn't use test examples</div>
                                </div>
                            </div>
"@
        }
        
        # Generate tags dynamically from traits and category
        $tags = @($scenario.Category)
        if ($scenario.Traits -and $scenario.Traits.Count -gt 0) {
            $tags += $scenario.Traits
        }
        $tags += "api"  # Generic tag
        
        $tagHtml = ""
        foreach ($tag in $tags) {
            $tagStyle = switch ($tag) {
                "happy-path" { "background: linear-gradient(135deg, #28a745, #20c997); color: white;" }
                "negative" { "background: linear-gradient(135deg, #dc3545, #e74c3c); color: white;" }
                "validation" { "background: linear-gradient(135deg, #007bff, #0056b3); color: white;" }
                "api" { "background: linear-gradient(135deg, #6f42c1, #563d7c); color: white;" }
                "case-insensitive" { "background: linear-gradient(135deg, #17a2b8, #138496); color: white;" }
                "boundary-testing" { "background: linear-gradient(135deg, #fd7e14, #e55a00); color: white;" }
                default { "background: linear-gradient(135deg, #6c757d, #5a6268); color: white;" }
            }
            $tagHtml += "                                <span style='$tagStyle padding: 4px 12px; border-radius: 16px; font-size: 0.8em; font-weight: 500; margin: 2px; display: inline-block;'>$tag</span>`n"
        }
        
        # Generate realistic steps based on test category and first example parameters
        $firstExampleParams = if ($scenario.Examples -and $scenario.Examples.Count -gt 0) { 
            $scenario.Examples[0].Parameters 
        } else { 
            @{} 
        }
        $stepsHtml = Generate-DynamicStepsForCategory $scenario.Category $firstExampleParams $scenario.Title
        
        $scenarioItemsHtml += @"
                    <div class="scenario-item" style="margin: 25px 0; background: linear-gradient(135deg, #ffffff, #f8f9fa); border: 1px solid #e9ecef; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); overflow: hidden; transition: all 0.3s ease;" onmouseover="this.style.boxShadow='0 12px 35px rgba(0,0,0,0.12)'; this.style.transform='translateY(-2px)';" onmouseout="this.style.boxShadow='0 8px 25px rgba(0,0,0,0.08)'; this.style.transform='translateY(0)';">
                        <div class="scenario-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 25px; border-bottom: 1px solid #dee2e6; position: relative; overflow: hidden; cursor: pointer;" onclick="toggleScenario(this)">
                            <div style="position: absolute; top: -50%; right: -20%; width: 200px; height: 200px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%); border-radius: 50%;"></div>
                            <div style="display: flex; justify-content: space-between; align-items: center; position: relative; z-index: 2;">
                                <div class="scenario-title" style="flex: 1; font-size: 1.3em; font-weight: 700; color: white; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">
                                    <i class="fas fa-play-circle" style="margin-right: 12px; color: #4facfe;"></i>$($scenario.Title)$compactSummary
                                </div>
                                <div class="scenario-status" style="display: flex; align-items: center; gap: 15px;">
                                    <span class="status-badge $statusClass" style="padding: 8px 18px; border-radius: 25px; font-weight: 700; text-transform: uppercase; font-size: 0.9em; box-shadow: 0 4px 8px rgba(0,0,0,0.2); border: 2px solid rgba(255,255,255,0.3);">$statusText</span>
                                    <span class="scenario-duration" style="background: rgba(255,255,255,0.2); padding: 8px 14px; border-radius: 20px; font-family: 'Courier New', monospace; font-weight: 600; color: white; backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.3);">⏱️ $($scenario.Duration) avg</span>
                                    <i class="fas fa-chevron-down collapse-icon" style="font-size: 1.2em; color: rgba(255,255,255,0.8); transition: transform 0.3s ease; margin-left: 10px;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="scenario-details" style="padding: 0; max-height: 0; overflow: hidden; transition: max-height 0.4s ease-out, padding 0.3s ease;">
                            <div class="scenario-content" style="padding: 0;">
                                $examplesHtml
                                <div style="padding: 20px;">
                                    $stepsHtml
                                    <div class="tags" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #e9ecef;">
                                        <div style="font-weight: 600; margin-bottom: 8px; color: #495057;">Tags:</div>
                                        $tagHtml
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
"@
    }
    
    return @"
            <div class="scenario-group" style="margin: 40px 0; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); background: linear-gradient(135deg, #ffffff, #f8f9fa);">
                <div class="scenario-group-header" style="background: linear-gradient(135deg, $IconColor, $(if ($IconColor -eq '#28a745') { '#20c997' } elseif ($IconColor -eq '#ffc107') { '#fd7e14' } elseif ($IconColor -eq '#17a2b8') { '#6f42c1' } else { '#007bff' })); color: white; padding: 30px; margin-bottom: 0; position: relative; overflow: hidden;">
                    <div style="position: absolute; top: -100px; right: -100px; width: 300px; height: 300px; background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%); border-radius: 50%;"></div>
                    <div style="position: absolute; bottom: -50px; left: -50px; width: 200px; height: 200px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%); border-radius: 50%;"></div>
                    <div style="display: flex; justify-content: space-between; align-items: center; position: relative; z-index: 2;">
                        <div>
                            <div class="scenario-group-title" style="font-size: 1.8em; font-weight: 800; margin-bottom: 12px; text-shadow: 0 2px 8px rgba(0,0,0,0.3); letter-spacing: 0.5px;">
                                <i class="$IconClass" style="margin-right: 15px; font-size: 1.2em; text-shadow: 0 2px 4px rgba(0,0,0,0.4);"></i> $GroupTitle
                            </div>
                            <div class="scenario-group-description" style="opacity: 0.95; font-size: 1.1em; font-weight: 500; text-shadow: 0 1px 3px rgba(0,0,0,0.2);">
                                🎯 $GroupDescription ($($Scenarios.Count) scenarios with dynamic test data)
                            </div>
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button onclick="expandAllScenarios(this)" style="background: rgba(255,255,255,0.2); color: white; border: 2px solid rgba(255,255,255,0.3); padding: 8px 16px; border-radius: 20px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; backdrop-filter: blur(10px);" onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">
                                <i class="fas fa-expand-alt" style="margin-right: 8px;"></i>Expand All
                            </button>
                            <button onclick="collapseAllScenarios(this)" style="background: rgba(255,255,255,0.2); color: white; border: 2px solid rgba(255,255,255,0.3); padding: 8px 16px; border-radius: 20px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; backdrop-filter: blur(10px);" onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">
                                <i class="fas fa-compress-alt" style="margin-right: 8px;"></i>Collapse All
                            </button>
                        </div>
                    </div>
                </div>
                <div class="scenario-list" style="background: linear-gradient(135deg, #ffffff, #f8f9fa); padding: 30px; border-radius: 0 0 20px 20px;">
                    $scenarioItemsHtml
                </div>
            </div>
"@
}

# Enhanced function to generate BDD steps dynamically based on actual test data
function Generate-DynamicStepsForCategory {
    param(
        [string]$Category,
        [hashtable]$Parameters,
        [string]$TestTitle
    )
    
    # Extract key information from parameters dynamically
    $paramValues = @()
    foreach ($param in $Parameters.GetEnumerator()) {
        $paramValues += "$($param.Key): $($param.Value)"
    }
    
    switch ($Category) {
        "happy-path" {
            $stepHtml = @"
                            <div class="steps">
                                <div class="step">
                                    <span class="step-keyword">Given</span>the system is available and ready
                                </div>
"@
            
            # Add parameter-specific steps
            foreach ($param in $Parameters.GetEnumerator()) {
                $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">And</span>I have $($param.Key.ToLower()) "$($param.Value)"
                                </div>
"@
            }
            
            $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">When</span>I execute the test scenario
                                </div>
                                <div class="step">
                                    <span class="step-keyword">Then</span>the result should be successful
                                </div>
                                <div class="step">
                                    <span class="step-keyword">And</span>all validations should pass
                                </div>
                            </div>
"@
            return $stepHtml
        }
        
        "negative" {
            $stepHtml = @"
                            <div class="steps">
                                <div class="step">
                                    <span class="step-keyword">Given</span>the system is available and ready
                                </div>
"@
            
            # Add parameter-specific steps
            foreach ($param in $Parameters.GetEnumerator()) {
                $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">And</span>I provide $($param.Key.ToLower()) "$($param.Value)"
                                </div>
"@
            }
            
            $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">When</span>I execute the test scenario
                                </div>
                                <div class="step">
                                    <span class="step-keyword">Then</span>the system should handle the error appropriately
                                </div>
                                <div class="step">
                                    <span class="step-keyword">And</span>proper error response should be returned
                                </div>
                            </div>
"@
            return $stepHtml
        }
        
        "validation" {
            $stepHtml = @"
                            <div class="steps">
                                <div class="step">
                                    <span class="step-keyword">Given</span>the validation rules are in place
                                </div>
"@
            
            # Add parameter-specific steps
            foreach ($param in $Parameters.GetEnumerator()) {
                $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">And</span>I input $($param.Key.ToLower()) as "$($param.Value)"
                                </div>
"@
            }
            
            $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">When</span>validation is performed
                                </div>
                                <div class="step">
                                    <span class="step-keyword">Then</span>the validation result should be as expected
                                </div>
                            </div>
"@
            return $stepHtml
        }
        
        default {
            $stepHtml = @"
                            <div class="steps">
                                <div class="step">
                                    <span class="step-keyword">Given</span>the test environment is prepared
                                </div>
"@
            
            # Add all parameters as steps
            if ($Parameters.Count -gt 0) {
                foreach ($param in $Parameters.GetEnumerator()) {
                    $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">And</span>parameter $($param.Key) is set to "$($param.Value)"
                                </div>
"@
                }
            }
            
            $stepHtml += @"
                                <div class="step">
                                    <span class="step-keyword">When</span>the test is executed
                                </div>
                                <div class="step">
                                    <span class="step-keyword">Then</span>the expected outcome is achieved
                                </div>
                            </div>
"@
            return $stepHtml
        }
    }
}

# Create reports directory following .NET test convention
if (!(Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    Write-Host "📁 Created reports directory: $OutputDir" -ForegroundColor Green
}

$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$reportBaseName = "FlightCheckin_TestReport_$timestamp"

Write-Host "🧪 Running BDD tests with detailed reporting..." -ForegroundColor Yellow

# Generate full paths for reports in TestResults/Reports directory (PowerShell 5.x compatible)
$fullOutputDir = $null
try {
    $resolvedPath = Resolve-Path $OutputDir -ErrorAction SilentlyContinue
    if ($resolvedPath) {
        $fullOutputDir = $resolvedPath.Path
    }
} catch {
    # Directory doesn't exist, will create below
}

if (-not $fullOutputDir) {
    # If directory doesn't exist yet, create it and resolve
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    $fullOutputDir = (Resolve-Path $OutputDir).Path
}

$basicReportPath = "$fullOutputDir\$reportBaseName.html"
$trxReportPath = "$fullOutputDir\$reportBaseName.trx"
$customReportPath = "$fullOutputDir\$reportBaseName`_detailed.html"

Write-Host "📁 All reports will be generated in: $fullOutputDir" -ForegroundColor Green

# 1. Generate base reports in TestResults/Reports directory
Write-Host "📄 Generating TRX report..." -ForegroundColor Yellow  
dotnet test $dynamicProjectPath --filter $FeatureFilter --logger "trx;LogFileName=$trxReportPath" --verbosity normal | Out-Null

Write-Host "📊 Generating HTML report..." -ForegroundColor Yellow
$testResult = dotnet test $dynamicProjectPath --filter $FeatureFilter --logger "html;LogFileName=$basicReportPath" --verbosity normal 2>&1

# The HTML logger might still create reports in the default location, so check and handle
if (!(Test-Path $basicReportPath)) {
    Write-Host "⚠️  HTML report not found at expected location. Checking default TestResults location..." -ForegroundColor Yellow
    
    # Look for reports in the default TestResults\Reports location
    $defaultReportLocations = @("TestResults\Reports", "TestResults")
    foreach ($location in $defaultReportLocations) {
        if (Test-Path $location) {
            $latestHtmlFile = Get-ChildItem -Path $location -Filter "*.html" -Recurse | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($latestHtmlFile) {
                Write-Host "📋 Found HTML report at: $($latestHtmlFile.FullName)" -ForegroundColor Yellow
                Copy-Item $latestHtmlFile.FullName $basicReportPath -Force
                Write-Host "✅ Moved HTML report to: $basicReportPath" -ForegroundColor Green
                break
            }
        }
    }
}

# 2. Parse test output for quick stats
$totalTests = 0
$passedTests = 0
$failedTests = 0
$successRate = "100%"

# Extract basic stats from console output
$testOutput = $testResult | Out-String
if ($testOutput -match "Passed:\s*(\d+)") { $passedTests = [int]$matches[1] }
if ($testOutput -match "Failed:\s*(\d+)") { $failedTests = [int]$matches[1] }
if ($testOutput -match "Total:\s*(\d+)") { $totalTests = [int]$matches[1] }

if ($totalTests -eq 0) {
    # Fallback: count from HTML if available
    if (Test-Path $basicReportPath) {
        $basicContent = Get-Content $basicReportPath -Raw
        if ($basicContent -match '<div class="total-tests">(\d+)</div>') { $totalTests = [int]$matches[1] }
        if ($basicContent -match '<span class="passedTests">(\d+)</span>') { $passedTests = [int]$matches[1] }
        if ($basicContent -match '<span class="failedTests">(\d+)</span>') { $failedTests = [int]$matches[1] }
    }
}

if ($totalTests -gt 0 -and $failedTests -eq 0) {
    $successRate = "100%"
} elseif ($totalTests -gt 0) {
    $successRate = "$([math]::Round(($passedTests / $totalTests) * 100))%"
}

# 3. Parse TRX file to get real test data with DYNAMIC extraction
Write-Host "📋 Parsing TRX file for detailed test results with dynamic parameter extraction..." -ForegroundColor Magenta
$realTestResults = Parse-TrxFile $trxReportPath

Write-Host "📊 Found $($realTestResults.Count) detailed test results with dynamic content" -ForegroundColor Cyan

# 4. Generate detailed report using template with DYNAMIC real data
Write-Host "🎨 Generating detailed report..." -ForegroundColor Magenta

if (Test-Path $TemplatePath) {
    Write-Host "📋 Using template: $TemplatePath" -ForegroundColor Green
    $template = Get-Content $TemplatePath -Raw
    
    # Update statistics in template
    $enhancedReport = $template
    $enhancedReport = $enhancedReport -replace '<div class="stat-number total">\d+</div>', "<div class=`"stat-number total`">$totalTests</div>"
    $enhancedReport = $enhancedReport -replace '<div class="stat-number passed">\d+</div>', "<div class=`"stat-number passed`">$passedTests</div>"
    $enhancedReport = $enhancedReport -replace '<div class="stat-number failed">\d+</div>', "<div class=`"stat-number failed`">$failedTests</div>"
    $enhancedReport = $enhancedReport -replace '<div class="stat-number">100%</div>', "<div class=`"stat-number`">$successRate</div>"
    
    # Update timestamp in footer
    $currentTime = Get-Date -Format "MMMM dd, yyyy 'at' HH:mm:ss"
    $enhancedReport = $enhancedReport -replace 'Generated on: <span id="timestamp"></span>', "Generated on: $currentTime"
    
    # Add JavaScript for collapsible functionality before closing </body> tag
    $javascriptCode = @"
        <script>
            function toggleScenario(header) {
                const details = header.nextElementSibling;
                const icon = header.querySelector('.collapse-icon');
                const content = details.querySelector('.scenario-content');
                
                if (details.style.maxHeight === '0px' || details.style.maxHeight === '') {
                    // Expand
                    details.style.maxHeight = content.scrollHeight + 'px';
                    details.style.padding = '0';
                    icon.style.transform = 'rotate(180deg)';
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                } else {
                    // Collapse
                    details.style.maxHeight = '0px';
                    details.style.padding = '0';
                    icon.style.transform = 'rotate(0deg)';
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                }
            }
            
            function expandAllScenarios(button) {
                const scenarioGroup = button.closest('.scenario-group');
                const scenarios = scenarioGroup.querySelectorAll('.scenario-item');
                
                scenarios.forEach(scenario => {
                    const header = scenario.querySelector('.scenario-header');
                    const details = scenario.querySelector('.scenario-details');
                    const icon = header.querySelector('.collapse-icon');
                    const content = details.querySelector('.scenario-content');
                    
                    details.style.maxHeight = content.scrollHeight + 'px';
                    details.style.padding = '0';
                    icon.style.transform = 'rotate(180deg)';
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                });
            }
            
            function collapseAllScenarios(button) {
                const scenarioGroup = button.closest('.scenario-group');
                const scenarios = scenarioGroup.querySelectorAll('.scenario-item');
                
                scenarios.forEach(scenario => {
                    const header = scenario.querySelector('.scenario-header');
                    const details = scenario.querySelector('.scenario-details');
                    const icon = header.querySelector('.collapse-icon');
                    
                    details.style.maxHeight = '0px';
                    details.style.padding = '0';
                    icon.style.transform = 'rotate(0deg)';
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                });
            }
            
            // Initialize all scenarios as collapsed on page load
            document.addEventListener('DOMContentLoaded', function() {
                const allScenarios = document.querySelectorAll('.scenario-item');
                allScenarios.forEach(scenario => {
                    const details = scenario.querySelector('.scenario-details');
                    const icon = scenario.querySelector('.collapse-icon');
                    
                    details.style.maxHeight = '0px';
                    details.style.padding = '0';
                    icon.style.transform = 'rotate(0deg)';
                });
            });
        </script>
    </body>
"@
    
    # Replace the closing body tag with our JavaScript
    $enhancedReport = $enhancedReport -replace '</body>', $javascriptCode
    
    # Group real test results by category DYNAMICALLY and generate HTML
    if ($realTestResults.Count -gt 0) {
        # Get all unique categories dynamically
        $allCategories = $realTestResults | ForEach-Object { $_.Category } | Select-Object -Unique
        
     #   Write-Host "📊 Found categories: $($allCategories -join ', ')" -ForegroundColor Cyan
        
        # Generate scenario group HTML with real data for each category
        $allScenariosHtml = ""
        
        foreach ($category in $allCategories) {
            $categoryScenarios = $realTestResults | Where-Object { $_.Category -eq $category }
            $categoryCount = $categoryScenarios.Count
            
            if ($categoryCount -gt 0) {
                $categoryTitle = ""
                $categoryDescription = ""
                $iconClass = ""
                $iconColor = ""
                
                switch ($category) {
                    "happy-path" {
                        $categoryTitle = "Happy Path Scenarios"
                        $categoryDescription = "Successful scenarios with valid inputs"
                        $iconClass = "fas fa-check-circle"
                        $iconColor = "#bee7c7ff"
                    }
                    "negative" {
                        $categoryTitle = "Negative Test Scenarios"
                        $categoryDescription = "Error handling and edge case scenarios"
                        $iconClass = "fas fa-exclamation-triangle"
                        $iconColor = "#ffc107"
                    }
                    "validation" {
                        $categoryTitle = "Validation Scenarios"
                        $categoryDescription = "Input validation and boundary testing"
                        $iconClass = "fas fa-shield-alt"
                        $iconColor = "#28a745"
                    }
                    "case-insensitive" {
                        $categoryTitle = "Case Insensitive Scenarios"
                        $categoryDescription = "Case insensitive data handling tests"
                        $iconClass = "fas fa-font"
                        $iconColor = "#17a2b8"
                    }
                    default {
                        $categoryTitle = "$($category.ToUpper()) Scenarios"
                        $categoryDescription = "Test scenarios for $category"
                        $iconClass = "fas fa-cog"
                        $iconColor = "#6c757d"
                    }
                }
                
            #    Write-Host "📋 Processing $categoryCount tests in category: $categoryTitle" -ForegroundColor Cyan
                $allScenariosHtml += Generate-RealScenarioHTML $categoryScenarios $categoryTitle $categoryDescription $iconClass $iconColor
            }
        }
        
        # Replace scenarios section with real data
        $scenariosPattern = '(?s)<div class="scenarios">.*?</div>(?=\s*<div class="footer">)'
        $replacement = @"
<div class="scenarios">
            $allScenariosHtml
        </div>
"@
        $enhancedReport = $enhancedReport -replace $scenariosPattern, $replacement
        
        # Display final category breakdown
        foreach ($category in $allCategories) {
            $count = ($realTestResults | Where-Object { $_.Category -eq $category }).Count
            Write-Host "✅ $category`: $count tests" -ForegroundColor Green
        }
    }
    
    # Update status badges based on results
    if ($failedTests -eq 0) {
        $enhancedReport = $enhancedReport -replace 'style="background: #d4edda; color: #155724;">All Passed', 'style="background: #d4edda; color: #155724;">All Passed'
    } else {
        $enhancedReport = $enhancedReport -replace 'style="background: #d4edda; color: #155724;">All Passed', 'style="background: #f8d7da; color: #721c24;">Some Failed'
    }
    
    # Write the enhanced report
    $enhancedReport | Out-File -FilePath $customReportPath -Encoding UTF8 -Force
    Write-Host "✅ Custom report generated at: $customReportPath" -ForegroundColor Green
    
} else {
    Write-Host "⚠️  Template not found at: $TemplatePath" -ForegroundColor Yellow
    Write-Host "💡 Creating dynamic report without template..." -ForegroundColor Yellow
    
    # Create a dynamic detailed report with real data
    $dynamicScenariosHtml = ""
    if ($realTestResults.Count -gt 0) {
        foreach ($test in $realTestResults) {
            $statusClass = if ($test.Status -eq "passed") { "success" } else { "error" }
            
            # Create detailed parameter display
            $paramsHtml = ""
            if ($test.Examples -and $test.Examples.Count -gt 0) {
                $paramsHtml = "<div style='margin: 10px 0;'><strong>📊 $($test.TotalExamples) examples:</strong> $($test.PassedCount) passed, $($test.FailedCount) failed</div>"
                $paramsHtml += "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 5px 0;'>"
                
                # Show first few examples
                $exampleCount = [Math]::Min(3, $test.Examples.Count)
                for ($i = 0; $i -lt $exampleCount; $i++) {
                    $example = $test.Examples[$i]
                    $exampleParams = @()
                    foreach ($param in $example.Parameters.GetEnumerator()) {
                        $exampleParams += "$($param.Key): $($param.Value)"
                    }
                    $statusIcon = if ($example.Status -eq "passed") { "✅" } else { "❌" }
                    $paramsHtml += "<div style='font-family: monospace; font-size: 0.9em; margin: 2px 0;'>$statusIcon [$($exampleParams -join ', ')] - $($example.Duration)</div>"
                }
                
                if ($test.Examples.Count -gt 3) {
                    $paramsHtml += "<div style='font-style: italic; color: #666;'>... and $($test.Examples.Count - 3) more examples</div>"
                }
                $paramsHtml += "</div>"
            }
            
            $dynamicScenariosHtml += @"
                <div class='test-item' style='margin: 15px 0; padding: 20px; background: #fff; border-left: 4px solid $(if ($test.Status -eq "passed") { "#28a745" } else { "#dc3545" }); border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'>
                    <div style='font-size: 1.1em; font-weight: bold; margin-bottom: 10px;'>$($test.Title)</div>
                    $paramsHtml
                    <div style='margin-top: 10px;'>
                        <span class='$statusClass' style='padding: 4px 12px; border-radius: 12px; font-weight: 600; text-transform: uppercase; $(if ($test.Status -eq "passed") { "background: #28a745; color: white;" } else { "background: #dc3545; color: white;" })'>$($test.Status.ToUpper())</span>
                        <span style='margin-left: 10px; font-family: monospace; background: #e9ecef; padding: 4px 8px; border-radius: 8px;'>$($test.Duration) avg</span>
                    </div>
                </div>
"@
        }
    }
    
    $fallbackReport = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flight Check-in Test Report - Dynamic</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: white; border-radius: 15px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        h1 { color: #495057; margin-bottom: 30px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat { text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px; }
        .stat-number { font-size: 2em; font-weight: bold; color: #007bff; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .test-item { padding: 15px; border-bottom: 1px solid #eee; background: #f8f9fa; margin: 5px 0; border-radius: 5px; }
        .category-header { background: #007bff; color: white; padding: 10px; margin: 20px 0 10px 0; border-radius: 5px; font-weight: bold; cursor: pointer; }
        .scenario-details { max-height: 0; overflow: hidden; transition: max-height 0.4s ease-out; }
        .collapse-icon { transition: transform 0.3s ease; }
    </style>
</head>
<body>
    <div class="container">
        <h1>✈️ Flight Check-in Test Report (Dynamic)</h1>
        <div class="stats">
            <div class="stat">
                <div class="stat-number">$totalTests</div>
                <div>Total Tests</div>
            </div>
            <div class="stat">
                <div class="stat-number success">$passedTests</div>
                <div>Passed</div>
            </div>
            <div class="stat">
                <div class="stat-number error">$failedTests</div>
                <div>Failed</div>
            </div>
            <div class="stat">
                <div class="stat-number">$successRate</div>
                <div>Success Rate</div>
            </div>
        </div>
        <h2>Dynamic Test Results:</h2>
        $dynamicScenariosHtml
        <p><strong>Generated:</strong> $(Get-Date -Format "MMMM dd, yyyy 'at' HH:mm:ss")</p>
        <p><strong>Framework:</strong> Reqnroll + XUnit + .NET 8</p>
        <p><strong>Note:</strong> This report was generated dynamically with all available test data.</p>
    </div>
    
    <script>
        function toggleScenario(header) {
            const details = header.nextElementSibling;
            const icon = header.querySelector('.collapse-icon');
            
            if (details.style.maxHeight === '0px' || details.style.maxHeight === '') {
                details.style.maxHeight = details.scrollHeight + 'px';
                if (icon) icon.style.transform = 'rotate(180deg)';
            } else {
                details.style.maxHeight = '0px';
                if (icon) icon.style.transform = 'rotate(0deg)';
            }
        }
        
        function expandAllScenarios(button) {
            const details = button.closest('.container').querySelectorAll('.scenario-details');
            const icons = button.closest('.container').querySelectorAll('.collapse-icon');
            
            details.forEach(detail => {
                detail.style.maxHeight = detail.scrollHeight + 'px';
            });
            icons.forEach(icon => {
                icon.style.transform = 'rotate(180deg)';
            });
        }
        
        function collapseAllScenarios(button) {
            const details = button.closest('.container').querySelectorAll('.scenario-details');
            const icons = button.closest('.container').querySelectorAll('.collapse-icon');
            
            details.forEach(detail => {
                detail.style.maxHeight = '0px';
            });
            icons.forEach(icon => {
                icon.style.transform = 'rotate(0deg)';
            });
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const allDetails = document.querySelectorAll('.scenario-details');
            allDetails.forEach(detail => {
                detail.style.maxHeight = '0px';
            });
        });
    </script>
</body>
</html>
"@
    $fallbackReport | Out-File -FilePath $customReportPath -Encoding UTF8 -Force
    Write-Host "✅ Dynamic fallback report with real data generated" -ForegroundColor Green
}

# 5. Generate Allure report if requested
if ($GenerateAllure) {
    Write-Host "✨ Generating Allure report..." -ForegroundColor Magenta
    
    $env:ALLURE_RESULTS_DIRECTORY = "allure-results"
    dotnet test $dynamicProjectPath --filter $FeatureFilter --logger "allure" --verbosity normal | Out-Null
    
    if (Get-Command "allure" -ErrorAction SilentlyContinue) {
        $allureOutputPath = "$fullOutputDir\allure-report"
        allure generate allure-results --clean -o $allureOutputPath 2>$null
        Write-Host "✅ Allure report generated in $allureOutputPath" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Allure CLI not found. Install with: npm install -g allure-commandline" -ForegroundColor Yellow
    }
}

# 6. Display summary
Write-Host "`n📊 Test Execution Summary" -ForegroundColor Cyan
Write-Host "=========================" -ForegroundColor Cyan
Write-Host "📋 Total Tests: $totalTests" -ForegroundColor White
Write-Host "✅ Passed: $passedTests" -ForegroundColor Green
Write-Host "❌ Failed: $failedTests" -ForegroundColor Red
Write-Host "📈 Success Rate: $successRate" -ForegroundColor White

Write-Host "`n📋 Generated Reports (All in: $OutputDir)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "📄 TRX Report: $(Split-Path $trxReportPath -Leaf)" -ForegroundColor White
Write-Host "📊 Basic HTML: $(Split-Path $basicReportPath -Leaf)" -ForegroundColor White
Write-Host "🎨 detailed Report: $(Split-Path $customReportPath -Leaf)" -ForegroundColor White

if ($GenerateAllure) {
    Write-Host "✨ Allure Report: allure-report/index.html" -ForegroundColor White
}

# 7. Open report if requested
if ($OpenReport) {
    if (Test-Path $customReportPath) {
        Write-Host "`n🌐 Opening detailed report in browser..." -ForegroundColor Green
        Start-Process $customReportPath
    } else {
        Write-Host "`n⚠️  detailed report not found, opening basic report..." -ForegroundColor Yellow
        if (Test-Path $basicReportPath) {
            Start-Process $basicReportPath
        }
    }
}

Write-Host "`n🎉 Report generation completed successfully!" -ForegroundColor Green
Write-Host "💡 Template path used: $TemplatePath" -ForegroundColor Gray
Write-Host "📁 All reports located in: $fullOutputDir" -ForegroundColor Gray