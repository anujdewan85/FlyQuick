using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace UserJourney.Infrastructure.Extensions;

/// <summary>
/// Extension methods for adding infrastructure services
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(
        this IServiceCollection services, 
        IConfiguration configuration)
    {
        // Add any infrastructure-specific services here
        // For example: HTTP clients, external service integrations, etc.
        
        // Example: Add HTTP client for external services
        services.AddHttpClient("PassengerService", client =>
        {
            var baseUrl = configuration.GetValue<string>("ExternalServices:PassengerService:BaseUrl");
            if (!string.IsNullOrEmpty(baseUrl))
            {
                client.BaseAddress = new Uri(baseUrl);
            }
        });

        services.AddHttpClient("JourneyService", client =>
        {
            var baseUrl = configuration.GetValue<string>("ExternalServices:JourneyService:BaseUrl");
            if (!string.IsNullOrEmpty(baseUrl))
            {
                client.BaseAddress = new Uri(baseUrl);
            }
        });

        return services;
    }
}
