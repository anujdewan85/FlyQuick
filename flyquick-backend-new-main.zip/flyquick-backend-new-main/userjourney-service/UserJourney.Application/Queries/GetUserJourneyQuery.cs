using FluentResults;
using MediatR;
using UserJourney.Domain.Entities;

namespace UserJourney.Application.Queries;

/// <summary>
/// Query to get user journey screens based on PNR and last name
/// </summary>
public class GetUserJourneyQuery : IRequest<Result<UserJourneyResult>>
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
}

/// <summary>
/// Response DTO for user journey
/// </summary>
public class UserJourneyDto
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
    public List<MobileScreenDto> Screens { get; init; } = new();
    public string Status { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;
    public DateTime GeneratedAt { get; init; }
}

/// <summary>
/// DTO for mobile screens
/// </summary>
public class MobileScreenDto
{
    public string ScreenId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public string Type { get; init; } = string.Empty;
    public int Order { get; init; }
    public bool IsRequired { get; init; }
    public Dictionary<string, object> Parameters { get; init; } = new();
    public List<string> Actions { get; init; } = new();
}

/// <summary>
/// Query for getting passenger information
/// </summary>
public class GetPassengerInfoQuery : IRequest<Result<Passenger>>
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
}
