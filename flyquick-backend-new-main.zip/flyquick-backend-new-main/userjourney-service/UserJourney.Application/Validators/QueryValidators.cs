using FluentValidation;
using UserJourney.Application.Queries;

namespace UserJourney.Application.Validators;

/// <summary>
/// Validator for GetUserJourneyQuery
/// </summary>
public class GetUserJourneyQueryValidator : AbstractValidator<GetUserJourneyQuery>
{
    public GetUserJourneyQueryValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 6)
            .WithMessage("PNR must be exactly 6 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("PNR must contain only uppercase letters and numbers");

        RuleFor(x => x.LastName)
            .NotEmpty()
            .WithMessage("Last name is required")
            .MinimumLength(2)
            .WithMessage("Last name must be at least 2 characters")
            .MaximumLength(50)
            .WithMessage("Last name cannot exceed 50 characters")
            .Matches("^[a-zA-Z\\s\\-']+$")
            .WithMessage("Last name can only contain letters, spaces, hyphens, and apostrophes");
    }
}

/// <summary>
/// Validator for GetPassengerInfoQuery
/// </summary>
public class GetPassengerInfoQueryValidator : AbstractValidator<GetPassengerInfoQuery>
{
    public GetPassengerInfoQueryValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 6)
            .WithMessage("PNR must be exactly 6 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("PNR must contain only uppercase letters and numbers");

        RuleFor(x => x.LastName)
            .NotEmpty()
            .WithMessage("Last name is required")
            .MinimumLength(2)
            .WithMessage("Last name must be at least 2 characters")
            .MaximumLength(50)
            .WithMessage("Last name cannot exceed 50 characters")
            .Matches("^[a-zA-Z\\s\\-']+$")
            .WithMessage("Last name can only contain letters, spaces, hyphens, and apostrophes");
    }
}
