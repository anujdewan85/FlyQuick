using Carter;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using UserJourney.Application.Queries;
using UserJourney.Domain.Exceptions;

namespace UserJourney.API.Endpoints;

/// <summary>
/// API endpoints for user journey functionality
/// </summary>
public class UserJourneyEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("api/user-journey")
            .WithTags("UserJourney")
            .WithOpenApi();

        // GET /api/user-journey/{pnr}/{lastName}
        group.MapGet("/{pnr}/{lastName}", GetUserJourney)
            .WithName("GetUserJourney")
            .WithSummary("Get mobile screens for user journey based on PNR and last name")
            .WithDescription("Returns a list of mobile screens that should be displayed to the user based on their booking and travel status")
            .Produces<UserJourneyDto>(StatusCodes.Status200OK)
            .Produces<ProblemDetails>(StatusCodes.Status400BadRequest)
            .Produces<ProblemDetails>(StatusCodes.Status404NotFound)
            .Produces<ProblemDetails>(StatusCodes.Status500InternalServerError);

        // GET /api/user-journey/passenger/{pnr}/{lastName}
        group.MapGet("/passenger/{pnr}/{lastName}", GetPassengerInfo)
            .WithName("GetPassengerInfo")
            .WithSummary("Get passenger information")
            .WithDescription("Returns passenger information for the given PNR and last name")
            .Produces<PassengerInfoDto>(StatusCodes.Status200OK)
            .Produces<ProblemDetails>(StatusCodes.Status400BadRequest)
            .Produces<ProblemDetails>(StatusCodes.Status404NotFound)
            .Produces<ProblemDetails>(StatusCodes.Status500InternalServerError);
    }

    private static async Task<IResult> GetUserJourney(
        string pnr,
        string lastName,
        IMediator mediator,
        IValidator<GetUserJourneyQuery> validator,
        ILogger<UserJourneyEndpoints> logger,
        CancellationToken cancellationToken)
    {
        var query = new GetUserJourneyQuery { Pnr = pnr.ToUpper(), LastName = lastName };
        
        // Validate the query
        var validationResult = await validator.ValidateAsync(query, cancellationToken);
        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => new { e.PropertyName, e.ErrorMessage });
            logger.LogWarning("Validation failed for GetUserJourney: {Errors}", errors);
            
            return Results.ValidationProblem(validationResult.ToDictionary());
        }

        // Execute the query
        var result = await mediator.Send(query, cancellationToken);
        
        if (result.IsFailed)
        {
            var error = result.Errors.FirstOrDefault();
            
            return error?.Metadata.ContainsKey("Exception") == true && 
                   error.Metadata["Exception"] is PassengerNotFoundException
                ? Results.NotFound(new ProblemDetails
                {
                    Title = "Passenger Not Found",
                    Detail = error.Message,
                    Status = StatusCodes.Status404NotFound,
                    Instance = $"/api/user-journey/{pnr}/{lastName}"
                })
                : Results.Problem(new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = error?.Message ?? "An unexpected error occurred",
                    Status = StatusCodes.Status500InternalServerError,
                    Instance = $"/api/user-journey/{pnr}/{lastName}"
                });
        }

        var userJourney = result.Value;
        var dto = MapToDto(userJourney);
        
        logger.LogInformation("Successfully returned user journey with {ScreenCount} screens for PNR: {Pnr}", 
            dto.Screens.Count, pnr);

        return Results.Ok(dto);
    }

    private static async Task<IResult> GetPassengerInfo(
        string pnr,
        string lastName,
        IMediator mediator,
        IValidator<GetPassengerInfoQuery> validator,
        ILogger<UserJourneyEndpoints> logger,
        CancellationToken cancellationToken)
    {
        var query = new GetPassengerInfoQuery { Pnr = pnr.ToUpper(), LastName = lastName };
        
        // Validate the query
        var validationResult = await validator.ValidateAsync(query, cancellationToken);
        if (!validationResult.IsValid)
        {
            logger.LogWarning("Validation failed for GetPassengerInfo: {Errors}", 
                validationResult.Errors.Select(e => new { e.PropertyName, e.ErrorMessage }));
            
            return Results.ValidationProblem(validationResult.ToDictionary());
        }

        // Execute the query
        var result = await mediator.Send(query, cancellationToken);
        
        if (result.IsFailed)
        {
            var error = result.Errors.FirstOrDefault();
            
            return error?.Metadata.ContainsKey("Exception") == true && 
                   error.Metadata["Exception"] is PassengerNotFoundException
                ? Results.NotFound(new ProblemDetails
                {
                    Title = "Passenger Not Found",
                    Detail = error.Message,
                    Status = StatusCodes.Status404NotFound,
                    Instance = $"/api/user-journey/passenger/{pnr}/{lastName}"
                })
                : Results.Problem(new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = error?.Message ?? "An unexpected error occurred",
                    Status = StatusCodes.Status500InternalServerError,
                    Instance = $"/api/user-journey/passenger/{pnr}/{lastName}"
                });
        }

        var passenger = result.Value;
        var dto = MapToPassengerDto(passenger);
        
        logger.LogInformation("Successfully returned passenger info for PNR: {Pnr}", pnr);

        return Results.Ok(dto);
    }

    private static UserJourneyDto MapToDto(Domain.Entities.UserJourneyResult userJourney)
    {
        return new UserJourneyDto
        {
            Pnr = userJourney.Pnr,
            LastName = userJourney.LastName,
            Status = userJourney.Status.ToString(),
            Message = userJourney.Message,
            GeneratedAt = userJourney.GeneratedAt,
            Screens = userJourney.Screens.Select(s => new MobileScreenDto
            {
                ScreenId = s.ScreenId,
                Title = s.Title,
                Description = s.Description,
                Type = s.Type.ToString(),
                Order = s.Order,
                IsRequired = s.IsRequired,
                Parameters = s.Parameters,
                Actions = s.Actions
            }).ToList()
        };
    }

    private static PassengerInfoDto MapToPassengerDto(Domain.Entities.Passenger passenger)
    {
        return new PassengerInfoDto
        {
            Pnr = passenger.Pnr,
            LastName = passenger.LastName,
            FirstName = passenger.FirstName,
            IsCheckedIn = passenger.IsCheckedIn,
            HasSpecialNeeds = passenger.HasSpecialNeeds,
            IsFrequentFlyer = passenger.IsFrequentFlyer,
            Type = passenger.Type.ToString(),
            FlightDepartureTime = passenger.FlightDepartureTime,
            FlightStatus = passenger.FlightStatus.ToString(),
            HasSeatAssigned = passenger.HasSeatAssigned,
            HasBaggageChecked = passenger.HasBaggageChecked,
            RequiresDocumentVerification = passenger.RequiresDocumentVerification,
            HasMobileBoardingPass = passenger.HasMobileBoardingPass
        };
    }
}

/// <summary>
/// DTO for passenger information
/// </summary>
public class PassengerInfoDto
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
    public string FirstName { get; init; } = string.Empty;
    public bool IsCheckedIn { get; init; }
    public bool HasSpecialNeeds { get; init; }
    public bool IsFrequentFlyer { get; init; }
    public string Type { get; init; } = string.Empty;
    public DateTime FlightDepartureTime { get; init; }
    public string FlightStatus { get; init; } = string.Empty;
    public bool HasSeatAssigned { get; init; }
    public bool HasBaggageChecked { get; init; }
    public bool RequiresDocumentVerification { get; init; }
    public bool HasMobileBoardingPass { get; init; }
}
