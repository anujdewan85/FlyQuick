# UserJourney Service

A production-grade .NET 8 microservice that uses **NRules** to determine which mobile screens should be displayed to users based on their PNR and last name. This service acts as a decision engine for mobile app user experience flows.

## 🚀 Quick Start

```bash
# Start the service with dependencies
docker-compose up -d

# Build and run locally
dotnet build
dotnet run --project UserJourney.API
```

## 🎯 Service Overview

The UserJourney Service is responsible for:

- **Smart Screen Determination**: Uses NRules business rules engine to decide which mobile screens to show
- **Passenger Context Analysis**: Analyzes passenger data, flight status, and booking details
- **Mobile UX Orchestration**: Provides ordered list of screens for optimal user experience
- **Business Rules Management**: Easily configurable rules for different passenger scenarios
- **Real-time Decision Making**: Fast rule evaluation with caching for performance

**Port**: 5004  
**Health Check**: <http://localhost:5004/health>  
**API Documentation**: <http://localhost:5004/swagger>

## 🏗️ Architecture

This service follows Clean Architecture principles with **NRules** integration:

```text
├── UserJourney.API/              # API layer (Carter minimal APIs)
├── UserJourney.Application/      # Business logic (MediatR, CQRS)
├── UserJourney.Domain/          # Domain entities and NRules rules
├── UserJourney.Infrastructure/  # External service integrations
└── tests/                       # Comprehensive test suite
```

## 🔧 Technologies

### Core Framework

- **.NET 8**: Modern web API framework
- **Carter**: Lightweight HTTP API framework
- **MediatR**: CQRS implementation
- **FluentValidation**: Request validation

### Business Rules Engine

- **NRules**: .NET rules engine for business logic
- **Rule-based Architecture**: Declarative business rules
- **Dynamic Rule Evaluation**: Runtime rule execution
- **Fluent Rule Definition**: Easy-to-read rule syntax

### Caching & Performance

- **Memory Cache**: Fast in-memory caching
- **Redis**: Distributed caching (optional)
- **Response Caching**: HTTP response optimization

### Observability

- **Serilog**: Structured logging
- **Seq**: Centralized logging
- **Health Checks**: Comprehensive monitoring

## 🐳 Docker Setup

The service includes a complete Docker setup:

```bash
# Build the container
docker build -t userjourney-service .

# Run with docker-compose (includes Redis and Seq)
docker-compose up -d

# View logs
docker-compose logs -f userjourney-service
```

## 📝 API Endpoints

### User Journey Management

- `GET /api/user-journey/{pnr}/{lastName}` - Get mobile screens for user journey
- `GET /api/user-journey/passenger/{pnr}/{lastName}` - Get passenger information

### Example Request/Response

**Request:**
```http
GET /api/user-journey/ABC123/SMITH
```

**Response:**
```json
{
  "pnr": "ABC123",
  "lastName": "SMITH",
  "status": "InProgress",
  "message": "Follow the steps to complete your check-in.",
  "generatedAt": "2025-07-20T10:30:00Z",
  "screens": [
    {
      "screenId": "welcome",
      "title": "Welcome",
      "description": "Welcome to mobile check-in",
      "type": "Information",
      "order": 1,
      "isRequired": true,
      "parameters": {},
      "actions": ["continue"]
    },
    {
      "screenId": "passenger_verification",
      "title": "Verify Identity",
      "description": "Please verify your identity to continue",
      "type": "Verification",
      "order": 2,
      "isRequired": true,
      "parameters": {
        "requiresDocument": false,
        "pnr": "ABC123",
        "lastName": "SMITH"
      },
      "actions": ["verify", "back"]
    }
  ]
}
```

### Health & Monitoring

- `GET /health` - Health check endpoint
- `GET /health/ready` - Readiness probe
- `GET /health/live` - Liveness probe

## 🧠 NRules Business Logic

### Rule Categories

1. **Welcome Screen Rules** - Initial greeting and setup
2. **Passenger Verification Rules** - Identity validation
3. **Check-in Availability Rules** - Time window validation
4. **Seat Selection Rules** - Seat assignment flow
5. **Baggage Information Rules** - Baggage handling
6. **Special Assistance Rules** - Special needs support
7. **Flight Status Rules** - Delay/cancellation handling
8. **Check-in Confirmation Rules** - Final confirmation
9. **Boarding Pass Rules** - Mobile boarding pass
10. **Unaccompanied Minor Rules** - Special minor handling

### Sample Rule Definition

```csharp
[Name("SeatSelectionRules")]
public class SeatSelectionRule : Rule
{
    public override void Define()
    {
        JourneyContext context = null!;
        
        When()
            .Match(() => context, c => c.IsWithinCheckinWindow() && 
                                      !c.Passenger.IsCheckedIn && 
                                      !c.Passenger.HasSeatAssigned);

        Then()
            .Do(ctx => ctx.AddScreen(new MobileScreen
            {
                ScreenId = "seat_selection",
                Title = "Select Your Seat",
                Description = "Choose your preferred seat",
                Type = ScreenType.Action,
                Order = 4,
                Actions = new List<string> { "select_seat", "skip" }
            }));
    }
}
```

### Mock Passenger Data

For testing, the service includes mock passenger data:

- **ABC123/SMITH** - Regular passenger, not checked in
- **DEF456/JOHNSON** - Already checked in passenger
- **GHI789/WILLIAMS** - Passenger with special needs and delays
- **JKL012/BROWN** - Unaccompanied minor
- **MNO345/DAVIS** - Outside check-in window
- **PQR678/WILSON** - Cancelled flight

## 🔒 Security

- Request validation with FluentValidation
- Input sanitization for PNR and names
- Rate limiting capabilities
- HTTPS enforcement in production
- CORS configuration for mobile apps

## 📊 Observability

### Logging

- Structured logging with Serilog
- Request/response logging with correlation IDs
- Rule execution logging
- Performance metrics
- Error tracking with context

### Health Checks

- Application health
- Memory usage monitoring
- Redis connectivity (if configured)
- Custom business logic checks

## 🏃‍♂️ Local Development

### Prerequisites

- .NET 8 SDK
- Docker Desktop
- VS Code or Visual Studio

### Setup

```bash
# Clone and navigate
cd userjourney-service

# Restore dependencies
dotnet restore

# Start dependencies
docker-compose up -d redis seq

# Run the service
dotnet run --project UserJourney.API

# Run tests
dotnet test
```

### Development Tools

- Hot reload enabled
- Swagger UI available at `/swagger`
- Health checks at `/health`
- Seq logging dashboard at `http://localhost:8083`

## 🧪 Testing

### Test Scenarios

```bash
# Run all tests
dotnet test

# Unit tests only
dotnet test tests/UserJourney.UnitTests

# Integration tests
dotnet test tests/UserJourney.IntegrationTests

# Acceptance tests (BDD)
dotnet test tests/UserJourney.AcceptanceTests
```

### Sample Test Cases

1. **Welcome Flow** - Basic passenger journey initiation
2. **Check-in Available** - Normal check-in process
3. **Check-in Not Available** - Outside time window
4. **Special Needs** - Passenger requiring assistance
5. **Unaccompanied Minor** - Special handling required
6. **Flight Cancelled** - Error scenario handling
7. **Already Checked In** - Boarding pass display

## 🚀 Deployment

### Container Registry

```bash
# Build for production
docker build -t your-registry/userjourney-service:latest .

# Push to registry
docker push your-registry/userjourney-service:latest
```

### Environment Variables

```bash
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__Redis=...
Serilog__WriteTo__1__Args__serverUrl=...
ExternalServices__PassengerService__BaseUrl=...
ExternalServices__JourneyService__BaseUrl=...
```

## 📈 Performance

- **Rule Engine Optimization**: Fast rule evaluation with NRules
- **Memory Caching**: Frequent passenger lookups cached
- **Async Operations**: Non-blocking I/O throughout
- **Response Caching**: HTTP response optimization
- **Connection Pooling**: Efficient resource usage

### Performance Characteristics

- **Rule Evaluation**: < 50ms average
- **Cache Hit Rate**: > 80% for repeated requests
- **Memory Usage**: < 100MB typical
- **Throughput**: > 1000 requests/second

## 🔧 Configuration

Key configuration sections in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "Redis": "localhost:6379"
  },
  "ExternalServices": {
    "PassengerService": {
      "BaseUrl": "http://passenger-service:8080"
    },
    "JourneyService": {
      "BaseUrl": "http://journey-service:8080"
    }
  },
  "Caching": {
    "DefaultTtlMinutes": 5,
    "UserJourneyTtlMinutes": 10
  }
}
```

## 🆘 Troubleshooting

### Common Issues

1. **Service won't start**: Check Redis connectivity
2. **Rules not executing**: Verify rule assembly loading
3. **Passenger not found**: Check mock data or external service
4. **Performance issues**: Monitor cache hit rates

### Debugging

- Enable debug logging for rule execution
- Check health endpoints for dependencies
- Review Seq logs for detailed tracing
- Monitor memory usage for rule engine

## 🤝 Integration

### Mobile App Integration

```typescript
// TypeScript example for mobile apps
interface UserJourneyResponse {
  pnr: string;
  lastName: string;
  status: 'InProgress' | 'Complete' | 'Blocked' | 'Error';
  message: string;
  screens: MobileScreen[];
}

async function getUserJourney(pnr: string, lastName: string): Promise<UserJourneyResponse> {
  const response = await fetch(`/api/user-journey/${pnr}/${lastName}`);
  return response.json();
}
```

### Service Dependencies

- **Optional**: Passenger Service for real passenger data
- **Optional**: Journey Service for flight information
- **Required**: Redis for caching (optional but recommended)

---

## 🔗 Related Services

- **Checkin Service**: Uses this service for mobile check-in flows
- **Passenger Service**: Provides passenger data
- **Journey Service**: Provides flight information

For more information, see the main [README](../README.md) in the root directory.
