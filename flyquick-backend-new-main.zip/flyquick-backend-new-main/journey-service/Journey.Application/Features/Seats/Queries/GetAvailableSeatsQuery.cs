using MediatR;

namespace Journey.Application.Features.Seats.Queries;

public record GetAvailableSeatsQuery(string FlightNumber) : IRequest<SeatMapDto>;

public record SeatMapDto(string FlightNumber, SeatDto[] AvailableSeats);

public record SeatDto(
    string SeatNumber,
    string SeatType,
    bool IsAvailable,
    decimal? Price);

public class GetAvailableSeatsQueryHandler : IRequestHandler<GetAvailableSeatsQuery, SeatMapDto>
{
    public Task<SeatMapDto> Handle(GetAvailableSeatsQuery request, CancellationToken cancellationToken)
    {
        // Mock implementation
        var seats = new[]
        {
            new SeatDto("12A", "Window", true, 500m),
            new SeatDto("12B", "Middle", true, 400m),
            new SeatDto("12C", "Aisle", true, 500m),
            new SeatDto("13A", "Window", true, 400m),
            new SeatDto("13B", "Middle", false, null),
            new SeatDto("13C", "Aisle", true, 400m)
        };

        return Task.FromResult(new SeatMapDto(request.FlightNumber, seats));
    }
}
