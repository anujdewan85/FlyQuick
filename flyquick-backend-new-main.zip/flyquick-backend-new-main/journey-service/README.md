# Journey Service

A production-grade .NET 8 microservice for managing flight journeys and operations in the aviation system.

## 🚀 Quick Start

```bash
# Start the service with dependencies
docker-compose up -d

# Build and run locally
dotnet build
dotnet run --project Journey.API
```

## 🎯 Service Overview

The Journey Service is responsible for:
- Managing flight information and schedules
- Seat availability and assignment operations
- Journey planning and route management
- Integration with airline reservation systems
- Real-time flight status updates

**Port**: 5003  
**Health Check**: http://localhost:5003/health  
**API Documentation**: http://localhost:5003/swagger

## 🏗️ Architecture

This service follows Clean Architecture principles:

```
├── Journey.API/              # API layer (Controllers, Minimal APIs)
├── Journey.Application/      # Business logic (MediatR, CQRS)
├── Journey.Domain/          # Domain entities and business rules
├── Journey.Infrastructure/  # Data access, external services
└── tests/                   # Comprehensive test suite
```

## 🔧 Technologies

- **.NET 8**: Modern web API framework
- **Carter**: Lightweight HTTP API framework
- **MediatR**: CQRS implementation
- **FluentValidation**: Request validation
- **Serilog**: Structured logging
- **Redis**: Distributed caching
- **RabbitMQ**: Message broker
- **Polly**: Resilience patterns

## 🐳 Docker Setup

The service includes a complete Docker setup:

```bash
# Build the container
docker build -t journey-service .

# Run with docker-compose (includes Redis)
docker-compose up -d

# View logs
docker-compose logs -f journey-service
```

## 📝 API Endpoints

### Flight Management
- `GET /api/flights/{flightNumber}` - Get flight information
- `GET /api/flights/{flightNumber}/seats` - Get available seats
- `POST /api/flights/{flightNumber}/seats/assign` - Assign seat to passenger

### Journey Operations
- `GET /api/journeys/{journeyId}` - Get journey details
- `PUT /api/journeys/{journeyId}/status` - Update journey status

### Health & Monitoring
- `GET /health` - Health check endpoint
- `GET /health/ready` - Readiness probe
- `GET /health/live` - Liveness probe

## 🔒 Security

- JWT authentication for protected endpoints
- Request validation with FluentValidation
- Rate limiting for API endpoints
- HTTPS enforcement in production

## 📊 Observability

### Logging
- Structured logging with Serilog
- Centralized logging with Seq
- Request/response logging
- Performance metrics

### Health Checks
- Database connectivity
- Redis cache availability
- External service dependencies
- Custom business logic checks

## 🏃‍♂️ Local Development

### Prerequisites

- .NET 8 SDK
- Docker Desktop
- VS Code or Visual Studio

### Setup

```bash
# Clone and navigate
cd journey-service

# Restore dependencies
dotnet restore

# Start dependencies
docker-compose up -d redis seq

# Run the service
dotnet run --project Journey.API

# Run tests
dotnet test
```

### Development Tools

- Hot reload enabled
- Swagger UI available at `/swagger`
- Health checks UI at `/healthchecks-ui`

## 🧪 Testing

Comprehensive test suite with multiple levels:

```bash
# Run all tests
dotnet test

# Unit tests only
dotnet test tests/Journey.UnitTests

# Integration tests
dotnet test tests/Journey.IntegrationTests

# With coverage
dotnet test --collect:"XPlat Code Coverage"
```

## 🚀 Deployment

### Container Registry

```bash
# Build for production
docker build -t your-registry/journey-service:latest .

# Push to registry
docker push your-registry/journey-service:latest
```

### Environment Variables

```bash
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__DefaultConnection=...
Redis__ConnectionString=...
RabbitMQ__ConnectionString=...
Logging__LogLevel__Default=Information
```

## 📈 Performance

- Async/await throughout
- Distributed caching with Redis
- Connection pooling
- Efficient serialization
- Response caching strategies

## 🔧 Configuration

Key configuration sections in `appsettings.json`:

- Database connections
- Redis cache settings
- RabbitMQ configuration
- Logging configuration
- External service endpoints

## 🆘 Troubleshooting

### Common Issues

1. **Service won't start**: Check dependencies (Redis, database)
2. **High response times**: Monitor Redis connectivity
3. **Authentication failures**: Verify JWT configuration

### Monitoring

- Check `/health` endpoint
- Review application logs in Seq
- Monitor metrics in application insights

---

For more information, see the main [README](../README.md) in the root directory.
