## Description
Brief description of what this PR does.

## Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)
- [ ] Performance improvement

## Services Affected
- [ ] checkin-service
- [ ] userjourney-service (NRules)
- [ ] journey-service
- [ ] passenger-service

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] No new security vulnerabilities introduced

## Code Quality
- [ ] Code follows .NET coding standards
- [ ] SonarCloud quality gate passes
- [ ] No new code smells introduced
- [ ] Documentation updated (if needed)

## Docker & Deployment
- [ ] All services build successfully
- [ ] Container images are secure (Trivy scan passes)
- [ ] Health checks work correctly
- [ ] Environment variables documented

## Checklist
- [ ] Self-review completed
- [ ] Peer review requested
- [ ] Breaking changes documented
- [ ] Migration scripts provided (if needed)
- [ ] Monitoring/logging considerations addressed

## Screenshots (if applicable)
Add screenshots or diagrams to help explain your changes.

## Additional Notes
Any additional information that reviewers should know.
