# GitHub Copilot Instructions: Aviation Microservices Architecture

## Local Development Prerequisites

### Required Software
- **.NET 8 SDK** - Download from [https://dotnet.microsoft.com/download](https://dotnet.microsoft.com/download)
- **Podman** - Container engine and development environment
- **Podman Compose** - Container orchestration tool
- **Git** - Version control system
- **Visual Studio Code** or **Visual Studio 2022** - IDE with C# support

### Verify Installation
```bash
# Verify .NET installation
dotnet --version  # Should show 8.x.x

# Verify Podman installation
podman --version
podman-compose --version

# Verify Git installation
git --version
```

### Global .NET Tools
```bash
# Install required global tools
dotnet tool install --global dotnet-ef
dotnet tool install --global Husky
dotnet tool install --global dotnet-format
dotnet tool install --global dotnet-outdated-tool
```

### VS Code Extensions (Recommended)
- C# Dev Kit
- Podman
- GitLens
- REST Client or Thunder Client
- EditorConfig for VS Code
- SonarLint

### Optional Tools
- **Postman** - API testing
- **Redis CLI** - Cache debugging and monitoring
- **Seq** - Structured logging viewer (can run via Podman)

## Project Overview
Create 3 production-grade .NET 8 microservices for an aviation system:

1. **Checkin Service** - BFF (Backend for Frontend) for mobile applications
2. **Passenger Service** - Core passenger data management with Navitaire PSS integration
3. **Journey Service** - Flight and journey management with Navitaire PSS integration

## Architecture Requirements

### 12-Factor App Compliance
- **I. Codebase**: Single repo per service with version control
- **II. Dependencies**: Explicit dependency declaration via NuGet packages
- **III. Config**: Store configuration in environment variables
- **IV. Backing Services**: Treat databases and external services as attached resources
- **V. Build/Release/Run**: Strict separation using CI/CD pipelines
- **VI. Processes**: Execute as stateless processes
- **VII. Port Binding**: Export services via port binding
- **VIII. Concurrency**: Scale via process model
- **IX. Disposability**: Fast startup and graceful shutdown
- **X. Dev/Prod Parity**: Keep environments as similar as possible
- **XI. Logs**: Treat logs as event streams
- **XII. Admin Processes**: Run admin tasks as one-off processes

### Technology Stack

#### Core Framework
- .NET 8 Web API
- ASP.NET Core minimal APIs

#### Testing Libraries (BDD/TDD)
- **xUnit** - Primary testing framework
- **FluentAssertions** - Assertion library
- **SpecFlow** - BDD framework for Gherkin scenarios
- **AutoFixture** - Test data generation
- **Moq** - Mocking framework
- **TestContainers** - Integration testing with containers
- **WebApplicationFactory** - Integration testing for APIs
- **Bogus** - Fake data generation

#### Production Libraries
- **Serilog** - Structured logging with sinks (Console, Seq, Application Insights)
- **MediatR** - CQRS and mediator pattern implementation
- **FluentValidation** - Input validation
- **AutoMapper** - Object-to-object mapping
- **Polly** - Resilience and transient-fault handling
- **HealthChecks.UI** - Health check monitoring
- **Swagger/OpenAPI** - API documentation
- **Carter** - Minimal API routing (alternative to controllers)
- **Elsa.Core** - Workflow engine for business process orchestration
- **Elsa.Server** - Workflow server components

#### Caching & Performance
- **Microsoft.Extensions.Caching.Memory** - In-memory caching
- **Microsoft.Extensions.Caching.StackExchangeRedis** - Distributed Redis caching
- **ResponseCaching** - HTTP response caching middleware
- **OutputCaching** - .NET 7+ output caching

#### Observability & Monitoring
- **OpenTelemetry** - Distributed tracing and metrics
- **Application Insights** or **Jaeger** - APM integration
- **Prometheus.Client** - Metrics collection

#### Security
- **Microsoft.AspNetCore.Authentication.JwtBearer** - JWT authentication
- **Microsoft.AspNetCore.Authorization** - Authorization policies

#### Code Quality & Linting
- **Husky.Net** - Git hooks for pre-commit linting and formatting
- **Microsoft.CodeAnalysis.Analyzers** - Static code analysis
- **StyleCop.Analyzers** - Code style and consistency rules
- **SonarAnalyzer.CSharp** - Code quality and security analysis
- **EditorConfig** - Consistent coding styles across editors

## Service-Specific Requirements

### 1. Checkin Service (BFF)
```
Purpose: Mobile app backend with Elsa workflow orchestration for check-in process
Port: 5001
Health Check Endpoint: /health
Workflow: PNR + LastName → Retrieve → Validate → Update → Generate Boarding Pass
```

#### Additional Dependencies:
- **HttpClientFactory** - HTTP client management
- **Refit** - Type-safe HTTP client
- **ResponseCaching** - API response caching
- **YARP** (Yet Another Reverse Proxy) - API gateway capabilities
- **Elsa.Workflows.Core** - Core workflow engine
- **Elsa.Workflows.Management** - Workflow management
- **Elsa.Http** - HTTP workflow activities

### 2. Passenger Service
```
Purpose: Passenger data management with Navitaire PSS integration
Port: 5002
Health Check Endpoint: /health
```

#### Additional Dependencies:
- **MassTransit** - Message bus integration

### 3. Journey Service
```
Purpose: Flight and journey management with Navitaire PSS integration
Port: 5003
Health Check Endpoint: /health
```

#### Additional Dependencies:
- **MassTransit** - Message bus integration

## Container Requirements

### Containerfile Specifications
```dockerfile
# Use Red Hat UBI 8 base images
FROM registry.access.redhat.com/ubi8/dotnet-80:latest AS build
FROM registry.access.redhat.com/ubi8/dotnet-80-runtime:latest AS runtime

# Multi-stage build
# Non-root user execution
# Health check implementation
# Proper layer caching
```

### Podman Compose Structure
```yaml
# Include all 3 services
# Redis cache (distributed caching)
# RabbitMQ message broker
# Seq logging
# Health check UI
# Development environment setup
```

### .devcontainer Configuration
```json
# VS Code development container
# Include all necessary extensions
# Pre-configured debugging
# Port forwarding setup
# Redis integration
```

## Health Checks Implementation

### Required Health Checks per Service:
- **Application Health**: Basic service availability
- **External Dependencies**: Navitaire PSS system connectivity
- **Message Bus Health**: RabbitMQ/Azure Service Bus
- **Cache Health**: Redis connectivity and performance
- **Memory and CPU Usage**: Resource monitoring

### Health Check Endpoints:
- `/health` - Basic health check
- `/health/ready` - Readiness probe
- `/health/live` - Liveness probe
- `/health/detailed` - Detailed health information

## Project Structure per Service
```
ServiceName/
├── src/
│   ├── ServiceName.API/
│   ├── ServiceName.Application/
│   ├── ServiceName.Domain/
│   └── ServiceName.Infrastructure/
├── tests/
│   ├── ServiceName.UnitTests/
│   ├── ServiceName.IntegrationTests/
│   └── ServiceName.AcceptanceTests/
├── Containerfile
├── compose.yml
├── .devcontainer/
└── README.md
```

## Configuration Management
- **appsettings.json** - Base configuration
- **appsettings.Development.json** - Development overrides
- **Environment Variables** - Production secrets and config
- **Azure Key Vault** integration for sensitive data

## Logging Configuration
```json
{
  "Serilog": {
    "MinimumLevel": "Information",
    "WriteTo": [
      { "Name": "Console" },
      { "Name": "Seq", "Args": { "serverUrl": "http://seq:5341" } }
    ]
  }
}
```

## BDD Test Structure
```gherkin
Feature: Passenger Check-in Process
  Scenario: Successful passenger check-in
    Given a passenger with valid booking reference
    When they attempt to check in
    Then the check-in should be successful
    And a boarding pass should be generated
```

## External Integration Requirements

### Navitaire PSS Integration
- **SOAP/REST API clients** for Navitaire connectivity
- **Circuit breaker pattern** for resilience
- **Retry policies** for transient failures
- **Rate limiting** for API calls

## Deployment Considerations
- **Kubernetes manifests** (optional)
- **Helm charts** for parameterized deployments
- **Environment-specific configurations**
- **Secret management** integration
- **Horizontal Pod Autoscaling** configuration

## Quality Gates
- **Code coverage**: Minimum 80%
- **Static analysis**: SonarQube integration
- **Security scanning**: OWASP dependency check
- **Performance testing**: Load testing scenarios

## Local Development & Code Quality

### Pre-commit Hooks Setup
Configure Husky.Net for automated local linting:

```bash
# Install Husky.Net globally
dotnet tool install --global Husky

# Initialize in project
husky install

# Add pre-commit hook
husky add .husky/pre-commit "dotnet format --verify-no-changes"
husky add .husky/pre-commit "dotnet build --verbosity normal --warnaserror"
```

### Manual Linting Commands
```bash
# Code formatting
dotnet format

# Verify formatting without changes
dotnet format --verify-no-changes

# Build with warnings as errors
dotnet build --configuration Release --warnaserror

# Run static analysis
dotnet build --verbosity normal

# Run all tests
dotnet test --collect:"XPlat Code Coverage"
```

### EditorConfig Configuration
```ini
# .editorconfig file for consistent coding styles
root = true

[*.cs]
indent_style = space
indent_size = 4
end_of_line = crlf
insert_final_newline = true
trim_trailing_whitespace = true

# StyleCop rules
dotnet_diagnostic.SA1200.severity = error
dotnet_diagnostic.SA1633.severity = none
```

### IDE Integration
- **VS Code**: Install C# Dev Kit extension
- **Visual Studio**: Enable "Format Document on Save"
- **Rider**: Configure "Reformat Code" on save
- All IDEs should respect .editorconfig settings

Generate each service following these specifications with complete implementation including all testing layers, containerization, and production-ready configurations.

## Sample Service Implementations

### 1. Checkin Service - Elsa Workflow Implementation

#### Exception Handling Classes
```csharp
// Custom exception hierarchy
public abstract class CheckinServiceException : Exception
{
    protected CheckinServiceException(string message) : base(message) { }
    protected CheckinServiceException(string message, Exception innerException) : base(message, innerException) { }
}

public class PnrNotFoundException : CheckinServiceException
{
    public string Pnr { get; }
    public PnrNotFoundException(string pnr) : base($"PNR '{pnr}' not found")
        => Pnr = pnr;
}

public class PassengerValidationException : CheckinServiceException
{
    public string LastName { get; }
    public PassengerValidationException(string lastName) : base($"Passenger validation failed for last name '{lastName}'")
        => LastName = lastName;
}

public class NavitaireIntegrationException : CheckinServiceException
{
    public NavitaireIntegrationException(string message, Exception innerException) 
        : base($"Navitaire PSS integration error: {message}", innerException) { }
}

public class CheckinWorkflowException : CheckinServiceException
{
    public string WorkflowId { get; }
    public CheckinWorkflowException(string workflowId, string message) 
        : base($"Workflow {workflowId} error: {message}")
        => WorkflowId = workflowId;
}
```

#### Workflow Activities
```csharp
// Custom Elsa activities for check-in workflow
[Activity("RetrievePassengerData")]
public class RetrievePassengerDataActivity : CodeActivity<PassengerData>
{
    public Input<string> Pnr { get; set; } = default!;
    public Input<string> LastName { get; set; } = default!;
    
    protected override async ValueTask<PassengerData> ExecuteAsync(ActivityExecutionContext context)
    {
        // Implementation with exception handling
        var pnr = context.Get(Pnr);
        var lastName = context.Get(LastName);
        
        try
        {
            // Call Passenger Service via HTTP client
            // Handle Navitaire PSS integration
            // Validate passenger data
            return new PassengerData(pnr, lastName);
        }
        catch (HttpRequestException ex)
        {
            throw new NavitaireIntegrationException("Failed to retrieve passenger data", ex);
        }
    }
}

[Activity("ValidateCheckinEligibility")]
public class ValidateCheckinEligibilityActivity : CodeActivity<bool>
{
    public Input<PassengerData> PassengerData { get; set; } = default!;
    
    protected override async ValueTask<bool> ExecuteAsync(ActivityExecutionContext context)
    {
        // Validation logic with proper exception handling
    }
}

[Activity("UpdateCheckinStatus")]
public class UpdateCheckinStatusActivity : CodeActivity<CheckinResult>
{
    public Input<PassengerData> PassengerData { get; set; } = default!;
    
    protected override async ValueTask<CheckinResult> ExecuteAsync(ActivityExecutionContext context)
    {
        // Update logic with comprehensive error handling
    }
}
```

#### Workflow Definition
```csharp
public class CheckinWorkflow : WorkflowBase
{
    protected override void Build(IWorkflowBuilder builder)
    {
        builder
            .Root<HttpEndpoint>(http => http
                .WithPath("/checkin")
                .WithMethod(HttpMethods.Post)
                .WithSummary("Passenger Check-in Workflow"))
            
            .Then<RetrievePassengerDataActivity>(activity => activity
                .WithPnr(context => context.GetInput<string>("pnr"))
                .WithLastName(context => context.GetInput<string>("lastName")))
            
            .Then<ValidateCheckinEligibilityActivity>()
            
            .If(context => context.GetVariable<bool>("IsEligible"))
                .Then<UpdateCheckinStatusActivity>()
                .Then<GenerateBoardingPassActivity>()
                .Then<WriteHttpResponse>(response => response
                    .WithContent(context => context.GetVariable<CheckinResult>("Result"))
                    .WithStatusCode(HttpStatusCode.OK))
            .Else()
                .Then<WriteHttpResponse>(response => response
                    .WithContent("Check-in not allowed")
                    .WithStatusCode(HttpStatusCode.BadRequest));
    }
}
```

#### Global Exception Handler
```csharp
public class CheckinServiceExceptionHandler : IExceptionHandler
{
    private readonly ILogger<CheckinServiceExceptionHandler> _logger;
    
    public CheckinServiceExceptionHandler(ILogger<CheckinServiceExceptionHandler> logger)
        => _logger = logger;
    
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        var (statusCode, errorResponse) = exception switch
        {
            PnrNotFoundException ex => (StatusCodes.Status404NotFound, 
                new ErrorResponse("PNR_NOT_FOUND", ex.Message, ex.Pnr)),
            
            PassengerValidationException ex => (StatusCodes.Status400BadRequest,
                new ErrorResponse("VALIDATION_FAILED", ex.Message, ex.LastName)),
            
            NavitaireIntegrationException ex => (StatusCodes.Status502BadGateway,
                new ErrorResponse("EXTERNAL_SERVICE_ERROR", ex.Message)),
            
            CheckinWorkflowException ex => (StatusCodes.Status500InternalServerError,
                new ErrorResponse("WORKFLOW_ERROR", ex.Message, ex.WorkflowId)),
            
            _ => (StatusCodes.Status500InternalServerError,
                new ErrorResponse("INTERNAL_ERROR", "An unexpected error occurred"))
        };
        
        _logger.LogError(exception, "Exception handled: {ExceptionType}", exception.GetType().Name);
        
        httpContext.Response.StatusCode = statusCode;
        await httpContext.Response.WriteAsJsonAsync(errorResponse, cancellationToken);
        
        return true;
    }
}

public record ErrorResponse(string Code, string Message, object? Details = null);
```

### 2. Passenger Service - Sample Implementation

#### Exception Classes
```csharp
public abstract class PassengerServiceException : Exception
{
    protected PassengerServiceException(string message) : base(message) { }
    protected PassengerServiceException(string message, Exception innerException) : base(message, innerException) { }
}

public class PassengerNotFoundException : PassengerServiceException
{
    public string PassengerId { get; }
    public PassengerNotFoundException(string passengerId) 
        : base($"Passenger with ID '{passengerId}' not found")
        => PassengerId = passengerId;
}

public class DuplicatePassengerException : PassengerServiceException
{
    public DuplicatePassengerException(string message) : base(message) { }
}
```

#### Service Implementation
```csharp
public interface IPassengerService
{
    Task<PassengerDto> GetByPnrAsync(string pnr, string lastName, CancellationToken cancellationToken = default);
    Task<PassengerDto> UpdateAsync(string passengerId, UpdatePassengerRequest request, CancellationToken cancellationToken = default);
}

public class PassengerService : IPassengerService
{
    private readonly INavitaireClient _navitaireClient;
    private readonly IMemoryCache _cache;
    private readonly ILogger<PassengerService> _logger;
    
    public async Task<PassengerDto> GetByPnrAsync(string pnr, string lastName, CancellationToken cancellationToken = default)
    {
        try
        {
            // Cache check, Navitaire API call, validation logic
            // Comprehensive error handling and logging
        }
        catch (HttpRequestException ex)
        {
            throw new NavitaireIntegrationException("Failed to retrieve passenger", ex);
        }
    }
}
```

### 3. Journey Service - Sample Implementation

#### Exception Classes
```csharp
public abstract class JourneyServiceException : Exception
{
    protected JourneyServiceException(string message) : base(message) { }
    protected JourneyServiceException(string message, Exception innerException) : base(message, innerException) { }
}

public class FlightNotFoundException : JourneyServiceException
{
    public string FlightNumber { get; }
    public FlightNotFoundException(string flightNumber)
        : base($"Flight '{flightNumber}' not found")
        => FlightNumber = flightNumber;
}

public class SeatNotAvailableException : JourneyServiceException
{
    public string SeatNumber { get; }
    public SeatNotAvailableException(string seatNumber)
        : base($"Seat '{seatNumber}' is not available")
        => SeatNumber = seatNumber;
}
```

#### Service Implementation
```csharp
public interface IJourneyService
{
    Task<FlightDto> GetFlightAsync(string flightNumber, DateTime departureDate, CancellationToken cancellationToken = default);
    Task<SeatMapDto> GetSeatMapAsync(string flightNumber, CancellationToken cancellationToken = default);
}

public class JourneyService : IJourneyService
{
    private readonly INavitaireClient _navitaireClient;
    private readonly IDistributedCache _distributedCache;
    private readonly ILogger<JourneyService> _logger;
    
    // Implementation with caching, resilience patterns, and comprehensive error handling
}
```