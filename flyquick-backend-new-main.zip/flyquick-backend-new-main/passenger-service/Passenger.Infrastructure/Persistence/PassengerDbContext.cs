using Microsoft.EntityFrameworkCore;
using Passenger.Domain.Entities;

namespace Passenger.Infrastructure.Persistence;

public class PassengerDbContext : DbContext
{
    public PassengerDbContext(DbContextOptions<PassengerDbContext> options) : base(options)
    {
    }

    public DbSet<Domain.Entities.Passenger> Passengers { get; set; } = null!;
    public DbSet<PassengerFlightReservation> PassengerFlightReservations { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configure Passenger entity
        modelBuilder.Entity<Domain.Entities.Passenger>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(255);
            entity.Property(e => e.Phone).IsRequired().HasMaxLength(20);
            entity.Property(e => e.PassportNumber).HasMaxLength(20);
            entity.Property(e => e.DateOfBirth).IsRequired();
            entity.Property(e => e.CreatedAt).IsRequired();
            entity.Property(e => e.UpdatedAt);
        });

        // Configure PassengerFlightReservation entity
        modelBuilder.Entity<PassengerFlightReservation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PassengerId).IsRequired();
            entity.Property(e => e.Pnr).IsRequired().HasMaxLength(10);
            entity.Property(e => e.FlightNumber).IsRequired().HasMaxLength(10);
            entity.Property(e => e.Origin).IsRequired().HasMaxLength(3);
            entity.Property(e => e.Destination).IsRequired().HasMaxLength(3);
            entity.Property(e => e.Status).HasConversion<string>();
            entity.Property(e => e.DepartureTime).IsRequired();
            entity.Property(e => e.CheckInTime);
            entity.Property(e => e.CreatedAt).IsRequired();
            entity.Property(e => e.UpdatedAt);
            
            entity.HasIndex(e => e.Pnr).IsUnique();
            entity.HasIndex(e => e.PassengerId);
        });

        base.OnModelCreating(modelBuilder);
    }
}
