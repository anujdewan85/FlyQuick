//using Passenger.Domain.Entities;
//using Passenger.Domain.ValueObjects;

//namespace Passenger.Infrastructure.Persistence;

///// <summary>
///// Seed data for testing and development purposes
///// </summary>
//public static class PassengerSeedData
//{
//    public static List<Domain.Entities.Passenger> GetTestPassengers()
//    {
//        return new List<Domain.Entities.Passenger>
//        {
//            new Domain.Entities.Passenger(
//                firstName: "Rahul",
//                lastName: "Verma", 
//                email: "rahul.verma@email.com",
//                phone: "+91234567890",
//                dateOfBirth: new DateTime(1985, 5, 15),
//                passportNumber: "A12345678"
//            ),
//            new Domain.Entities.Passenger(
//                firstName: "Priya",
//                lastName: "Sharma",
//                email: "priya.sharma@email.com", 
//                phone: "+91234567891",
//                dateOfBirth: new DateTime(1987, 8, 22),
//                passportNumber: "B87654321"
//            ),
//            new Domain.Entities.Passenger(
//                firstName: "Amit",
//                lastName: "Singh",
//                email: "amit.singh@email.com",
//                phone: "+91234567892", 
//                dateOfBirth: new DateTime(1990, 12, 10),
//                passportNumber: "C11223344"
//            )
//        };
//    }

//    public static List<PassengerFlightReservation> GetTestReservations()
//    {
//        var passengers = GetTestPassengers();
        
//        return new List<PassengerFlightReservation>
//        {
//            new PassengerFlightReservation(
//                passengerId: passengers[0].Id,
//                pnr: "ABC123",
//                flightNumber: "AI101",
//                departureTime: DateTime.Now.AddDays(7),
//                origin: "DEL",
//                destination: "BOM"
//            ),
//            new PassengerFlightReservation(
//                passengerId: passengers[1].Id,
//                pnr: "DEF456", 
//                flightNumber: "AI102",
//                departureTime: DateTime.Now.AddDays(10),
//                origin: "BOM",
//                destination: "BLR"
//            ),
//            new PassengerFlightReservation(
//                passengerId: passengers[2].Id,
//                pnr: "GHI789",
//                flightNumber: "AI103", 
//                departureTime: DateTime.Now.AddDays(14),
//                origin: "BLR",
//                destination: "DEL"
//            )
//        };
//    }
//}
///*}
//                        SeatNumber = "12B",
//                        TicketClass = "Economy",
//                        IsCheckedIn = false
//                    }
//                },
//                FlightJourneys = new List<FlightJourney>
//                {
//                    new FlightJourney
//                    {
//                        FlightNumber = "IN101",
//                        Airline = "IndiGo",
//                        Origin = "DEL",
//                        Destination = "BOM",
//                        DepartureTime = DateTime.Now.AddDays(1).Date.AddHours(14).AddMinutes(30),
//                        ArrivalTime = DateTime.Now.AddDays(1).Date.AddHours(16).AddMinutes(45),
//                        AircraftType = "A320",
//                        Gate = "A12",
//                        Terminal = "T3",
//                        Status = "On Time"
//                    }
//                }
//            },
//            new FlightBooking
//            {
//                BookingReference = "XYZ789",
//                BookingDate = DateTime.Now.AddDays(-5),
//                BookingStatus = "Confirmed",
//                TotalAmount = 850.00m,
//                Currency = "INR",
//                ContactEmail = "rohit.sharma@email.com",
//                ContactPhone = "+91987654321",
//                Passengers = new List<Passenger>
//                {
//                    new Passenger
//                    {
//                        PassengerId = "P003",
//                        FirstName = "Rohit",
//                        LastName = "Sharma",
//                        Email = "rohit.sharma@email.com",
//                        Phone = "+91987654321",
//                        DateOfBirth = new DateTime(1990, 3, 10),
//                        PassportNumber = "C11223344",
//                        Nationality = "IND",
//                        SeatNumber = "8C",
//                        TicketClass = "Business",
//                        IsCheckedIn = false
//                    }
//                },
//                FlightJourneys = new List<FlightJourney>
//                {
//                    new FlightJourney
//                    {
//                        FlightNumber = "IN205",
//                        Airline = "IndiGo",
//                        Origin = "BOM",
//                        Destination = "BLR",
//                        DepartureTime = DateTime.Now.AddDays(2).Date.AddHours(9).AddMinutes(15),
//                        ArrivalTime = DateTime.Now.AddDays(2).Date.AddHours(10).AddMinutes(30),
//                        AircraftType = "A321",
//                        Gate = "B7",
//                        Terminal = "T2",
//                        Status = "On Time"
//                    }
//                }
//            },
//            new FlightBooking
//            {
//                BookingReference = "PQR456",
//                BookingDate = DateTime.Now.AddDays(-3),
//                BookingStatus = "Confirmed",
//                TotalAmount = 2400.00m,
//                Currency = "INR",
//                ContactEmail = "raj.kumar@email.com",
//                ContactPhone = "+919876543210",
//                Passengers = new List<Passenger>
//                {
//                    new Passenger
//                    {
//                        PassengerId = "P004",
//                        FirstName = "Raj",
//                        LastName = "Kumar",
//                        Email = "raj.kumar@email.com",
//                        Phone = "+919876543210",
//                        DateOfBirth = new DateTime(1980, 12, 5),
//                        PassportNumber = "D55667788",
//                        Nationality = "IN",
//                        SeatNumber = "3A",
//                        TicketClass = "Business",
//                        IsCheckedIn = true,
//                        CheckInTime = DateTime.Now.AddHours(-2)
//                    },
//                    new Passenger
//                    {
//                        PassengerId = "P005",
//                        FirstName = "Priya",
//                        LastName = "Kumar",
//                        Email = "priya.kumar@email.com",
//                        Phone = "+919876543211",
//                        DateOfBirth = new DateTime(1983, 7, 18),
//                        PassportNumber = "E99887766",
//                        Nationality = "IN",
//                        SeatNumber = "3B",
//                        TicketClass = "Business",
//                        IsCheckedIn = true,
//                        CheckInTime = DateTime.Now.AddHours(-2)
//                    },
//                    new Passenger
//                    {
//                        PassengerId = "P006",
//                        FirstName = "Arjun",
//                        LastName = "Kumar",
//                        Email = "arjun.kumar@email.com",
//                        Phone = "+919876543212",
//                        DateOfBirth = new DateTime(2010, 2, 28),
//                        PassportNumber = "F44556677",
//                        Nationality = "IN",
//                        SeatNumber = "3C",
//                        TicketClass = "Business",
//                        IsCheckedIn = true,
//                        CheckInTime = DateTime.Now.AddHours(-2)
//                    }
//                },
//                FlightJourneys = new List<FlightJourney>
//                {
//                    new FlightJourney
//                    {
//                        FlightNumber = "IN501",
//                        Airline = "IndiGo",
//                        Origin = "DEL",
//                        Destination = "GOA",
//                        DepartureTime = DateTime.Now.AddDays(3).Date.AddHours(6).AddMinutes(30),
//                        ArrivalTime = DateTime.Now.AddDays(3).Date.AddHours(9).AddMinutes(15),
//                        AircraftType = "A320neo",
//                        Gate = "C15",
//                        Terminal = "T1",
//                        Status = "On Time"
//                    },
//                    new FlightJourney
//                    {
//                        FlightNumber = "IN502",
//                        Airline = "IndiGo",
//                        Origin = "GOA",
//                        Destination = "DEL",
//                        DepartureTime = DateTime.Now.AddDays(10).Date.AddHours(20).AddMinutes(45),
//                        ArrivalTime = DateTime.Now.AddDays(10).Date.AddHours(23).AddMinutes(30),
//                        AircraftType = "A320neo",
//                        Gate = "A8",
//                        Terminal = "T1",
//                        Status = "Scheduled"
//                    }
//                }
//            }
//        };
//    }
//}
//*/
