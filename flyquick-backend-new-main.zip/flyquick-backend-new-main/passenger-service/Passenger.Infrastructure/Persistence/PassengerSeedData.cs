using Passenger.Domain.Entities;

namespace Passenger.Infrastructure.Persistence;

/// <summary>
/// Seed data for testing and development purposes
/// </summary>
public static class PassengerSeedData
{
    public static List<Domain.Entities.Passenger> GetTestPassengers()
    {
        return new List<Domain.Entities.Passenger>
        {
            new Domain.Entities.Passenger(
                firstName: "Rahul",
                lastName: "Verma", 
                email: "rahul.verma@email.com",
                phone: "+91234567890",
                dateOfBirth: new DateTime(1985, 5, 15),
                passportNumber: "A12345678"
            ),
            new Domain.Entities.Passenger(
                firstName: "Priya",
                lastName: "Sharma",
                email: "priya.sharma@email.com", 
                phone: "+91234567891",
                dateOfBirth: new DateTime(1987, 8, 22),
                passportNumber: "B87654321"
            ),
            new Domain.Entities.Passenger(
                firstName: "Amit",
                lastName: "Singh",
                email: "amit.singh@email.com",
                phone: "+91234567892", 
                dateOfBirth: new DateTime(1990, 12, 10),
                passportNumber: "C11223344"
            )
        };
    }

    public static List<PassengerFlightReservation> GetTestReservations()
    {
        var passengers = GetTestPassengers();
        
        return new List<PassengerFlightReservation>
        {
            new PassengerFlightReservation(
                passengerId: passengers[0].Id,
                pnr: "ABC123",
                flightNumber: "AI101",
                departureTime: DateTime.Now.AddDays(7),
                origin: "DEL",
                destination: "BOM"
            ),
            new PassengerFlightReservation(
                passengerId: passengers[1].Id,
                pnr: "DEF456", 
                flightNumber: "AI102",
                departureTime: DateTime.Now.AddDays(10),
                origin: "BOM",
                destination: "BLR"
            ),
            new PassengerFlightReservation(
                passengerId: passengers[2].Id,
                pnr: "GHI789",
                flightNumber: "AI103", 
                departureTime: DateTime.Now.AddDays(14),
                origin: "BLR",
                destination: "DEL"
            )
        };
    }
}
