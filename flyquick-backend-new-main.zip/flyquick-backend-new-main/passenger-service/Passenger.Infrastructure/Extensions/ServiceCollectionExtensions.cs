using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Passenger.Infrastructure.Persistence;
using Passenger.Infrastructure.Repositories;
using Passenger.Application.Abstractions;

namespace Passenger.Infrastructure.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Add Entity Framework
        services.AddDbContext<PassengerDbContext>(options =>
            options.UseSqlite(configuration.GetConnectionString("DefaultConnection")));

        // Add repositories
        services.AddScoped<IPassengerRepository, PassengerRepository>();
        services.AddScoped<IFlightReservationRepository, FlightReservationRepository>();
        
        return services;
    }
}
