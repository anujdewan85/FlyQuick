using Microsoft.EntityFrameworkCore;
using Passenger.Application.Abstractions;
using Passenger.Infrastructure.Persistence;
using PassengerEntity = Passenger.Domain.Entities.Passenger;

namespace Passenger.Infrastructure.Repositories;

/// <summary>
/// Repository implementation for passenger operations
/// </summary>
public class PassengerRepository : IPassengerRepository
{
    private readonly PassengerDbContext _context;

    public PassengerRepository(PassengerDbContext context)
    {
        _context = context;
    }

    public async Task<PassengerEntity?> GetByIdAsync(string passengerId, CancellationToken cancellationToken = default)
    {
        return await _context.Passengers
            .FirstOrDefaultAsync(p => p.Id == passengerId, cancellationToken);
    }

    public async Task<PassengerEntity> AddAsync(PassengerEntity passenger, CancellationToken cancellationToken = default)
    {
        _context.Passengers.Add(passenger);
        await _context.SaveChangesAsync(cancellationToken);
        return passenger;
    }

    public async Task<PassengerEntity> UpdateAsync(PassengerEntity passenger, CancellationToken cancellationToken = default)
    {
        _context.Passengers.Update(passenger);
        await _context.SaveChangesAsync(cancellationToken);
        return passenger;
    }
    
    public async Task DeleteAsync(string passengerId, CancellationToken cancellationToken = default)
    {
        var passenger = await GetByIdAsync(passengerId, cancellationToken);
        if (passenger != null)
        {
            _context.Passengers.Remove(passenger);
            await _context.SaveChangesAsync(cancellationToken);
        }
    }

    public async Task<IEnumerable<PassengerEntity>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Passengers.ToListAsync(cancellationToken);
    }
}
