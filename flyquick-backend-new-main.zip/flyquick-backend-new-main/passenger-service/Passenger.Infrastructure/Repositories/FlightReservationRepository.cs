using Microsoft.EntityFrameworkCore;
using Passenger.Application.Abstractions;
using Passenger.Domain.Entities;
using Passenger.Infrastructure.Persistence;

namespace Passenger.Infrastructure.Repositories;

/// <summary>
/// Repository implementation for flight reservation operations
/// </summary>
public class FlightReservationRepository : IFlightReservationRepository
{
    private readonly PassengerDbContext _context;

    public FlightReservationRepository(PassengerDbContext context)
    {
        _context = context;
    }

    public async Task<PassengerFlightReservation?> GetByIdAsync(string reservationId, CancellationToken cancellationToken = default)
    {
        return await _context.PassengerFlightReservations
            .FirstOrDefaultAsync(r => r.Id == reservationId, cancellationToken);
    }

    public async Task<PassengerFlightReservation?> GetByPnrAsync(string pnr, CancellationToken cancellationToken = default)
    {
        return await _context.PassengerFlightReservations
            .Include(r => r.Passenger)
            .FirstOrDefaultAsync(r => r.Pnr == pnr, cancellationToken);
    }

    public async Task<PassengerFlightReservation?> GetByPnrAndLastNameAsync(string pnr, string lastName, CancellationToken cancellationToken = default)
    {
        return await _context.PassengerFlightReservations
            .Include(r => r.Passenger)
            .FirstOrDefaultAsync(r => r.Pnr == pnr && r.Passenger!.LastName == lastName, cancellationToken);
    }

    public async Task<IEnumerable<PassengerFlightReservation>> GetByPassengerIdAsync(string passengerId, CancellationToken cancellationToken = default)
    {
        return await _context.PassengerFlightReservations
            .Where(r => r.PassengerId == passengerId)
            .ToListAsync(cancellationToken);
    }

    public async Task<PassengerFlightReservation> AddAsync(PassengerFlightReservation reservation, CancellationToken cancellationToken = default)
    {
        _context.PassengerFlightReservations.Add(reservation);
        await _context.SaveChangesAsync(cancellationToken);
        return reservation;
    }

    public async Task<PassengerFlightReservation> UpdateAsync(PassengerFlightReservation reservation, CancellationToken cancellationToken = default)
    {
        _context.PassengerFlightReservations.Update(reservation);
        await _context.SaveChangesAsync(cancellationToken);
        return reservation;
    }

    public async Task DeleteAsync(string reservationId, CancellationToken cancellationToken = default)
    {
        var reservation = await GetByIdAsync(reservationId, cancellationToken);
        if (reservation != null)
        {
            _context.PassengerFlightReservations.Remove(reservation);
            await _context.SaveChangesAsync(cancellationToken);
        }
    }
}
