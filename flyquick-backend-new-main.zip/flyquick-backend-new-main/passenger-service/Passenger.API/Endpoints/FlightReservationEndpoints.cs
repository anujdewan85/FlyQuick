using Carter;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Passenger.Application.Features.FlightReservations.Queries;
using Passenger.Application.Features.FlightReservations.Commands;
using Passenger.API.DTOs;
using Mapster;

namespace Passenger.API.Endpoints;

public class FlightReservationEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/passengers/flight-reservations")
            .WithTags("Flight Reservations")
            .WithOpenApi();

        group.MapPost("/", CreateFlightReservation)
            .WithName("CreateFlightReservation")
            .WithSummary("Create a new flight reservation")
            .Produces<CreatePassengerFlightReservationResponse>(201)
            .Produces(400);

        group.MapGet("/pnr/{pnr}", GetFlightReservationByPnr)
            .WithName("GetFlightReservationByPnr")
            .WithSummary("Get flight reservation by PNR")
            .Produces<FlightReservationResponse>(200)
            .Produces(404);
    }

    private static async Task<IResult> CreateFlightReservation(
        [FromBody] CreateFlightReservationRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = request.Adapt<CreatePassengerFlightReservationCommand>();
        var result = await mediator.Send(command, cancellationToken);
        var response = result.Adapt<CreatePassengerFlightReservationResponse>();
        return Results.Created($"/api/passengers/flight-reservations/{response.ReservationId}", response);
    }

    private static async Task<IResult> GetFlightReservationByPnr(
        string pnr,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetFlightReservationByPnrQuery(pnr);
        var result = await mediator.Send(query, cancellationToken);
        
        if (result == null)
            return Results.NotFound($"Flight reservation not found for PNR: {pnr}");
            
        var response = result.Adapt<FlightReservationResponse>();
        return Results.Ok(response);
    }
}
