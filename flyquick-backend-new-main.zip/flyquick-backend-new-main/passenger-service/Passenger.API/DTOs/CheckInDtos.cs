namespace Passenger.API.DTOs;

// ===== CHECK-IN OPERATION DTOs =====
// These DTOs handle check-in workflows and status management

public record CheckInPassengerRequest(string PNR);

public record CheckInPassengerResponse(
    bool IsSuccess,
    string Message,
    DateTime? CheckInTime,
    string PNR,
    string SeatNumber = "",
    string GateNumber = "");

public record UpdateStatusRequest(string Status);

public record UpdateCheckinStatusResponse(
    string ReservationId,
    string Pnr,
    string Status,
    DateTime? CheckInTime);

public record GetCheckInStatusRequest(string PNR);

public record GetCheckInStatusResponse(
    string PNR,
    string Status,
    DateTime? CheckInTime,
    string SeatNumber = "",
    string GateNumber = "",
    bool CanCheckIn = false);

public record BulkCheckInRequest(
    List<string> PNRs);

public record BulkCheckInResponse(
    int SuccessCount,
    int FailureCount,
    List<CheckInResult> Results);

public record CheckInResult(
    string PNR,
    bool IsSuccess,
    string Message,
    DateTime? CheckInTime = null);
