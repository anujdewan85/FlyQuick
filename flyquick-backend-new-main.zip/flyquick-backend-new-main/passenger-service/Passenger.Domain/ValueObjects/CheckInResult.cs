namespace Passenger.Domain.ValueObjects;

public class CheckInResult
{
    public bool IsSuccess { get; private set; }
    public string? ErrorMessage { get; private set; }

    private CheckInResult(bool isSuccess, string? errorMessage = null)
    {
        IsSuccess = isSuccess;
        ErrorMessage = errorMessage;
    }

    public static CheckInResult Success() => new(true);
    public static CheckInResult Failure(string errorMessage) => new(false, errorMessage);
}
