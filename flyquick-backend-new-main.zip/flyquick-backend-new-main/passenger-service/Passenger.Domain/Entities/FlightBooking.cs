using Passenger.Domain.ValueObjects;

namespace Passenger.Domain.Entities;

/// <summary>
/// Represents a flight booking that contains multiple passenger reservations
/// </summary>
public class FlightBooking
{
    public string BookingReference { get; private set; } = string.Empty; // PNR
    public DateTime BookingDate { get; private set; }
    public string BookingStatus { get; private set; } = string.Empty;
    public List<PassengerFlightReservation> Reservations { get; private set; } = new();
    public decimal TotalAmount { get; private set; }
    public string Currency { get; private set; } = "INR";
    public string ContactEmail { get; private set; } = string.Empty;
    public string ContactPhone { get; private set; } = string.Empty;

    private FlightBooking() { }

    public FlightBooking(string bookingReference, string contactEmail, string contactPhone)
    {
        BookingReference = bookingReference;
        BookingDate = DateTime.UtcNow;
        BookingStatus = "Confirmed";
        ContactEmail = contactEmail;
        ContactPhone = contactPhone;
    }

    public void AddReservation(PassengerFlightReservation reservation)
    {
        if (reservation == null)
            throw new ArgumentNullException(nameof(reservation));
            
        Reservations.Add(reservation);
    }

    public void RemoveReservation(string reservationId)
    {
        var reservation = Reservations.FirstOrDefault(r => r.Id == reservationId);
        if (reservation != null)
        {
            Reservations.Remove(reservation);
        }
    }

    public void UpdateBookingStatus(string newStatus)
    {
        if (string.IsNullOrWhiteSpace(newStatus))
            throw new ArgumentNullException(nameof(newStatus));
            
        BookingStatus = newStatus;
    }

    public bool CanBeCancelled()
    {
        return BookingStatus == "Confirmed" && 
               Reservations.All(r => r.Status == CheckInStatus.NotCheckedIn);
    }

    public void Cancel()
    {
        if (!CanBeCancelled())
            throw new InvalidOperationException("Booking cannot be cancelled at this time");
            
        BookingStatus = "Cancelled";
        foreach (var reservation in Reservations)
        {
            reservation.UpdateCheckInStatus(CheckInStatus.Cancelled);
        }
    }
}
