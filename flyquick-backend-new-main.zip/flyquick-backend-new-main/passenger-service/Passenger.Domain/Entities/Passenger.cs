using Passenger.Domain.ValueObjects;
using Passenger.Domain.Common;
using Passenger.Domain.Events;

namespace Passenger.Domain.Entities;

/// <summary>
/// Represents a passenger - a person who travels
/// </summary>
public class Passenger : AggregateRoot
{
    public string Id { get; private set; } = string.Empty;
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string Phone { get; private set; } = string.Empty;
    public DateTime DateOfBirth { get; private set; }
    public string PassportNumber { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    // Private constructor for EF Core
    private Passenger() { }

    public Passenger(
        string firstName,
        string lastName,
        string email,
        string phone,
        DateTime dateOfBirth,
        string passportNumber = "")
    {
        Id = Guid.NewGuid().ToString();
        FirstName = firstName ?? throw new ArgumentNullException(nameof(firstName));
        LastName = lastName ?? throw new ArgumentNullException(nameof(lastName));
        Email = email ?? throw new ArgumentNullException(nameof(email));
        Phone = phone ?? throw new ArgumentNullException(nameof(phone));
        DateOfBirth = dateOfBirth;
        PassportNumber = passportNumber ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        
        // Raise domain event
        AddDomainEvent(new PassengerCreatedEvent(Id, FirstName, LastName, Email));
    }

    public void UpdateContactInformation(string email, string phone)
    {
        if (string.IsNullOrWhiteSpace(email) && string.IsNullOrWhiteSpace(phone))
            throw new ArgumentException("At least one contact field must be provided");

        if (!string.IsNullOrWhiteSpace(email))
            Email = email;
            
        if (!string.IsNullOrWhiteSpace(phone))
            Phone = phone;
            
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email cannot be null or empty");
            
        Email = email;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdatePhone(string phone)
    {
        if (string.IsNullOrWhiteSpace(phone))
            throw new ArgumentException("Phone cannot be null or empty");
            
        Phone = phone;
        UpdatedAt = DateTime.UtcNow;
    }

    public string GetFullName() => $"{FirstName} {LastName}";
}
