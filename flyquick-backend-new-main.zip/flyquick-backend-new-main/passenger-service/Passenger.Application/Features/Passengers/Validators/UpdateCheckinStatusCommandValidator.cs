using FluentValidation;
using Passenger.Application.Features.Passengers.Commands;
using Passenger.Domain.ValueObjects;

namespace Passenger.Application.Features.Passengers.Validators;

public class UpdateCheckinStatusCommandValidator : AbstractValidator<UpdateCheckinStatusCommand>
{
    public UpdateCheckinStatusCommandValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty().WithMessage("PNR is required")
            .Length(6).WithMessage("PNR must be exactly 6 characters")
            .Matches("^[A-Z0-9]+$").WithMessage("PNR can only contain uppercase letters and numbers");

        RuleFor(x => x.Status)
            .NotEmpty().WithMessage("Status is required")
            .Must(BeValidStatus).WithMessage("Invalid check-in status");
    }

    private bool BeValidStatus(string status)
    {
        return Enum.TryParse<CheckInStatus>(status, true, out _);
    }
}
