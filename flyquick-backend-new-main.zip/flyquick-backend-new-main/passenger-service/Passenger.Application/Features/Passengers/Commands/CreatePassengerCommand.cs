using MediatR;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.Passengers.Commands;

public record CreatePassengerCommand(
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber = "") : IRequest<CreatePassengerResponse>;

public record CreatePassengerResponse(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    DateTime CreatedAt);

public class CreatePassengerCommandHandler : IRequestHandler<CreatePassengerCommand, CreatePassengerResponse>
{
    private readonly IPassengerRepository _repository;

    public CreatePassengerCommandHandler(IPassengerRepository repository)
    {
        _repository = repository;
    }

    public async Task<CreatePassengerResponse> Handle(CreatePassengerCommand request, CancellationToken cancellationToken)
    {
        var passenger = new Domain.Entities.Passenger(
            request.FirstName,
            request.LastName,
            request.Email,
            request.Phone,
            request.DateOfBirth,
            request.PassportNumber);

        var createdPassenger = await _repository.AddAsync(passenger, cancellationToken);

        return new CreatePassengerResponse(
            createdPassenger.Id,
            createdPassenger.FirstName,
            createdPassenger.LastName,
            createdPassenger.Email,
            createdPassenger.CreatedAt);
    }
}
