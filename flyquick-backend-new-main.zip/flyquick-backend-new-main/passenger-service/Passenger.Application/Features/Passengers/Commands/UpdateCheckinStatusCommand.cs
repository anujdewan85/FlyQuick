using MediatR;
using Passenger.Application.Abstractions;
using Passenger.Application.Common.Exceptions;
using Passenger.Domain.ValueObjects;

namespace Passenger.Application.Features.Passengers.Commands;

public record UpdateCheckinStatusCommand(string Pnr, string Status) : IRequest<PassengerStatusDto>;

public record PassengerStatusDto(
    string Pnr,
    string Status,
    DateTime UpdatedAt);

public class UpdateCheckinStatusCommandHandler(IFlightReservationRepository reservationRepository) : IRequestHandler<UpdateCheckinStatusCommand, PassengerStatusDto>
{
    private readonly IFlightReservationRepository _reservationRepository = reservationRepository;

    public async Task<PassengerStatusDto> Handle(UpdateCheckinStatusCommand request, CancellationToken cancellationToken)
    {
        var reservation = await _reservationRepository.GetByPnrAsync(request.Pnr, cancellationToken) ?? throw new NotFoundException($"Reservation with PNR {request.Pnr} not found");
        if (Enum.TryParse<CheckInStatus>(request.Status, true, out var status))
        {
            reservation.UpdateCheckInStatus(status);
            await _reservationRepository.UpdateAsync(reservation, cancellationToken);
        }

        return new PassengerStatusDto(
            reservation.Pnr,
            reservation.Status.ToString(),
            DateTime.UtcNow
        );
    }
}
