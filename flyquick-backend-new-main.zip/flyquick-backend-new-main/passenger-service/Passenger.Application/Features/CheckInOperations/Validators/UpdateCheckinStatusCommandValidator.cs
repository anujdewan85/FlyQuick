using FluentValidation;
using Passenger.Application.Features.CheckInOperations.Commands;

namespace Passenger.Application.Features.CheckInOperations.Validators;

public class UpdateCheckinStatusCommandValidator : AbstractValidator<UpdateCheckinStatusCommand>
{
    public UpdateCheckinStatusCommandValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 10)
            .WithMessage("PNR must be between 6 and 10 characters");

        RuleFor(x => x.Status)
            .NotEmpty()
            .WithMessage("Status is required")
            .Must(BeValidStatus)
            .WithMessage("Invalid status value");
    }

    private static bool BeValidStatus(string status)
    {
        return Enum.TryParse<Domain.ValueObjects.CheckInStatus>(status, true, out _);
    }
}
