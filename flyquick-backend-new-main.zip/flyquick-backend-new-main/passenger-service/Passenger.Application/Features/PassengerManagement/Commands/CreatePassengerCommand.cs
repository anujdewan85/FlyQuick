using MediatR;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.PassengerManagement.Commands;

public record CreatePassengerCommand(
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber = "") : IRequest<CreatePassengerResult>;

public record CreatePassengerResult(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public class CreatePassengerCommandHandler : IRequestHandler<CreatePassengerCommand, CreatePassengerResult>
{
    private readonly IPassengerRepository _repository;

    public CreatePassengerCommandHandler(IPassengerRepository repository)
    {
        _repository = repository;
    }

    public async Task<CreatePassengerResult> Handle(CreatePassengerCommand request, CancellationToken cancellationToken)
    {
        var passenger = new Domain.Entities.Passenger(
            request.FirstName,
            request.LastName,
            request.Email,
            request.Phone,
            request.DateOfBirth,
            request.PassportNumber);

        await _repository.AddAsync(passenger, cancellationToken);

        return new CreatePassengerResult(
            passenger.Id,
            passenger.FirstName,
            passenger.LastName,
            passenger.Email,
            passenger.Phone,
            passenger.DateOfBirth,
            passenger.PassportNumber);
    }
}
