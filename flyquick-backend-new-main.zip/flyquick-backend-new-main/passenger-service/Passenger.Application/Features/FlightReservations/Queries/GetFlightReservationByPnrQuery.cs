using MediatR;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.FlightReservations.Queries;

public record GetFlightReservationByPnrQuery(string Pnr) : IRequest<FlightReservationDto?>;

public record FlightReservationDto(
    string ReservationId,
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status,
    DateTime? CheckInTime);

public class GetFlightReservationByPnrQueryHandler : IRequestHandler<GetFlightReservationByPnrQuery, FlightReservationDto?>
{
    private readonly IFlightReservationRepository _repository;

    public GetFlightReservationByPnrQueryHandler(IFlightReservationRepository repository)
    {
        _repository = repository;
    }

    public async Task<FlightReservationDto?> Handle(GetFlightReservationByPnrQuery request, CancellationToken cancellationToken)
    {
        var reservation = await _repository.GetByPnrAsync(request.Pnr, cancellationToken);
        
        if (reservation == null)
            return null;

        return new FlightReservationDto(
            reservation.Id,
            reservation.PassengerId,
            reservation.Pnr,
            reservation.FlightNumber,
            reservation.DepartureTime,
            reservation.Origin,
            reservation.Destination,
            reservation.Status.ToString(),
            reservation.CheckInTime
        );
    }
}
