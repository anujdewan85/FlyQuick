using FluentValidation;
using Passenger.Domain.Entities;

namespace Passenger.Application.Features.FlightReservations.Validators;

public class PassengerFlightReservationValidator : AbstractValidator<PassengerFlightReservation>
{
    public PassengerFlightReservationValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 10)
            .WithMessage("PNR must be between 6 and 10 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("PNR must contain only uppercase letters and numbers");

        RuleFor(x => x.PassengerId)
            .NotEmpty()
            .WithMessage("Passenger ID is required");

        RuleFor(x => x.FlightNumber)
            .NotEmpty()
            .WithMessage("Flight number is required")
            .MaximumLength(10)
            .WithMessage("Flight number cannot exceed 10 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("Flight number must contain only uppercase letters and numbers");

        RuleFor(x => x.Origin)
            .NotEmpty()
            .WithMessage("Origin is required")
            .Length(3)
            .WithMessage("Origin must be exactly 3 characters")
            .Matches("^[A-Z]+$")
            .WithMessage("Origin must contain only uppercase letters");

        RuleFor(x => x.Destination)
            .NotEmpty()
            .WithMessage("Destination is required")
            .Length(3)
            .WithMessage("Destination must be exactly 3 characters")
            .Matches("^[A-Z]+$")
            .WithMessage("Destination must contain only uppercase letters");

        RuleFor(x => x.DepartureTime)
            .GreaterThan(DateTime.UtcNow.AddMinutes(-30))
            .WithMessage("Departure time cannot be more than 30 minutes in the past");

        RuleFor(x => x.Origin)
            .NotEqual(x => x.Destination)
            .WithMessage("Origin and destination cannot be the same");

        RuleFor(x => x.SeatNumber)
            .Matches("^[0-9]{1,3}[A-F]$")
            .WithMessage("Seat number must be in format like '12A', '15B', etc.")
            .When(x => !string.IsNullOrEmpty(x.SeatNumber));
    }
}
