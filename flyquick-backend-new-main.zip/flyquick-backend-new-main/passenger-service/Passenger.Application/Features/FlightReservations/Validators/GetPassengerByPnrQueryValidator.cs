using FluentValidation;
using Passenger.Application.Features.FlightReservations.Queries;

namespace Passenger.Application.Features.FlightReservations.Validators;

public class GetFlightReservationByPnrQueryValidator : AbstractValidator<GetFlightReservationByPnrQuery>
{
    public GetFlightReservationByPnrQueryValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 10)
            .WithMessage("PNR must be between 6 and 10 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("PNR must contain only uppercase letters and numbers");
    }
}
