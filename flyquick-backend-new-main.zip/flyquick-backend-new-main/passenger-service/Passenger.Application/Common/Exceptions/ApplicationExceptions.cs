namespace Passenger.Application.Common.Exceptions;

public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message) { }
    
    public NotFoundException(string name, object key) 
        : base($"Entity \"{name}\" ({key}) was not found.") { }
}

public class ValidationException : Exception
{
    public ValidationException(string message) : base(message) { }
    
    public ValidationException(IEnumerable<string> failures)
        : base("One or more validation failures have occurred.")
    {
        Failures = failures.ToList();
    }
    
    public IReadOnlyList<string> Failures { get; } = new List<string>();
}
