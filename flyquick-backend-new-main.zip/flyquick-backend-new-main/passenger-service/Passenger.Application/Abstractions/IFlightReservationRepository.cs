using Passenger.Domain.Entities;

namespace Passenger.Application.Abstractions;

/// <summary>
/// Repository interface for flight reservation operations
/// </summary>
public interface IFlightReservationRepository
{
    Task<PassengerFlightReservation?> GetByIdAsync(string reservationId, CancellationToken cancellationToken = default);
    Task<PassengerFlightReservation?> GetByPnrAsync(string pnr, CancellationToken cancellationToken = default);
    Task<PassengerFlightReservation?> GetByPnrAndLastNameAsync(string pnr, string lastName, CancellationToken cancellationToken = default);
    Task<IEnumerable<PassengerFlightReservation>> GetByPassengerIdAsync(string passengerId, CancellationToken cancellationToken = default);
    Task<PassengerFlightReservation> AddAsync(PassengerFlightReservation reservation, CancellationToken cancellationToken = default);
    Task<PassengerFlightReservation> UpdateAsync(PassengerFlightReservation reservation, CancellationToken cancellationToken = default);
    Task DeleteAsync(string reservationId, CancellationToken cancellationToken = default);
}
