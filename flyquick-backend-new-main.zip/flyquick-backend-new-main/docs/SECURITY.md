# Security Guide - Indigo Aviation Check-in Backend

## 🔒 Container Security

### Multi-layered Security Approach

Our containerization strategy implements defense-in-depth security:

1. **Base Image Security**
   - Red Hat UBI 8: Enterprise-grade, regularly updated base images
   - Minimal attack surface with only required packages
   - Official .NET runtime and SDK images

2. **Non-Root Execution**
   ```dockerfile
   # All containers run as non-root user 1001
   USER 1001
   RUN chown -R 1001:0 /app && chmod -R g+rwX /app
   ```

3. **File System Permissions**
   - Group-writable permissions (1001:0) for OpenShift compatibility
   - No unnecessary write permissions
   - Secrets mounted as read-only volumes

### Container Scanning

Automated security scanning integrated in CI/CD:

```yaml
# Trivy vulnerability scanning
- name: Run Trivy vulnerability scanner
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.IMAGE_NAME }}:${{ github.sha }}
    format: 'sarif'
    output: 'trivy-results.sarif'
```

## 🛡️ Application Security

### Input Validation

All API endpoints implement comprehensive input validation:

```csharp
public class CheckinStartCommand : IRequest<CheckinResponse>
{
    [Required]
    [StringLength(6, MinimumLength = 6)]
    [RegularExpression(@"^[A-Z0-9]{6}$")]
    public string Pnr { get; set; } = string.Empty;
    
    [Required]
    [StringLength(50, MinimumLength = 2)]
    public string LastName { get; set; } = string.Empty;
}
```

### Security Headers

Essential security headers implemented via middleware:

```csharp
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
    context.Response.Headers.Add("X-Frame-Options", "DENY");
    context.Response.Headers.Add("X-XSS-Protection", "1; mode=block");
    context.Response.Headers.Add("Referrer-Policy", "strict-origin-when-cross-origin");
    context.Response.Headers.Add("Content-Security-Policy", "default-src 'self'");
    await next();
});
```

### Rate Limiting

Implement rate limiting to prevent abuse:

```csharp
services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("CheckinApi", limiter =>
    {
        limiter.PermitLimit = 10;
        limiter.Window = TimeSpan.FromMinutes(1);
        limiter.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
    });
});
```

## 🔐 Secret Management

### Environment Variables

Sensitive configuration managed via environment variables:

```bash
# Database connections
DATABASE_CONNECTION_STRING=Server=...;Database=...;Trusted_Connection=true;
REDIS_CONNECTION_STRING=localhost:6379

# External API keys
NAVITAIRE_API_KEY=your-secure-api-key
NAVITAIRE_API_URL=https://api.navitaire.com

# JWT settings
JWT_SECRET_KEY=your-256-bit-secret-key
JWT_ISSUER=indigo-checkin-service
JWT_AUDIENCE=indigo-mobile-app
```

### Kubernetes Secrets

For Kubernetes deployments:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: checkin-service-secrets
type: Opaque
data:
  database-connection: <base64-encoded-connection-string>
  navitaire-api-key: <base64-encoded-api-key>
```

### Azure Key Vault Integration

For Azure deployments:

```csharp
builder.Configuration.AddAzureKeyVault(
    vaultUri: new Uri(builder.Configuration["KeyVault:VaultUri"]!),
    credential: new DefaultAzureCredential());
```

## 🚨 Security Monitoring

### Logging Security Events

Structured security logging:

```csharp
public class SecurityAuditMiddleware
{
    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        // Log authentication attempts
        if (context.Request.Path.StartsWithSegments("/api/auth"))
        {
            _logger.LogInformation("Authentication attempt from {IP} for {User}", 
                context.Connection.RemoteIpAddress, 
                context.User?.Identity?.Name ?? "anonymous");
        }
        
        await next(context);
        
        // Log unauthorized access attempts
        if (context.Response.StatusCode == 401 || context.Response.StatusCode == 403)
        {
            _logger.LogWarning("Unauthorized access attempt from {IP} to {Path}", 
                context.Connection.RemoteIpAddress, 
                context.Request.Path);
        }
    }
}
```

### Anomaly Detection

Monitor for suspicious patterns:

- Multiple failed login attempts
- Unusual API usage patterns
- Access from unexpected geographic locations
- High-volume requests from single IP

## 🔍 Vulnerability Management

### Automated Dependency Scanning

GitHub Dependabot configuration:

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "nuget"
    directory: "/"
    schedule:
      interval: "weekly"
    open-pull-requests-limit: 10
```

### Security Updates Process

1. **Automated Scanning**: Daily vulnerability scans via GitHub Security
2. **Priority Assessment**: Critical/High vulnerabilities addressed within 24/72 hours
3. **Testing**: All security updates tested in staging environment
4. **Deployment**: Emergency security updates follow expedited deployment process

## 🛠️ Secure Development Practices

### Secure Coding Guidelines

1. **Input Validation**
   - Validate all inputs at API boundaries
   - Use parameterized queries for database access
   - Sanitize data for logging output

2. **Error Handling**
   ```csharp
   try
   {
       // Risky operation
   }
   catch (Exception ex)
   {
       // Log full exception details securely
       _logger.LogError(ex, "Error processing request {RequestId}", requestId);
       
       // Return generic error to client
       return Problem("An error occurred processing your request");
   }
   ```

3. **Authentication & Authorization**
   ```csharp
   [Authorize(Policy = "CheckinOperator")]
   [HttpPost("start")]
   public async Task<IActionResult> StartCheckin([FromBody] CheckinStartCommand command)
   {
       // Implementation
   }
   ```

### Code Review Security Checklist

- [ ] No hardcoded secrets or credentials
- [ ] Input validation implemented
- [ ] SQL injection prevention (parameterized queries)
- [ ] XSS prevention (output encoding)
- [ ] Authentication/authorization checks
- [ ] Error handling doesn't leak sensitive information
- [ ] Logging doesn't include PII or secrets

## 🚀 Deployment Security

### Container Registry Security

```yaml
# Push to secure container registry
- name: Build and push Docker image
  uses: docker/build-push-action@v5
  with:
    context: .
    push: true
    tags: ghcr.io/your-org/indigo-checkin:${{ github.sha }}
    # Sign container images
    provenance: true
    sbom: true
```

### Network Security

1. **Service Mesh**: Implement Istio/Linkerd for mTLS between services
2. **Network Policies**: Kubernetes NetworkPolicies to restrict traffic
3. **API Gateway**: Centralized authentication and rate limiting

### Infrastructure as Code Security

```yaml
# Terraform security scanning
- name: Run Checkov
  uses: bridgecrewio/checkov-action@master
  with:
    directory: terraform/
    framework: terraform
    output_format: sarif
```

## 🔧 Security Configuration

### Redis Security

```bash
# Redis configuration for production
requirepass your-secure-redis-password
bind 127.0.0.1
port 6379
tcp-keepalive 60
maxmemory-policy allkeys-lru
```

### Database Security

```sql
-- Create dedicated service accounts with minimal permissions
CREATE LOGIN checkin_service WITH PASSWORD = 'SecurePassword123!';
CREATE USER checkin_service FOR LOGIN checkin_service;

-- Grant minimal required permissions
GRANT SELECT, INSERT, UPDATE ON checkin_data TO checkin_service;
```

## 📋 Security Compliance

### GDPR Compliance

1. **Data Minimization**: Only collect necessary passenger data
2. **Data Retention**: Implement automatic data purging policies
3. **Right to be Forgotten**: API endpoints for data deletion
4. **Consent Management**: Track and respect user consent preferences

### PCI DSS Considerations

While not storing credit card data directly:

1. **Network Segmentation**: Isolate payment processing components
2. **Access Controls**: Implement role-based access control
3. **Audit Logging**: Comprehensive audit trails for all transactions
4. **Encryption**: Encrypt sensitive data in transit and at rest

## 🚨 Incident Response

### Security Incident Playbook

1. **Detection**: Automated alerting via monitoring systems
2. **Assessment**: Evaluate scope and impact of security incident
3. **Containment**: Isolate affected systems and prevent spread
4. **Communication**: Notify stakeholders and customers as required
5. **Recovery**: Restore normal operations with security fixes
6. **Lessons Learned**: Post-incident review and process improvements

### Emergency Contacts

- **Security Team**: security@indigo-aviation.com
- **On-call Engineer**: +1-xxx-xxx-xxxx
- **Management Escalation**: management@indigo-aviation.com

## 📚 Security Resources

### Training & Education

- OWASP Top 10 awareness training
- Secure coding practices workshops
- Container security best practices
- Cloud security fundamentals

### Tools & References

- **OWASP**: https://owasp.org/
- **NIST Cybersecurity Framework**: https://www.nist.gov/cyberframework
- **Container Security**: https://kubernetes.io/docs/concepts/security/
- **Azure Security Center**: https://azure.microsoft.com/en-us/services/security-center/

---

**Security is everyone's responsibility. Stay vigilant, stay secure! 🔐**
