#!/bin/bash

# Aviation Microservices Development Setup Script
set -e

echo "🚀 Aviation Microservices Development Setup"
echo "============================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check .NET 8
    if command -v dotnet &> /dev/null; then
        DOTNET_VERSION=$(dotnet --version | cut -d'.' -f1)
        if [ "$DOTNET_VERSION" == "8" ]; then
            print_success ".NET 8 SDK found"
        else
            print_error ".NET 8 SDK required. Current version: $(dotnet --version)"
            exit 1
        fi
    else
        print_error ".NET SDK not found. Please install .NET 8 SDK."
        exit 1
    fi
    
    # Check Podman
    if command -v podman &> /dev/null; then
        print_success "Podman found"
    else
        print_warning "Podman not found. Docker can be used as alternative."
    fi
    
    # Check Podman Compose
    if command -v podman-compose &> /dev/null; then
        print_success "Podman Compose found"
    elif command -v docker-compose &> /dev/null; then
        print_success "Docker Compose found"
        COMPOSE_CMD="docker-compose"
    else
        print_warning "Neither podman-compose nor docker-compose found."
        COMPOSE_CMD="podman-compose"
    fi
}

# Setup function
setup() {
    print_status "Setting up development environment..."
    
    # Restore .NET dependencies
    print_status "Restoring .NET dependencies..."
    dotnet restore
    
    if [ $? -eq 0 ]; then
        print_success "Dependencies restored successfully"
    else
        print_error "Failed to restore dependencies"
        exit 1
    fi
    
    # Install global tools
    print_status "Installing global .NET tools..."
    dotnet tool install --global dotnet-ef --skip-existing
    dotnet tool install --global Husky --skip-existing
    dotnet tool install --global dotnet-format --skip-existing
    
    print_success "Global tools installed"
}

# Build function
build() {
    print_status "Building solution..."
    dotnet build --configuration Release --verbosity minimal
    
    if [ $? -eq 0 ]; then
        print_success "Build completed successfully"
    else
        print_error "Build failed"
        exit 1
    fi
}

# Test function
test() {
    print_status "Running tests..."
    
    # Unit tests
    print_status "Running unit tests..."
    dotnet test tests/Checkin.UnitTests/ --verbosity minimal
    
    # Integration tests (if containers are available)
    if command -v podman &> /dev/null || command -v docker &> /dev/null; then
        print_status "Running integration tests..."
        dotnet test tests/Checkin.IntegrationTests/ --verbosity minimal
        
        print_status "Running acceptance tests..."
        dotnet test tests/Checkin.AcceptanceTests/ --verbosity minimal
    else
        print_warning "Skipping integration tests - container runtime not available"
    fi
    
    print_success "Tests completed"
}

# Format function
format() {
    print_status "Formatting code..."
    dotnet format --verify-no-changes --verbosity minimal
    
    if [ $? -eq 0 ]; then
        print_success "Code formatting verified"
    else
        print_warning "Code formatting issues found. Run 'dotnet format' to fix."
    fi
}

# Container functions
start_infrastructure() {
    print_status "Starting infrastructure services..."
    ${COMPOSE_CMD:-podman-compose} up -d redis rabbitmq seq
    
    print_status "Waiting for services to be ready..."
    sleep 10
    
    print_success "Infrastructure services started"
    print_status "Services available at:"
    echo "  - Redis: localhost:6379"
    echo "  - RabbitMQ: localhost:5672 (Management: localhost:15672)"
    echo "  - Seq: localhost:5341"
}

start_services() {
    print_status "Starting all services with containers..."
    ${COMPOSE_CMD:-podman-compose} up --build -d
    
    print_status "Waiting for services to be ready..."
    sleep 15
    
    print_success "All services started"
    print_status "Services available at:"
    echo "  - Checkin API: http://localhost:5001 (Swagger: http://localhost:5001/swagger)"
    echo "  - Passenger API: http://localhost:5002 (Swagger: http://localhost:5002/swagger)"
    echo "  - Journey API: http://localhost:5003 (Swagger: http://localhost:5003/swagger)"
    echo "  - UserJourney API: http://localhost:5004 (Swagger: http://localhost:5004/swagger)"
    echo "  - Health Check UI: http://localhost:8080"
}

stop_services() {
    print_status "Stopping all services..."
    ${COMPOSE_CMD:-podman-compose} down
    print_success "Services stopped"
}

# Main script logic
case "${1:-help}" in
    "check")
        check_prerequisites
        ;;
    "setup")
        check_prerequisites
        setup
        ;;
    "build")
        check_prerequisites
        build
        ;;
    "test")
        check_prerequisites
        test
        ;;
    "format")
        format
        ;;
    "start-infra")
        check_prerequisites
        start_infrastructure
        ;;
    "start")
        check_prerequisites
        start_services
        ;;
    "stop")
        stop_services
        ;;
    "dev")
        check_prerequisites
        setup
        build
        format
        test
        start_infrastructure
        print_success "Development environment ready!"
        print_status "You can now run individual services with 'dotnet run' in their respective directories."
        ;;
    "full")
        check_prerequisites
        setup
        build
        format
        test
        start_services
        print_success "Full environment started!"
        ;;
    "help"|*)
        echo "Aviation Microservices Development Script"
        echo ""
        echo "Usage: $0 [command]"
        echo ""
        echo "Commands:"
        echo "  check        - Check prerequisites"
        echo "  setup        - Setup development environment"
        echo "  build        - Build the solution"
        echo "  test         - Run all tests"
        echo "  format       - Check code formatting"
        echo "  start-infra  - Start infrastructure services only"
        echo "  start        - Start all services with containers"
        echo "  stop         - Stop all services"
        echo "  dev          - Setup development environment (infra only)"
        echo "  full         - Full setup and start all services"
        echo "  help         - Show this help"
        echo ""
        echo "Examples:"
        echo "  $0 dev       # Setup for local development"
        echo "  $0 full      # Complete setup with containers"
        echo "  $0 test      # Run all tests"
        ;;
esac
