using MediatR;
using Microsoft.Extensions.Logging;
using Checkin.Domain.Entities;

namespace Checkin.Application.Features.Checkin.Queries;

public record GetCheckinStatusQuery(string Pnr) : IRequest<CheckinStatusResult>;

public class GetCheckinStatusQueryHandler : IRequestHandler<GetCheckinStatusQuery, CheckinStatusResult>
{
    private readonly ILogger<GetCheckinStatusQueryHandler> _logger;

    public GetCheckinStatusQueryHandler(ILogger<GetCheckinStatusQueryHandler> logger)
    {
        _logger = logger;
    }

    public async Task<CheckinStatusResult> Handle(GetCheckinStatusQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Retrieving check-in status for PNR: {Pnr}", request.Pnr);

        // Simulate status retrieval
        await Task.Delay(50, cancellationToken);

        var status = new CheckinStatusResult(
            Pnr: request.Pnr,
            Status: CheckinStatus.CheckedIn,
            CheckinTime: DateTime.UtcNow.AddMinutes(-30),
            SeatNumber: "12A"
        );

        _logger.LogInformation("Check-in status retrieved for PNR: {Pnr}, Status: {Status}", 
            request.Pnr, status.Status);

        return status;
    }
}

public record CheckinStatusResult(
    string Pnr,
    CheckinStatus Status,
    DateTime? CheckinTime,
    string? SeatNumber);
