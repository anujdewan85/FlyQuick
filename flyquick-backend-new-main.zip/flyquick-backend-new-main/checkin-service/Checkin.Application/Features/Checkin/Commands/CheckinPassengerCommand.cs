using MediatR;
using Microsoft.Extensions.Logging;
using Checkin.Domain.Entities;

namespace Checkin.Application.Features.Checkin.Commands;

public record CheckinPassengerCommand(
    string Pnr, 
    string LastName, 
    string? SeatPreference = null) : IRequest<CheckinResult>;

public class CheckinPassengerCommandHandler : IRequestHandler<CheckinPassengerCommand, CheckinResult>
{
    private readonly ILogger<CheckinPassengerCommandHandler> _logger;

    public CheckinPassengerCommandHandler(ILogger<CheckinPassengerCommandHandler> logger)
    {
        _logger = logger;
    }

    public async Task<CheckinResult> Handle(CheckinPassengerCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Starting check-in process for PNR: {Pnr}", request.Pnr);

        // Simulate workflow execution
        // In real implementation, this would trigger Elsa workflow
        await Task.Delay(100, cancellationToken);

        var checkinResult = new CheckinResult(
            Pnr: request.Pnr,
            Status: CheckinStatus.CheckedIn,
            CheckinTime: DateTime.UtcNow,
            SeatNumber: request.SeatPreference ?? "12A",
            BoardingPass: GenerateBoardingPassId()
        );

        _logger.LogInformation("Check-in completed for PNR: {Pnr}, Status: {Status}", 
            request.Pnr, checkinResult.Status);

        return checkinResult;
    }

    private static string GenerateBoardingPassId()
    {
        return $"BP{DateTime.UtcNow:yyyyMMddHHmmss}{Random.Shared.Next(1000, 9999)}";
    }
}
