using FluentValidation;

namespace Checkin.Application.Features.Checkin.Commands;

public class CheckinPassengerCommandValidator : AbstractValidator<CheckinPassengerCommand>
{
    public CheckinPassengerCommandValidator()
    {
        RuleFor(x => x.Pnr)
            .NotEmpty().WithMessage("PNR is required")
            .Length(6, 6).WithMessage("PNR must be exactly 6 characters")
            .Matches("^[A-Z0-9]+$").WithMessage("PNR must contain only uppercase letters and numbers");

        RuleFor(x => x.LastName)
            .NotEmpty().WithMessage("Last name is required")
            .MaximumLength(50).WithMessage("Last name cannot exceed 50 characters")
            .Matches("^[a-zA-Z\\s'-]+$").WithMessage("Last name contains invalid characters");

        RuleFor(x => x.SeatPreference)
            .Matches("^[0-9]{1,2}[A-F]$").WithMessage("Seat preference must be in format like '12A'")
            .When(x => !string.IsNullOrEmpty(x.SeatPreference));
    }
}
