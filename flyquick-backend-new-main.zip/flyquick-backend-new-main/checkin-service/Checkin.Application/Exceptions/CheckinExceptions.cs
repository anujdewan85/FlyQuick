namespace Checkin.Application.Exceptions;

public abstract class CheckinServiceException : Exception
{
    protected CheckinServiceException(string message) : base(message) { }
    protected CheckinServiceException(string message, Exception innerException) : base(message, innerException) { }
}

public class PnrNotFoundException : CheckinServiceException
{
    public string Pnr { get; }
    
    public PnrNotFoundException(string pnr) 
        : base($"PNR '{pnr}' not found")
    {
        Pnr = pnr;
    }
}

public class PassengerValidationException : CheckinServiceException
{
    public string LastName { get; }
    
    public PassengerValidationException(string lastName) 
        : base($"Passenger validation failed for last name '{lastName}'")
    {
        LastName = lastName;
    }
}

public class NavitaireIntegrationException : CheckinServiceException
{
    public NavitaireIntegrationException(string message, Exception innerException) 
        : base($"Navitaire PSS integration error: {message}", innerException) 
    {
    }
}

public class CheckinWorkflowException : CheckinServiceException
{
    public string WorkflowId { get; }
    
    public CheckinWorkflowException(string workflowId, string message) 
        : base($"Workflow {workflowId} error: {message}")
    {
        WorkflowId = workflowId;
    }
}

public class SeatNotAvailableException : CheckinServiceException
{
    public string SeatNumber { get; }
    
    public SeatNotAvailableException(string seatNumber)
        : base($"Seat '{seatNumber}' is not available")
    {
        SeatNumber = seatNumber;
    }
}
