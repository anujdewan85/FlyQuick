using Checkin.Domain.Entities;
using Refit;

namespace Checkin.Infrastructure.Services;

public interface IPassengerApiClient
{
    [Get("/api/passengers/pnr/{pnr}")]
    Task<PassengerApiResponse> GetPassengerByPnrAsync(string pnr, [Query] string lastName, CancellationToken cancellationToken = default);
    
    [Put("/api/passengers/{pnr}/checkin-status")]
    Task<PassengerApiResponse> UpdateCheckinStatusAsync(string pnr, [Body] UpdateCheckinStatusRequest request, CancellationToken cancellationToken = default);
}

public interface IJourneyApiClient
{
    [Get("/api/flights/{flightNumber}")]
    Task<FlightApiResponse> GetFlightAsync(string flightNumber, [Query] string departureDate, CancellationToken cancellationToken = default);
    
    [Get("/api/flights/{flightNumber}/seats")]
    Task<SeatsApiResponse> GetAvailableSeatsAsync(string flightNumber, CancellationToken cancellationToken = default);
    
    [Post("/api/flights/{flightNumber}/seats/{seatNumber}/assign")]
    Task<SeatAssignmentResponse> AssignSeatAsync(string flightNumber, string seatNumber, [Body] AssignSeatRequest request, CancellationToken cancellationToken = default);
}

// API Response models
public record PassengerApiResponse(
    string Pnr,
    string LastName,
    string FirstName,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);

public record FlightApiResponse(
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Aircraft,
    string Gate);

public record SeatsApiResponse(
    string FlightNumber,
    SeatApiModel[] AvailableSeats);

public record SeatApiModel(
    string SeatNumber,
    string SeatType,
    bool IsAvailable,
    decimal? Price);

public record SeatAssignmentResponse(
    string Pnr,
    string SeatNumber,
    bool Success);

// API Request models
public record UpdateCheckinStatusRequest(string Status);
public record AssignSeatRequest(string Pnr);
