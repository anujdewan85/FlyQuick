using Checkin.Application.Exceptions;
using Checkin.Domain.Entities;
using Checkin.Domain.Interfaces;
using Microsoft.Extensions.Logging;
using Refit;

namespace Checkin.Infrastructure.Services;

public class PassengerServiceClient : IPassengerService
{
    private readonly IPassengerApiClient _apiClient;
    private readonly ICacheService _cacheService;
    private readonly ILogger<PassengerServiceClient> _logger;

    public PassengerServiceClient(
        IPassengerApiClient apiClient, 
        ICacheService cacheService,
        ILogger<PassengerServiceClient> logger)
    {
        _apiClient = apiClient;
        _cacheService = cacheService;
        _logger = logger;
    }

    public async Task<PassengerData> GetPassengerByPnrAsync(string pnr, string lastName, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"passenger_{pnr}_{lastName}";
        
        var cachedPassenger = await _cacheService.GetAsync<PassengerData>(cacheKey, cancellationToken);
        if (cachedPassenger != null)
        {
            _logger.LogDebug("Retrieved passenger from cache for PNR: {Pnr}", pnr);
            return cachedPassenger;
        }

        try
        {
            var response = await _apiClient.GetPassengerByPnrAsync(pnr, lastName, cancellationToken);
            
            var passenger = new PassengerData(
                response.Pnr,
                response.LastName,
                response.FirstName,
                response.FlightNumber,
                response.DepartureTime,
                response.Origin,
                response.Destination,
                Enum.Parse<CheckinStatus>(response.Status)
            );

            await _cacheService.SetAsync(cacheKey, passenger, TimeSpan.FromMinutes(15), cancellationToken);
            
            _logger.LogInformation("Retrieved passenger data for PNR: {Pnr}", pnr);
            return passenger;
        }
        catch (ApiException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            throw new PnrNotFoundException(pnr);
        }
        catch (Exception ex)
        {
            throw new NavitaireIntegrationException("Failed to retrieve passenger data", ex);
        }
    }

    public async Task<bool> ValidatePassengerAsync(PassengerData passenger, CancellationToken cancellationToken = default)
    {
        // Implement passenger validation logic
        await Task.Delay(10, cancellationToken); // Simulate validation
        
        return passenger.Status == CheckinStatus.Eligible;
    }

    public async Task<PassengerData> UpdateCheckinStatusAsync(string pnr, CheckinStatus status, CancellationToken cancellationToken = default)
    {
        try
        {
            var request = new UpdateCheckinStatusRequest(status.ToString());
            var response = await _apiClient.UpdateCheckinStatusAsync(pnr, request, cancellationToken);
            
            var passenger = new PassengerData(
                response.Pnr,
                response.LastName,
                response.FirstName,
                response.FlightNumber,
                response.DepartureTime,
                response.Origin,
                response.Destination,
                Enum.Parse<CheckinStatus>(response.Status)
            );

            _logger.LogInformation("Updated check-in status for PNR: {Pnr} to {Status}", pnr, status);
            return passenger;
        }
        catch (Exception ex)
        {
            throw new NavitaireIntegrationException("Failed to update check-in status", ex);
        }
    }
}
