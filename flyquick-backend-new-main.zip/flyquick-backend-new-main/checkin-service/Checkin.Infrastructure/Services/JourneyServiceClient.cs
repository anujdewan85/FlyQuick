using Checkin.Application.Exceptions;
using Checkin.Domain.Entities;
using Checkin.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace Checkin.Infrastructure.Services;

public class JourneyServiceClient : IJourneyService
{
    private readonly IJourneyApiClient _apiClient;
    private readonly ICacheService _cacheService;
    private readonly ILogger<JourneyServiceClient> _logger;

    public JourneyServiceClient(
        IJourneyApiClient apiClient,
        ICacheService cacheService,
        ILogger<JourneyServiceClient> logger)
    {
        _apiClient = apiClient;
        _cacheService = cacheService;
        _logger = logger;
    }

    public async Task<FlightInfo> GetFlightInfoAsync(string flightNumber, DateTime departureDate, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"flight_{flightNumber}_{departureDate:yyyyMMdd}";
        
        var cachedFlight = await _cacheService.GetAsync<FlightInfo>(cacheKey, cancellationToken);
        if (cachedFlight != null)
        {
            _logger.LogDebug("Retrieved flight info from cache for flight: {FlightNumber}", flightNumber);
            return cachedFlight;
        }

        try
        {
            var response = await _apiClient.GetFlightAsync(flightNumber, departureDate.ToString("yyyy-MM-dd"), cancellationToken);
            
            var flightInfo = new FlightInfo(
                response.FlightNumber,
                response.DepartureTime,
                response.Origin,
                response.Destination,
                response.Aircraft,
                response.Gate
            );

            await _cacheService.SetAsync(cacheKey, flightInfo, TimeSpan.FromHours(1), cancellationToken);
            
            _logger.LogInformation("Retrieved flight info for flight: {FlightNumber}", flightNumber);
            return flightInfo;
        }
        catch (Exception ex)
        {
            throw new NavitaireIntegrationException("Failed to retrieve flight information", ex);
        }
    }

    public async Task<IEnumerable<SeatInfo>> GetAvailableSeatsAsync(string flightNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            var response = await _apiClient.GetAvailableSeatsAsync(flightNumber, cancellationToken);
            
            var seats = response.AvailableSeats.Select(s => new SeatInfo(
                s.SeatNumber,
                s.SeatType,
                s.IsAvailable,
                s.Price
            ));

            _logger.LogInformation("Retrieved {Count} available seats for flight: {FlightNumber}", 
                seats.Count(), flightNumber);
            
            return seats;
        }
        catch (Exception ex)
        {
            throw new NavitaireIntegrationException("Failed to retrieve available seats", ex);
        }
    }

    public async Task<SeatInfo> AssignSeatAsync(string pnr, string seatNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            // Extract flight number from PNR context (simplified for demo)
            var flightNumber = "6E123"; // In real scenario, get from context
            
            var request = new AssignSeatRequest(pnr);
            var response = await _apiClient.AssignSeatAsync(flightNumber, seatNumber, request, cancellationToken);
            
            if (!response.Success)
            {
                throw new SeatNotAvailableException(seatNumber);
            }

            var seatInfo = new SeatInfo(seatNumber, "Economy", false);
            
            _logger.LogInformation("Assigned seat {SeatNumber} to PNR: {Pnr}", seatNumber, pnr);
            return seatInfo;
        }
        catch (SeatNotAvailableException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new NavitaireIntegrationException("Failed to assign seat", ex);
        }
    }
}
