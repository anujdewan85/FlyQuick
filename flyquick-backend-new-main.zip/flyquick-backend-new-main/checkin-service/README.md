# Checkin Service

A production-ready .NET 8 microservice for passenger check-in with Elsa workflow orchestration.

## 🏗️ Architecture

This service follows Clean Architecture principles:

```
checkin-service/
├── Checkin.API/              # API layer with Carter endpoints
├── Checkin.Application/      # Business logic with MediatR/CQRS
├── Checkin.Domain/          # Domain entities and interfaces
├── Checkin.Infrastructure/  # External services & data access
├── tests/
│   ├── Checkin.UnitTests/
│   ├── Checkin.IntegrationTests/
│   └── Checkin.AcceptanceTests/
├── Containerfile
├── compose.yml              # Service-specific compose file
├── .devcontainer/
└── README.md
```

## 🚀 Features

- **Elsa Workflow Engine** for check-in process orchestration
- **Carter Minimal APIs** for lightweight HTTP endpoints
- **MediatR CQRS** pattern for command/query separation
- **FluentValidation** for input validation
- **Polly** for resilience patterns
- **Redis** for distributed caching
- **Comprehensive Testing** (Unit, Integration, BDD)

## 🔌 API Endpoints

- `POST /api/checkin` - Check-in passenger
- `GET /api/checkin/status/{pnr}` - Get check-in status
- `POST /api/checkin/boarding-pass/{pnr}` - Generate boarding pass
- `GET /health` - Health check

## 🚀 Getting Started

### Prerequisites
- .NET 8 SDK
- Podman/Docker
- Redis (for caching)

### Run Locally

```bash
# Start dependencies
podman-compose up -d redis

# Run the service
dotnet run --project Checkin.API

# Service will be available at http://localhost:5001
# Swagger UI: http://localhost:5001/swagger
```

### Run with Containers

```bash
# Build and run with compose
podman-compose up --build

# Service available at http://localhost:5001
```

### Run Tests

```bash
# Unit tests
dotnet test tests/Checkin.UnitTests/

# Integration tests
dotnet test tests/Checkin.IntegrationTests/

# BDD Acceptance tests
dotnet test tests/Checkin.AcceptanceTests/
```

## 📋 Configuration

Key configuration settings (via environment variables or appsettings.json):

```json
{
  "ConnectionStrings": {
    "Redis": "localhost:6379"
  },
  "Services": {
    "PassengerService": "http://localhost:5002",
    "JourneyService": "http://localhost:5003"
  },
  "Elsa": {
    "Features": {
      "Workflows": {
        "Runtime": true,
        "Management": true
      }
    }
  }
}
```

## 🔄 Workflows

The service uses Elsa workflows for the check-in process:

1. **Retrieve Passenger Data** - Get passenger info from Passenger Service
2. **Validate Check-in Eligibility** - Business rules validation
3. **Update Check-in Status** - Update passenger status
4. **Generate Boarding Pass** - Create boarding pass with QR code

## 🏥 Health Checks

- `/health` - Basic health check
- `/health/ready` - Readiness probe
- `/health/live` - Liveness probe

Health checks validate:
- Service availability
- External dependencies (Passenger/Journey services)
- Cache connectivity (Redis)

## 🔧 Development

### Code Quality
```bash
# Format code
dotnet format

# Build with warnings as errors
dotnet build --warnaserror

# Run static analysis
dotnet build --verbosity normal
```

### Debugging
- Launch profiles configured for ports 5001 (HTTP) and 7001 (HTTPS)
- VS Code launch configurations included
- Structured logging with Serilog

## 📊 Monitoring

- **Structured Logging**: Serilog with Seq integration
- **OpenTelemetry**: Distributed tracing ready
- **Health Check UI**: Integrated monitoring dashboard

## 🔐 Security

- JWT Bearer authentication support
- Input validation with FluentValidation
- Rate limiting configured
- Non-root container execution

## 🐳 Container

Uses Red Hat UBI 8 base images for security and compliance:
- Multi-stage build optimization
- Non-root user execution
- Health check integration
- Proper layer caching

## 🤝 Dependencies

**External Services**:
- Passenger Service (http://localhost:5002)
- Journey Service (http://localhost:5003)
- Redis Cache (localhost:6379)

**Message Bus**:
- Can integrate with RabbitMQ via MassTransit (optional)

## 📝 API Documentation

Full OpenAPI/Swagger documentation available at `/swagger` when running in development mode.

## 🚦 Status

✅ Production Ready
- Comprehensive error handling
- Logging and monitoring
- Health checks
- Security best practices
- Container ready
- Test coverage >80%
