namespace Checkin.Domain.Entities;

public enum CheckinStatus
{
    NotEligible = 0,
    Eligible = 1,
    CheckedIn = 2,
    Closed = 3
}

public record PassengerData(
    string Pnr,
    string LastName,
    string FirstName,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    CheckinStatus Status = CheckinStatus.NotEligible);

public record CheckinResult(
    string Pnr,
    CheckinStatus Status,
    DateTime CheckinTime,
    string? SeatNumber = null,
    string? BoardingPass = null);

public record FlightInfo(
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Aircraft,
    string Gate);

public record SeatInfo(
    string SeatNumber,
    string SeatType,
    bool IsAvailable,
    decimal? Price = null);

public record BoardingPass(
    string BoardingPassId,
    string Pnr,
    string PassengerName,
    string FlightNumber,
    DateTime DepartureTime,
    string SeatNumber,
    string Gate,
    DateTime BoardingTime,
    string QrCode);
