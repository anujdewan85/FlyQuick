using Checkin.Domain.Entities;

namespace Checkin.Domain.Interfaces;

public interface IPassengerService
{
    Task<PassengerData> GetPassengerByPnrAsync(string pnr, string lastName, CancellationToken cancellationToken = default);
    Task<bool> ValidatePassengerAsync(PassengerData passenger, CancellationToken cancellationToken = default);
    Task<PassengerData> UpdateCheckinStatusAsync(string pnr, CheckinStatus status, CancellationToken cancellationToken = default);
}

public interface IJourneyService
{
    Task<FlightInfo> GetFlightInfoAsync(string flightNumber, DateTime departureDate, CancellationToken cancellationToken = default);
    Task<IEnumerable<SeatInfo>> GetAvailableSeatsAsync(string flightNumber, CancellationToken cancellationToken = default);
    Task<SeatInfo> AssignSeatAsync(string pnr, string seatNumber, CancellationToken cancellationToken = default);
}

public interface IBoardingPassService
{
    Task<BoardingPass> GenerateBoardingPassAsync(PassengerData passenger, string seatNumber, string gate, CancellationToken cancellationToken = default);
    Task<string> GenerateQrCodeAsync(BoardingPass boardingPass, CancellationToken cancellationToken = default);
}

public interface ICheckinRepository
{
    Task<CheckinResult?> GetCheckinResultAsync(string pnr, CancellationToken cancellationToken = default);
    Task<CheckinResult> SaveCheckinResultAsync(CheckinResult checkinResult, CancellationToken cancellationToken = default);
    Task<bool> DeleteCheckinResultAsync(string pnr, CancellationToken cancellationToken = default);
}

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
}
