# Contributing to Indigo Aviation Check-in Backend

Thank you for your interest in contributing to our aviation microservices project! This guide will help you get started with contributing effectively.

## 🚀 Getting Started

### Prerequisites
- .NET 8 SDK
- Docker & Docker Compose
- Git
- Visual Studio Code or Visual Studio 2022
- Redis (for local development)

### Development Environment Setup

1. **Fork and Clone**
   ```bash
   git clone https://github.com/your-username/indigo-checkin-backend.git
   cd indigo-checkin-backend
   ```

2. **Setup Development Environment**
   ```bash
   # Install .NET tools
   dotnet tool install -g dotnet-format
   dotnet tool install -g dotnet-outdated-tool
   
   # Start dependencies
   docker compose up redis -d
   ```

3. **Verify Setup**
   ```bash
   # Build all services
   dotnet build checkin-service/Checkin.API/Checkin.API.csproj
   dotnet build userjourney-service/UserJourney.API/UserJourney.API.csproj
   dotnet build journey-service/Journey.API/Journey.API.csproj
   dotnet build passenger-service/Passenger.API/Passenger.API.csproj
   ```

## 🏗️ Project Structure Understanding

### Service Architecture
Each service follows Clean Architecture with:
```
ServiceName/
├── ServiceName.API/           # Controllers, endpoints, middleware
├── ServiceName.Application/   # Use cases, CQRS handlers, DTOs
├── ServiceName.Domain/        # Entities, value objects, interfaces
├── ServiceName.Infrastructure/ # Data access, external services
└── tests/                     # Unit and integration tests
```

### Key Patterns Used
- **CQRS with MediatR**: Command Query Responsibility Segregation
- **Clean Architecture**: Domain-centric design with dependency inversion
- **Carter**: Minimal APIs for lightweight HTTP endpoints
- **Repository Pattern**: Data access abstraction
- **Circuit Breaker**: Resilience with Polly

## 🎯 Contribution Types

### 🐛 Bug Fixes
- Fix existing issues or bugs
- Add regression tests
- Update documentation if needed

### ✨ New Features
- Implement new functionality
- Add comprehensive tests (unit + integration)
- Update API documentation
- Consider backward compatibility

### 📚 Documentation
- API documentation improvements
- README updates
- Code comments and XML docs
- Architecture decision records (ADRs)

### 🔒 Security Improvements
- Vulnerability fixes
- Security best practices implementation
- Dependency updates
- Container security enhancements

### ⚡ Performance Optimizations
- Query optimization
- Caching improvements
- Resource usage optimization
- Load testing and benchmarking

## 📋 Development Guidelines

### Code Standards
- **C# Coding Standards**: Follow Microsoft C# conventions
- **EditorConfig**: Use provided .editorconfig settings
- **Naming**: Use descriptive, meaningful names
- **Documentation**: Add XML docs for public APIs
- **Async/Await**: Prefer async patterns for I/O operations

### Testing Requirements
- **Unit Tests**: Minimum 80% code coverage
- **Integration Tests**: Test service interactions
- **Contract Tests**: API contract validation
- **Performance Tests**: For critical paths

### Git Workflow
1. **Branch Naming**:
   ```
   feature/add-seat-selection
   bugfix/fix-pnr-validation
   docs/update-api-guide
   security/update-dependencies
   ```

2. **Commit Messages**: Follow Conventional Commits
   ```
   feat(checkin): add multi-passenger support
   fix(userjourney): resolve NRules memory leak
   docs(api): update swagger documentation
   security(deps): update vulnerable packages
   ```

3. **Pull Request Process**:
   - Create feature branch from `develop`
   - Keep changes focused and atomic
   - Add tests for new functionality
   - Update documentation
   - Ensure CI passes before requesting review

## 🧪 Testing Guidelines

### Unit Tests
```csharp
[Test]
public async Task Handle_ValidPnr_ReturnsPassengerData()
{
    // Arrange
    var query = new GetPassengerByPnrQuery("ABC123", "Smith");
    var handler = new GetPassengerByPnrQueryHandler();
    
    // Act
    var result = await handler.Handle(query, CancellationToken.None);
    
    // Assert
    Assert.That(result.Pnr, Is.EqualTo("ABC123"));
    Assert.That(result.LastName, Is.EqualTo("Smith"));
}
```

### Integration Tests
```csharp
[Test]
public async Task POST_Checkin_Start_Returns_Success()
{
    // Arrange
    using var factory = new WebApplicationFactory<Program>();
    var client = factory.CreateClient();
    var request = new CheckinStartCommand("ABC123", "Smith");
    
    // Act
    var response = await client.PostAsJsonAsync("/api/checkin/start", request);
    
    // Assert
    response.StatusCode.Should().Be(HttpStatusCode.OK);
}
```

### Running Tests
```bash
# Run all tests
dotnet test --collect:"XPlat Code Coverage"

# Run tests for specific service
dotnet test checkin-service/tests/ --verbosity normal

# Run with coverage report
dotnet test --collect:"XPlat Code Coverage" --results-directory ./coverage
```

## 📦 Service-Specific Guidelines

### Checkin Service
- **Workflows**: Use Elsa for complex check-in flows
- **Integration**: Navitaire PSS integration patterns
- **Caching**: Redis for temporary check-in state
- **Validation**: Comprehensive passenger validation

### UserJourney Service (NRules)
- **Business Rules**: Document rule changes thoroughly
- **Performance**: Profile rule execution for complex scenarios
- **Testing**: Test rule combinations extensively
- **Versioning**: Consider rule versioning for backward compatibility

### Journey Service
- **Mock Data**: Maintain realistic test data
- **Seat Maps**: Ensure seat map consistency
- **Capacity**: Handle edge cases (full flights, etc.)

### Passenger Service
- **Data Privacy**: Handle PII with care
- **Caching**: Cache passenger data appropriately
- **Validation**: Implement robust PNR validation

## 🔍 Code Review Process

### For Contributors
1. **Self-Review**: Review your own code before submitting
2. **Testing**: Ensure all tests pass locally
3. **Documentation**: Update relevant docs
4. **Small PRs**: Keep changes focused and reviewable

### Review Checklist
- [ ] Code follows established patterns
- [ ] Tests cover new functionality
- [ ] No security vulnerabilities introduced
- [ ] Performance implications considered
- [ ] Documentation updated
- [ ] Backward compatibility maintained

### Review Comments
- Be constructive and specific
- Suggest improvements, don't just point out problems
- Ask questions to understand context
- Appreciate good code and improvements

## 🚀 Deployment Considerations

### Docker Best Practices
- Use multi-stage builds
- Non-root user execution
- Minimal base images (UBI 8)
- Security scanning with Trivy

### Configuration Management
- Environment-specific configurations
- Secret management (avoid hardcoding)
- Feature flags for gradual rollouts

### Monitoring & Observability
- Add structured logging for new features
- Include health checks for dependencies
- Consider metrics for business logic

## 🔐 Security Considerations

### Development Security
- Never commit secrets or credentials
- Use environment variables for configuration
- Validate all inputs
- Implement proper error handling

### Dependency Management
- Regular security updates
- Vulnerability scanning
- License compliance
- Minimal dependencies

### Container Security
- Regular base image updates
- Security scanning in CI/CD
- Non-root execution
- Minimal privileges

## 🆘 Getting Help

### Resources
- **Architecture Docs**: `/docs/architecture/`
- **API Documentation**: Available at `/swagger` endpoints
- **Troubleshooting**: `/docs/troubleshooting.md`

### Communication
- **Issues**: Use GitHub Issues for bugs and feature requests
- **Discussions**: GitHub Discussions for general questions
- **Pull Requests**: For code contributions and reviews

### Support Channels
- **Email**: engineering@indigo-aviation.com
- **Slack**: #indigo-backend-dev
- **Office Hours**: Thursdays 2-4 PM UTC

## 🏆 Recognition

### Contributors
We recognize and appreciate all contributions:
- Code contributors listed in releases
- Documentation improvements acknowledged
- Bug reporters credited in release notes
- Feature requesters mentioned in implementations

### Becoming a Maintainer
Regular contributors who demonstrate:
- Deep understanding of the codebase
- High-quality contributions
- Helpful code reviews
- Community involvement

May be invited to become maintainers with additional privileges.

---

**Happy Contributing! 🚀**

Together, we're building robust, scalable aviation software that powers seamless travel experiences.
