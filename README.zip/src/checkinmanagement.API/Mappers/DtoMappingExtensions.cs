using Mapster;
using checkinmanagement.API.DTOs.Requests;
using checkinmanagement.API.DTOs.Responses;
using checkinmanagement.Application.DTOs;
using checkinmanagement.Domain.Entities;

namespace checkinmanagement.API.Mappers
{
    /// <summary>
    /// Extension methods for mapping between API and Application DTOs using Mapster
    /// </summary>
    public static class DtoMappingExtensions
    {
        /// <summary>
        /// Maps API request to Application request using Mapster
        /// </summary>
        public static Application.DTOs.RetrieveJourneyRequest ToApplicationRequest(this DTOs.Requests.RetrieveJourneyRequest apiRequest)
        {
            return apiRequest.Adapt<Application.DTOs.RetrieveJourneyRequest>();
        }

        /// <summary>
        /// Maps BookingAggregateDto to API RetrieveJourneyResponse using Mapster
        /// </summary>
        public static DTOs.Responses.RetrieveJourneyResponse ToApiJourneyListResponse(this BookingAggregateDto bookingAggregate)
        {
            if (bookingAggregate?.Journeys == null || !bookingAggregate.Journeys.Any())
            {
                return new DTOs.Responses.RetrieveJourneyResponse
                {
                    Data = new RetrieveJourneyDataWrapper
                    {
                        JourneyList = new List<RetrieveJourneyItem>()
                    }
                };
            }

            var journeyItems = bookingAggregate.Journeys.Select(journey => new RetrieveJourneyItem
            {
                JourneyKey = journey.JourneyKey,
                CheckinEligibility = new CheckinEligibilityResponse
                {
                    Status = journey.CheckinEligibility.Status,
                    Reason = journey.CheckinEligibility.Reason
                },
                CheckedinStatus = journey.CheckedinStatus,
                IsInternational = journey.IsInternational,
                IsCodeshare = journey.IsCodeshare,
                Designator = new DesignatorResponse
                {
                    Destination = journey.Designator.Destination,
                    Origin = journey.Designator.Origin,
                    UtcArrival = journey.Designator.UtcArrival,
                    UtcDeparture = journey.Designator.UtcDeparture
                }
            }).ToList();

            return new DTOs.Responses.RetrieveJourneyResponse
            {
                Data = new RetrieveJourneyDataWrapper
                {
                    JourneyList = journeyItems
                }
            };
        }

        /// <summary>
        /// Maps JourneyDto to API JourneyDetailResponse
        /// </summary>
        public static DTOs.Responses.JourneyDetailResponse ToApiJourneyDetailResponse(this JourneyDto journey)
        {
            if (journey == null)
            {
                return new DTOs.Responses.JourneyDetailResponse
                {
                    Data = new JourneyDetailDataWrapper(),
                    Errors = new { Message = "Journey not found", Code = "NOT_FOUND" }
                };
            }

            var journeyDetails = new JourneyDetailsResponse
            {
                JourneyKey = journey.JourneyKey ?? string.Empty,
                FlightType = journey.FlightType ?? string.Empty,
                Stops = journey.Stops,
                ProductClass = journey.ProductClass ?? string.Empty,
                Designator = new DesignatorResponse
                {
                    Destination = journey.Designator?.Destination ?? string.Empty,
                    Origin = journey.Designator?.Origin ?? string.Empty,
                    UtcArrival = journey.Designator?.UtcArrival ?? DateTime.MinValue,
                    UtcDeparture = journey.Designator?.UtcDeparture ?? DateTime.MinValue
                },
                Passengers = journey.Passengers?.Select(p => new PassengerResponse
                {
                    PassengerKey = p.PassengerKey ?? string.Empty,
                    PassengerTypeCode = p.PassengerTypeCode ?? string.Empty,
                    DiscountCode = p.DiscountCode ?? string.Empty,
                    ExtraseatTag = p.ExtraseatTag ?? string.Empty,
                    HasCheckedIn = (int)p.HasCheckedIn,
                    Nationality = p.Nationality ?? string.Empty,
                    Gender = p.Gender,
                    DateOfBirth = p.DateOfBirth ?? string.Empty,
                    Name = new PassengerNameResponse
                    {
                        First = p.Name?.First ?? string.Empty,
                        Middle = p.Name?.Middle ?? string.Empty,
                        Last = p.Name?.Last ?? string.Empty,
                        Title = p.Name?.Title ?? string.Empty
                    },
                    Loyalty = new LoyaltyResponse
                    {
                        Tier = p.Loyalty?.Tier ?? string.Empty,
                        FfNumber = p.Loyalty?.FfNumber ?? string.Empty
                    },
                    Infant = new InfantResponse
                    {
                        DateOfBirth = p.Infant?.DateOfBirth ?? string.Empty,
                        ResidentCountry = p.Infant?.ResidentCountry ?? string.Empty,
                        Gender = p.Infant?.Gender ?? string.Empty,
                        Name = new PassengerNameResponse
                        {
                            First = p.Infant?.Name?.First ?? string.Empty,
                            Middle = p.Infant?.Name?.Middle ?? string.Empty,
                            Last = p.Infant?.Name?.Last ?? string.Empty,
                            Title = p.Infant?.Name?.Title ?? string.Empty
                        }
                    },
                    SeatsAndSsrs = p.SeatsAndSsrs?.Select(s => new SeatAndSsrResponse
                    {
                        SegmentKey = s.SegmentKey ?? string.Empty,
                        Seats = s.Seats?.Select(seat => new SeatResponse
                        {
                            SeatUnitDesignator = seat.SeatUnitDesignator ?? string.Empty,
                            Type = seat.Type ?? string.Empty
                        }).ToList() ?? new List<SeatResponse>(),
                        Ssrs = s.Ssrs?.Select(ssr => new SsrResponse
                        {
                            SsrNumber = ssr.SsrNumber ?? string.Empty,
                            SsrDetail = ssr.SsrDetail ?? string.Empty
                        }).ToList() ?? new List<SsrResponse>()
                    }).ToList() ?? new List<SeatAndSsrResponse>()
                }).ToList() ?? new List<PassengerResponse>(),
                Segments = journey.Segments?.Select(s => new SegmentResponse
                {
                    SegmentKey = s.SegmentKey ?? string.Empty,
                    Destination = s.Destination ?? string.Empty,
                    DestinationName = s.DestinationName ?? string.Empty,
                    DestinationCityName = s.DestinationCityName ?? string.Empty,
                    Origin = s.Origin ?? string.Empty,
                    OriginName = s.OriginName ?? string.Empty,
                    OriginCityName = s.OriginCityName ?? string.Empty,
                    UtcArrival = s.UtcArrival,
                    UtcDeparture = s.UtcDeparture,
                    ProductClass = s.ProductClass ?? string.Empty,
                    IsInternational = s.IsInternational,
                    Identifier = new FlightIdentifierResponse
                    {
                        Identifier = s.Identifier?.Identifier ?? string.Empty,
                        CarrierCode = s.Identifier?.CarrierCode ?? string.Empty,
                        OpSuffix = s.Identifier?.OpSuffix ?? string.Empty
                    },
                    ExternalIdentifier = new FlightIdentifierResponse
                    {
                        Identifier = s.ExternalIdentifier?.Identifier ?? string.Empty,
                        CarrierCode = s.ExternalIdentifier?.CarrierCode ?? string.Empty,
                        OpSuffix = s.ExternalIdentifier?.OpSuffix ?? string.Empty
                    },
                    LegInfo = s.LegInfo?.Select(l => new LegInfoResponse
                    {
                        ArrivalTerminal = l.ArrivalTerminal ?? string.Empty,
                        DepartureTerminal = l.DepartureTerminal ?? string.Empty,
                        EquipmentType = l.EquipmentType ?? string.Empty,
                        EquipmentTypeSuffix = l.EquipmentTypeSuffix ?? string.Empty,
                        OnTime = l.OnTime ?? string.Empty,
                        OperatingCarrier = l.OperatingCarrier ?? string.Empty,
                        OperatingFlightNumber = l.OperatingFlightNumber ?? string.Empty
                    }).ToList() ?? new List<LegInfoResponse>()
                }).ToList() ?? new List<SegmentResponse>()
            };

            return new DTOs.Responses.JourneyDetailResponse
            {
                Data = new JourneyDetailDataWrapper
                {
                    JourneyDetails = journeyDetails
                },
                Errors = new object()
            };
        }
    }
}
