namespace checkinmanagement.API.Mappers
{
    /// <summary>
    /// Mapper class for creating custom validation error responses
    /// </summary>
    public static class ValidationErrorMapper
    {
        /// <summary>
        /// Creates a custom validation error response
        /// </summary>
        /// <param name="message">The main error message</param>
        /// <param name="code">The error code</param>
        /// <param name="validationErrors">Dictionary of field-specific validation errors</param>
        /// <returns>Custom validation error response object</returns>
        public static object ToCustomValidationErrorResponse(string message, string code, Dictionary<string, string[]> validationErrors)
        {
            return new
            {
                success = false,
                errorMessage = message,
                errorCode = code,
                timestamp = DateTime.UtcNow,
                validationErrors = validationErrors
            };
        }

        /// <summary>
        /// Creates a simple validation error response without field-specific errors
        /// </summary>
        /// <param name="message">The error message</param>
        /// <param name="code">The error code</param>
        /// <returns>Simple validation error response object</returns>
        public static object ToSimpleValidationErrorResponse(string message, string code)
        {
            return new
            {
                success = false,
                errorMessage = message,
                errorCode = code,
                timestamp = DateTime.UtcNow
            };
        }

        /// <summary>
        /// Creates a validation error response with a single field error
        /// </summary>
        /// <param name="message">The main error message</param>
        /// <param name="code">The error code</param>
        /// <param name="fieldName">The name of the field with error</param>
        /// <param name="fieldErrors">Array of error messages for the field</param>
        /// <returns>Validation error response object</returns>
        public static object ToSingleFieldValidationErrorResponse(string message, string code, string fieldName, string[] fieldErrors)
        {
            var validationErrors = new Dictionary<string, string[]>
            {
                { fieldName, fieldErrors }
            };

            return ToCustomValidationErrorResponse(message, code, validationErrors);
        }
    }
}
