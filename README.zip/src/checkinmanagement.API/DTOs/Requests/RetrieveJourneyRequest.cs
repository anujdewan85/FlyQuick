using System.Text.Json.Serialization;

namespace checkinmanagement.API.DTOs.Requests
{
    /// <summary>
    /// Request to retrieve journey information for check-in
    /// Using record type for immutability and value-based equality
    /// </summary>
    public record RetrieveJourneyRequest
    {
        /// <summary>
        /// Passenger Name Record (PNR) - 6 character booking reference
        /// </summary>
        /// <example>ABC123</example>
        public string? Pnr { get; init; }
        
        /// <summary>
        /// Passenger's last name
        /// </summary>
        /// <example>Smith</example>
        public string? LastName { get; init; }
        
        /// <summary>
        /// Passenger's email address
        /// </summary>
        /// <example>john.smith@example.com</example>
        public string? EmailId { get; init; }
        
        /// <summary>
        /// Booking reference
        /// </summary>
        /// <example>BKREF123456</example>
        public string? BookingReference { get; init; }
    }
}
