namespace checkinmanagement.API.DTOs.Responses;

/// <summary>
/// Health check response model
/// </summary>
public class HealthResponse
{
    /// <summary>
    /// Current health status of the service
    /// </summary>
    /// <example>Healthy</example>
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Timestamp when the health check was performed
    /// </summary>
    /// <example>2025-08-10T11:33:20.1144153Z</example>
    public DateTime Timestamp { get; set; }

    /// <summary>
    /// Service name
    /// </summary>
    /// <example>CheckIn Management API</example>
    public string Service { get; set; } = string.Empty;

    /// <summary>
    /// Current version of the service
    /// </summary>
    /// <example>1.0.0.0</example>
    public string Version { get; set; } = string.Empty;

    /// <summary>
    /// Current environment where the service is running
    /// </summary>
    /// <example>Development</example>
    public string Environment { get; set; } = string.Empty;
}
