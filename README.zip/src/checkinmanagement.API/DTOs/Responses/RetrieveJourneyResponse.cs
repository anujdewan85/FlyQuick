using System.Text.Json.Serialization;

namespace checkinmanagement.API.DTOs.Responses
{
    /// <summary>
    /// Response model for POST /checkin/v1/journeys/retrieve
    /// Matches exact API contract - lightweight journey list
    /// Maps from BookingAggregateDto.Journeys
    /// </summary>
    public record RetrieveJourneyResponse
    {
        public RetrieveJourneyDataWrapper Data { get; init; } = new RetrieveJourneyDataWrapper { JourneyList = [] };
        
        public object Errors { get; init; } = new object();
    }

    public record RetrieveJourneyDataWrapper
    {
        public required List<RetrieveJourneyItem> JourneyList { get; init; }
    }

    /// <summary>
    /// Simplified journey info for list endpoint - immutable record
    /// Only contains essential fields needed for journey selection
    /// </summary>
    public record RetrieveJourneyItem
    {
        /// <summary>
        /// Unique journey identifier
        /// </summary>
        /// <example>ABC123~2025-08-15~DEL~BOM~AI101</example>
        public required string JourneyKey { get; init; }
        
        /// <summary>
        /// Check-in eligibility information
        /// </summary>
        public required CheckinEligibilityResponse CheckinEligibility { get; init; }
        
        /// <summary>
        /// Current check-in status
        /// </summary>
        /// <example>None</example>
        public string CheckedinStatus { get; init; } = string.Empty;
        
        /// <summary>
        /// Indicates if this is an international journey
        /// </summary>
        public bool IsInternational { get; init; }
        
        /// <summary>
        /// Indicates if this is a codeshare flight
        /// </summary>
        public bool IsCodeshare { get; init; }
        
        /// <summary>
        /// Flight route and timing information
        /// </summary>
        public DesignatorResponse Designator { get; init; } = new DesignatorResponse();
    }

    /// <summary>
    /// Check-in eligibility status - immutable record
    /// </summary>
    public record CheckinEligibilityResponse
    {
        /// <summary>
        /// Eligibility status (eligible, noteligible, schedule)
        /// </summary>
        /// <example>eligible</example>
        public string Status { get; init; } = string.Empty;
        
        /// <summary>
        /// Human-readable reason for the status
        /// </summary>
        /// <example>Check-in is available</example>
        public string Reason { get; init; } = string.Empty;
    }

    /// <summary>
    /// Flight route designator - immutable record with validation
    /// </summary>
    public record DesignatorResponse
    {
        /// <summary>
        /// Destination airport code
        /// </summary>
        /// <example>BOM</example>
        public string Destination { get; init; } = string.Empty;
        
        /// <summary>
        /// Origin airport code
        /// </summary>
        /// <example>DEL</example>
        public string Origin { get; init; } = string.Empty;
        
        /// <summary>
        /// Arrival time in UTC
        /// </summary>
        /// <example>2025-08-15T12:00:00Z</example>
        public DateTime UtcArrival { get; init; }
        
        /// <summary>
        /// Departure time in UTC
        /// </summary>
        /// <example>2025-08-15T10:30:00Z</example>
        public DateTime UtcDeparture { get; init; }
    }

    /// <summary>
    /// Response model for GET /checkin/v1/journey/{journeyKey}
    /// Matches exact API contract - complete journey details
    /// Maps from single JourneyDto from BookingAggregateDto
    /// </summary>
    public class JourneyDetailResponse
    {
        public JourneyDetailDataWrapper Data { get; set; } = new JourneyDetailDataWrapper();
        public object Errors { get; set; } = new object();
    }

    public class JourneyDetailDataWrapper
    {
        public JourneyDetailsResponse JourneyDetails { get; set; }
    }

    /// <summary>
    /// Complete journey information for detail endpoint
    /// Contains all passengers, segments, and related data
    /// </summary>
    public class JourneyDetailsResponse
    {
        public string JourneyKey { get; set; }
        public string FlightType { get; set; }
        public int Stops { get; set; }
        public string ProductClass { get; set; }
        public DesignatorResponse Designator { get; set; }
        public List<PassengerResponse> Passengers { get; set; } = new List<PassengerResponse>();
        public List<SegmentResponse> Segments { get; set; } = new List<SegmentResponse>();
    }

    public class PassengerResponse
    {
        public LoyaltyResponse Loyalty { get; set; }
        public string ExtraseatTag { get; set; }
        public string PassengerKey { get; set; }
        public int HasCheckedIn { get; set; }
        public PassengerNameResponse Name { get; set; }
        public string PassengerTypeCode { get; set; }
        public string DiscountCode { get; set; }
        public InfantResponse Infant { get; set; }
        public string Nationality { get; set; }
        public int Gender { get; set; }
        public string DateOfBirth { get; set; }
        public List<SeatAndSsrResponse> SeatsAndSsrs { get; set; } = new List<SeatAndSsrResponse>();
    }

    public class PassengerNameResponse
    {
        public string First { get; set; }
        public string Middle { get; set; }
        public string Last { get; set; }
        public string Title { get; set; }
    }

    public class LoyaltyResponse
    {
        public string Tier { get; set; }
        public string FfNumber { get; set; }
    }

    public class InfantResponse
    {
        public string DateOfBirth { get; set; }
        public string ResidentCountry { get; set; }
        public string Gender { get; set; }
        public PassengerNameResponse Name { get; set; }
    }

    public class SeatAndSsrResponse
    {
        public string SegmentKey { get; set; }
        public List<SeatResponse> Seats { get; set; } = new List<SeatResponse>();
        public List<SsrResponse> Ssrs { get; set; } = new List<SsrResponse>();
    }

    public class SeatResponse
    {
        public string SeatUnitDesignator { get; set; }
        public string Type { get; set; }
    }

    public class SsrResponse
    {
        public string SsrNumber { get; set; }
        public string SsrDetail { get; set; }
    }

    public class SegmentResponse
    {
        public string Destination { get; set; }
        public string DestinationName { get; set; }
        public string DestinationCityName { get; set; }
        public string Origin { get; set; }
        public string OriginName { get; set; }
        public string OriginCityName { get; set; }
        public DateTime UtcArrival { get; set; }
        public DateTime UtcDeparture { get; set; }
        public FlightIdentifierResponse Identifier { get; set; }
        public string ProductClass { get; set; }
        public string SegmentKey { get; set; }
        public bool IsInternational { get; set; }
        public FlightIdentifierResponse ExternalIdentifier { get; set; }
        public List<LegInfoResponse> LegInfo { get; set; } = new List<LegInfoResponse>();
    }

    public class FlightIdentifierResponse
    {
        public string Identifier { get; set; }
        public string CarrierCode { get; set; }
        public string OpSuffix { get; set; }
    }

    public class LegInfoResponse
    {
        public string ArrivalTerminal { get; set; }
        public string DepartureTerminal { get; set; }
        public string EquipmentType { get; set; }
        public string EquipmentTypeSuffix { get; set; }
        public string OnTime { get; set; }
        public string OperatingCarrier { get; set; }
        public string OperatingFlightNumber { get; set; }
    }
}
