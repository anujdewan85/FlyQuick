using checkinmanagement.API.DTOs.Requests;
using FluentValidation;

namespace checkinmanagement.API.Validators
{
    public class RetrieveJourneyApiRequestValidator : AbstractValidator<RetrieveJourneyRequest>
    {
        public RetrieveJourneyApiRequestValidator()
        {
            // Ensure at least one valid combination is provided
            RuleFor(x => x)
                .Must(BeValidCombination)
                .WithMessage("Please provide one of the following: 1) BookingReference only, 2) PNR + LastName, or 3) PNR + EmailId");

            // PNR validation (when provided)
            RuleFor(x => x.Pnr)
                .NotEmpty()
                .When(x => !string.IsNullOrEmpty(x.Pnr))
                .WithMessage("PNR cannot be empty when provided")
                .Length(6, 10)
                .When(x => !string.IsNullOrEmpty(x.Pnr))
                .WithMessage("PNR must be between 6 and 10 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.Pnr))
                .WithMessage("PNR must contain only uppercase letters and numbers");

            // LastName validation (when provided)
            RuleFor(x => x.LastName)
                .NotEmpty()
                .When(x => !string.IsNullOrEmpty(x.LastName))
                .WithMessage("LastName cannot be empty when provided")
                .MinimumLength(2)
                .When(x => !string.IsNullOrEmpty(x.LastName))
                .WithMessage("Last name must be at least 2 characters");

            // EmailId validation (when provided)
            RuleFor(x => x.EmailId)
                .NotEmpty()
                .When(x => !string.IsNullOrEmpty(x.EmailId))
                .WithMessage("EmailId cannot be empty when provided")
                .EmailAddress()
                .When(x => !string.IsNullOrEmpty(x.EmailId))
                .WithMessage("Invalid email format");

            // BookingReference validation (when provided)
            RuleFor(x => x.BookingReference)
                .NotEmpty()
                .When(x => !string.IsNullOrEmpty(x.BookingReference))
                .WithMessage("BookingReference cannot be empty when provided")
                .Length(6, 20)
                .When(x => !string.IsNullOrEmpty(x.BookingReference))
                .WithMessage("BookingReference must be between 6 and 20 characters");
        }

        private static bool BeValidCombination(RetrieveJourneyRequest request)
        {
            // Option 1: Only BookingReference
            if (!string.IsNullOrEmpty(request.BookingReference) && 
                string.IsNullOrEmpty(request.Pnr) && 
                string.IsNullOrEmpty(request.LastName) && 
                string.IsNullOrEmpty(request.EmailId))
            {
                return true;
            }

            // Option 2: PNR + LastName
            if (!string.IsNullOrEmpty(request.Pnr) && 
                !string.IsNullOrEmpty(request.LastName) && 
                string.IsNullOrEmpty(request.EmailId) && 
                string.IsNullOrEmpty(request.BookingReference))
            {
                return true;
            }

            // Option 3: PNR + EmailId
            if (!string.IsNullOrEmpty(request.Pnr) && 
                !string.IsNullOrEmpty(request.EmailId) && 
                string.IsNullOrEmpty(request.LastName) && 
                string.IsNullOrEmpty(request.BookingReference))
            {
                return true;
            }

            return false;
        }
    }
}
