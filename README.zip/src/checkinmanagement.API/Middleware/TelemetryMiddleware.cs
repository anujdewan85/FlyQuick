using System.Diagnostics;
using System.Text.Json;
using checkinmanagement.API.Configuration;

namespace checkinmanagement.API.Middleware
{
    /// <summary>
    /// Middleware for global exception handling and telemetry
    /// </summary>
    public class TelemetryMiddleware(RequestDelegate next, ILogger<TelemetryMiddleware> logger)
    {
        private readonly RequestDelegate _next = next;
        private readonly ILogger<TelemetryMiddleware> _logger = logger;

        public async Task InvokeAsync(HttpContext context)
        {
            using var activity = TelemetryConfiguration.ActivitySource.StartActivity("HTTP Request");
            
            // Add request information to telemetry
            activity?.SetTag("http.method", context.Request.Method);
            activity?.SetTag("http.url", GetFullUrl(context.Request));
            activity?.SetTag("http.user_agent", context.Request.Headers.UserAgent.ToString());
            activity?.SetTag("http.request_id", context.TraceIdentifier);

            var stopwatch = Stopwatch.StartNew();

            try
            {
                await _next(context);
                
                stopwatch.Stop();
                
                // Add response information to telemetry
                activity?.SetTag("http.status_code", context.Response.StatusCode);
                activity?.SetTag("http.response_time_ms", stopwatch.ElapsedMilliseconds);
                
                // Log successful request
                _logger.LogInformation(
                    "HTTP {Method} {Path} responded {StatusCode} in {ElapsedMs}ms",
                    context.Request.Method,
                    context.Request.Path,
                    context.Response.StatusCode,
                    stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                
                // Add exception information to telemetry
                activity?.SetTag("exception.type", ex.GetType().Name);
                activity?.SetTag("exception.message", ex.Message);
                activity?.SetTag("exception.stacktrace", ex.StackTrace);
                activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
                
                // Log the exception
                _logger.LogError(ex,
                    "Unhandled exception occurred during HTTP {Method} {Path} after {ElapsedMs}ms",
                    context.Request.Method,
                    context.Request.Path,
                    stopwatch.ElapsedMilliseconds);

                await HandleExceptionAsync(context, ex);
            }
        }

        private static string GetFullUrl(HttpRequest request)
        {
            return $"{request.Scheme}://{request.Host}{request.PathBase}{request.Path}{request.QueryString}";
        }

        private static async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            
            var response = new
            {
                success = false,
                message = "An error occurred while processing your request.",
                errorCode = "INTERNAL_SERVER_ERROR",
                traceId = context.TraceIdentifier,
                timestamp = DateTime.UtcNow
            };

            switch (exception)
            {
                case ArgumentNullException:
                case ArgumentException:
                    context.Response.StatusCode = StatusCodes.Status400BadRequest;
                    response = new
                    {
                        success = false,
                        message = "Invalid request parameters.",
                        errorCode = "BAD_REQUEST",
                        traceId = context.TraceIdentifier,
                        timestamp = DateTime.UtcNow
                    };
                    break;
                    
                case KeyNotFoundException:
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                    response = new
                    {
                        success = false,
                        message = "The requested resource was not found.",
                        errorCode = "NOT_FOUND",
                        traceId = context.TraceIdentifier,
                        timestamp = DateTime.UtcNow
                    };
                    break;
                    
                case TimeoutException:
                    context.Response.StatusCode = StatusCodes.Status408RequestTimeout;
                    response = new
                    {
                        success = false,
                        message = "The request timed out.",
                        errorCode = "TIMEOUT",
                        traceId = context.TraceIdentifier,
                        timestamp = DateTime.UtcNow
                    };
                    break;
                    
                default:
                    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                    // response is already set above for 500 errors
                    break;
            }

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            
            await context.Response.WriteAsync(jsonResponse);
        }
    }

    /// <summary>
    /// Extension method to register the telemetry middleware
    /// </summary>
    public static class TelemetryMiddlewareExtensions
    {
        public static IApplicationBuilder UseTelemetryMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<TelemetryMiddleware>();
        }
    }
}
