using Microsoft.AspNetCore.Mvc;
using checkinmanagement.Application.Interfaces;
using Asp.Versioning;

namespace checkinmanagement.API.Controllers.v1
{
    /// <summary>
    /// Contact management endpoints for check-in operations (Version 1)
    /// </summary>
    [ApiVersion("1.0")]
    [Route("checkin/v{version:apiVersion}/contacts")]
    public class ContactController(ILogger<ContactController> logger, IContactService contactService) : BaseController(logger)
    {
        private readonly IContactService _contactService = contactService;

        /// <summary>
        /// Get contacts by journey key
        /// </summary>
        /// <param name="journeyKey">The journey key to get contacts for</param>
        /// <returns>Contact information for the journey</returns>
        /// <response code="200">Contact information retrieved successfully</response>
        /// <response code="400">Invalid journey key</response>
        /// <response code="404">Journey not found</response>
        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetContacts([FromQuery] string journeyKey)
        {
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Action"] = nameof(GetContacts),
                ["RequestId"] = HttpContext.TraceIdentifier,
                ["CorrelationId"] = HttpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault() ?? Guid.NewGuid().ToString(),
                ["JourneyKey"] = journeyKey
            });

            try
            {
                if (string.IsNullOrWhiteSpace(journeyKey))
                {
                    _logger.LogWarning("Journey key is required for getting contacts");
                    return BadRequest(new
                    {
                        data = new { },
                        errors = new { message = "Journey key is required", code = "INVALID_REQUEST" }
                    });
                }

                _logger.LogInformation("GET /checkin/v1/contacts called with JourneyKey: {JourneyKey}", journeyKey);

                // Get contact data from service
                var contacts = await _contactService.GetContactsByJourneyKeyAsync(journeyKey);
                
                if (contacts == null || !contacts.Any())
                {
                    _logger.LogWarning("No contacts found for JourneyKey: {JourneyKey}", journeyKey);
                    return NotFound(new
                    {
                        data = new { },
                        errors = new { message = "No contacts found for the specified journey", code = "JOURNEY_NOT_FOUND" }
                    });
                }

                // Format contacts based on whether there's one or multiple
                var contactList = contacts.ToList();
                var contactsData = contactList.Select(contact => new
                {
                    phoneNumber = contact.PhoneNumber,
                    email = contact.Email,
                    type = contact.Type
                }).ToList();

                return Ok(new
                {
                    data = new
                    {
                        journeyKey = contactList.First().JourneyKey,
                        contacts = contactsData
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error while retrieving contacts for journey: {JourneyKey}", journeyKey);
                return StatusCode(500, new
                {
                    data = new { },
                    errors = new { message = "An unexpected error occurred while retrieving contacts", code = "INTERNAL_ERROR" }
                });
            }
        }

        /// <summary>
        /// Post contacts endpoint
        /// </summary>
        /// <returns>200 OK status</returns>
        /// <response code="200">Success</response>
        [HttpPost]
        [ProducesResponseType(200)]
        public IActionResult PostContacts()
        {
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Action"] = nameof(PostContacts),
                ["RequestId"] = HttpContext.TraceIdentifier,
                ["CorrelationId"] = HttpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault() ?? Guid.NewGuid().ToString()
            });

            _logger.LogInformation("POST /checkin/v1/contacts called");
            return Ok(new { Message = "Contacts endpoint - POST", Status = "Success" });
        }
    }
}
