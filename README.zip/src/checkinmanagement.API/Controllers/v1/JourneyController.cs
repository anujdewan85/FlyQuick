using checkinmanagement.API.DTOs.Requests;
using checkinmanagement.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using checkinmanagement.API.Mappers;
using Asp.Versioning;

namespace checkinmanagement.API.Controllers.v1
{
    /// <summary>
    /// Journey management endpoints for check-in operations (Version 1)
    /// </summary>
    [ApiVersion("1.0")]
    [Route("checkin/v{version:apiVersion}/journeys")]
    public class JourneyController(
        IJourneyService journeyService,
        ILogger<JourneyController> logger) : BaseController(logger)
    {
        private readonly IJourneyService _journeyService = journeyService;

        /// <summary>
        /// Retrieve journey list for check-in (API contract format)
        /// </summary>
        /// <param name="request">Journey retrieval request containing PNR and passenger details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of journeys in API format</returns>
        /// <response code="200">Journey list found successfully</response>
        /// <response code="400">Invalid request data</response>
        /// <response code="404">Journey not found</response>
        /// <response code="500">Internal server error</response>
        [HttpPost("retrieve")]
        [ProducesResponseType(typeof(DTOs.Responses.RetrieveJourneyResponse), 200)]
        [ProducesResponseType(typeof(object), 400)]
        [ProducesResponseType(typeof(object), 404)]
        [ProducesResponseType(typeof(object), 500)]
        public async Task<ActionResult<DTOs.Responses.RetrieveJourneyResponse>> RetrieveJourneyList(
            [FromBody] RetrieveJourneyRequest request,
            CancellationToken cancellationToken = default)
        {
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Action"] = nameof(RetrieveJourneyList),
                ["RequestId"] = HttpContext.TraceIdentifier,
                ["CorrelationId"] = HttpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault() ?? Guid.NewGuid().ToString()
            });

            try
            {
                var applicationRequest = request.ToApplicationRequest();
                var bookingAggregate = await _journeyService.GetJourneyListAsync(applicationRequest, cancellationToken);

                if (bookingAggregate == null)
                {
                    _logger.LogWarning("Journey not found for {RequestType}", GetRequestType(request));
                    return NotFound(new
                    {
                        Data = new { },
                        Errors = new { Message = "Journey not found", Code = "NOT_FOUND" }
                    });
                }

                var apiResponse = bookingAggregate.ToApiJourneyListResponse();
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in journey list retrieval for {RequestType}", GetRequestType(request));
                return StatusCode(500, new
                {
                    Data = new { },
                    Errors = new { Message = "An unexpected error occurred", Code = "INTERNAL_ERROR" }
                });
            }
        }

        /// <summary>
        /// Helper method to determine request type for logging
        /// </summary>
        private static string GetRequestType(RetrieveJourneyRequest request)
        {
            if (!string.IsNullOrWhiteSpace(request.BookingReference))
                return "BookingReference";
            if (!string.IsNullOrWhiteSpace(request.Pnr) && !string.IsNullOrWhiteSpace(request.LastName))
                return "PNR+LastName";
            if (!string.IsNullOrWhiteSpace(request.Pnr) && !string.IsNullOrWhiteSpace(request.EmailId))
                return "PNR+Email";
            return "Unknown";
        }

        /// <summary>
        /// Retrieve specific journey details by journey key
        /// </summary>
        /// <param name="journeyKey">The unique journey identifier</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Detailed journey information</returns>
        /// <response code="200">Journey details found successfully</response>
        /// <response code="404">Journey not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("{journeyKey}")]
        [ProducesResponseType(typeof(DTOs.Responses.JourneyDetailResponse), 200)]
        [ProducesResponseType(typeof(object), 404)]
        [ProducesResponseType(typeof(object), 500)]
        public async Task<ActionResult<DTOs.Responses.JourneyDetailResponse>> GetJourneyByKey(
            [FromRoute] string journeyKey,
            CancellationToken cancellationToken = default)
        {
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Action"] = nameof(GetJourneyByKey),
                ["RequestId"] = HttpContext.TraceIdentifier,
                ["CorrelationId"] = HttpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault() ?? Guid.NewGuid().ToString(),
                ["JourneyKey"] = journeyKey
            });

            try
            {
                if (string.IsNullOrWhiteSpace(journeyKey))
                {
                    _logger.LogWarning("Journey key is required");
                    return BadRequest(new
                    {
                        Data = new { },
                        Errors = new { Message = "Journey key is required", Code = "INVALID_REQUEST" }
                    });
                }

                var journey = await _journeyService.GetJourneyByKeyAsync(journeyKey, cancellationToken);

                if (journey == null)
                {
                    _logger.LogWarning("Journey not found for key: {JourneyKey}", journeyKey);
                    return NotFound(new
                    {
                        Data = new { },
                        Errors = new { Message = "Journey not found", Code = "NOT_FOUND" }
                    });
                }

                var apiResponse = journey.ToApiJourneyDetailResponse();
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in journey detail retrieval for key: {JourneyKey}", journeyKey);
                return StatusCode(500, new
                {
                    Data = new { },
                    Errors = new { Message = "An unexpected error occurred", Code = "INTERNAL_ERROR" }
                });
            }
        }
    }
}
