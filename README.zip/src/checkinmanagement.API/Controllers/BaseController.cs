using Microsoft.AspNetCore.Mvc;

namespace checkinmanagement.API.Controllers
{
    /// <summary>
    /// Base controller with common functionality for all API controllers
    /// </summary>
    [ApiController]
    [Produces("application/json")]
    public abstract class BaseController : ControllerBase
    {
        protected readonly ILogger _logger;

        protected BaseController(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Creates a standard error response
        /// </summary>
        protected ObjectResult CreateErrorResponse(string message, string errorCode, int statusCode)
        {
            var errorResponse = new
            {
                Success = false,
                ErrorMessage = message,
                ErrorCode = errorCode,
                Timestamp = DateTime.UtcNow
            };

            return StatusCode(statusCode, errorResponse);
        }
    }
}
