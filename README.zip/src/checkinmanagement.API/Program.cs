using checkinmanagement.API.Configuration;
using checkinmanagement.API.Extensions;
using Asp.Versioning;
using Serilog;
using System.Text.Json;

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(new ConfigurationBuilder()
        .AddJsonFile("appsettings.json")
        .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", optional: true)
        .AddEnvironmentVariables()
        .Build())
    .CreateLogger();

try
{
    Log.Information("Starting CheckIn Management Service");

    var builder = WebApplication.CreateBuilder(args);

    // Configure Serilog with the application
    builder.Host.UseSerilog();

    // Configure Mapster mappings
    MapsterConfiguration.ConfigureApiMappings();

    // Add services to the container
    builder.Services.AddControllers()
        .AddJsonOptions(options =>
        {
            // Configure camelCase naming policy globally
            options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            options.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
        });

    // Add API versioning
    builder.Services.AddApiVersioning(opt =>
    {
        opt.DefaultApiVersion = new ApiVersion(1, 0);
        opt.AssumeDefaultVersionWhenUnspecified = true;
        opt.ApiVersionReader = ApiVersionReader.Combine(
            new UrlSegmentApiVersionReader(),
            new QueryStringApiVersionReader("version"),
            new HeaderApiVersionReader("X-Version")
        );
    }).AddMvc();

    builder.Services.AddEndpointsApiExplorer();
    
    // Add Swagger configuration
    builder.Services.AddSwaggerConfiguration();


    // Register IHttpClientFactory for external HTTP calls
    builder.Services.AddHttpClient();

    // Add custom services usin    g extension methods
    builder.Services.AddCustomServices(builder.Configuration);

    // Add OpenTelemetry for observability
    builder.Services.AddTelemetryServices(builder.Configuration);

    var app = builder.Build();

    // Configure the HTTP request pipeline
    app.UseSerilogRequestLogging(SerilogConfiguration.ConfigureRequestLogging);

    app.UseSwagger();
    app.UseSwaggerUI();

    if (app.Environment.IsDevelopment())
    {
        // Additional development-only configurations can go here
    }

    app.UseHttpsRedirection();
    app.UseAuthorization();
    app.MapControllers();

    Log.Information("CheckIn Management Service started successfully on {MachineName}", Environment.MachineName);
    
    await app.RunAsync();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    Log.Information("CheckIn Management Service shutting down");
    await Log.CloseAndFlushAsync();
}
