using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System.Diagnostics;

namespace checkinmanagement.API.Configuration
{
    /// <summary>
    /// Configuration for OpenTelemetry telemetry setup
    /// </summary>
    public static class TelemetryConfiguration
    {
        private const string DefaultServiceName = "checkin-management-service";
        
        /// <summary>
        /// Activity source for manual instrumentation
        /// </summary>
        public static readonly ActivitySource ActivitySource = new(DefaultServiceName);

        /// <summary>
        /// Configures OpenTelemetry tracing
        /// </summary>
        /// <param name="builder">The tracer provider builder</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The tracer provider builder for chaining</returns>
        public static TracerProviderBuilder ConfigureTracing(this TracerProviderBuilder builder, IConfiguration configuration)
        {
            var serviceName = configuration["OpenTelemetry:ServiceName"] ?? DefaultServiceName;
            
            return builder
                .AddSource(serviceName)
                .SetResourceBuilder(CreateResourceBuilder(configuration))
                .AddAspNetCoreInstrumentation(options =>
                {
                    // Capture request and response bodies for debugging (be careful with sensitive data)
                    options.RecordException = true;
                    options.EnrichWithHttpRequest = (activity, request) =>
                    {
                        activity.SetTag("http.request.method", request.Method);
                        activity.SetTag("http.request.path", request.Path);
                        activity.SetTag("http.request.query", request.QueryString.ToString());
                        activity.SetTag("user_agent", request.Headers.UserAgent.ToString());
                    };
                    options.EnrichWithHttpResponse = (activity, response) =>
                    {
                        activity.SetTag("http.response.status_code", response.StatusCode);
                        activity.SetTag("http.response.content_type", response.ContentType);
                    };
                    options.EnrichWithException = (activity, exception) =>
                    {
                        activity.SetTag("exception.type", exception.GetType().Name);
                        activity.SetTag("exception.message", exception.Message);
                        activity.SetTag("exception.stacktrace", exception.StackTrace);
                    };
                })
                .AddHttpClientInstrumentation(options =>
                {
                    // Instrument outgoing HTTP calls
                    options.RecordException = true;
                    options.EnrichWithHttpRequestMessage = (activity, request) =>
                    {
                        activity.SetTag("http.client.method", request.Method.ToString());
                        activity.SetTag("http.client.url", request.RequestUri?.ToString());
                    };
                    options.EnrichWithHttpResponseMessage = (activity, response) =>
                    {
                        activity.SetTag("http.client.status_code", (int)response.StatusCode);
                        activity.SetTag("http.client.response_time", activity.Duration.TotalMilliseconds);
                    };
                    options.EnrichWithException = (activity, exception) =>
                    {
                        activity.SetTag("http.client.exception.type", exception.GetType().Name);
                        activity.SetTag("http.client.exception.message", exception.Message);
                    };
                })
                .AddConsoleExporter()
                .AddOtlpExporter(options =>
                {
                    // Configure OTLP endpoint if provided
                    var endpoint = configuration["OpenTelemetry:Endpoint"];
                    if (!string.IsNullOrEmpty(endpoint))
                    {
                        options.Endpoint = new Uri(endpoint);
                    }
                });
        }

        /// <summary>
        /// Configures OpenTelemetry metrics
        /// </summary>
        /// <param name="builder">The meter provider builder</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The meter provider builder for chaining</returns>
        public static MeterProviderBuilder ConfigureMetrics(this MeterProviderBuilder builder, IConfiguration configuration)
        {
            var serviceName = configuration["OpenTelemetry:ServiceName"] ?? DefaultServiceName;
            
            return builder
                .AddMeter(serviceName)
                .SetResourceBuilder(CreateResourceBuilder(configuration))
                .AddAspNetCoreInstrumentation()
                .AddHttpClientInstrumentation()
                .AddRuntimeInstrumentation()
                .AddConsoleExporter()
                .AddOtlpExporter(options =>
                {
                    // Configure OTLP endpoint if provided
                    var endpoint = configuration["OpenTelemetry:Endpoint"];
                    if (!string.IsNullOrEmpty(endpoint))
                    {
                        options.Endpoint = new Uri(endpoint);
                    }
                });
        }

        /// <summary>
        /// Creates the resource builder with service information
        /// </summary>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The resource builder</returns>
        private static ResourceBuilder CreateResourceBuilder(IConfiguration configuration)
        {
            var serviceName = configuration["OpenTelemetry:ServiceName"] ?? DefaultServiceName;
            var serviceVersion = configuration["OpenTelemetry:ServiceVersion"] ?? "1.0.0";
            
            return ResourceBuilder.CreateDefault()
                .AddService(
                    serviceName: serviceName,
                    serviceVersion: serviceVersion,
                    serviceInstanceId: Environment.MachineName)
                .AddAttributes(new Dictionary<string, object>
                {
                    ["service.environment"] = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production",
                    ["service.instance"] = Environment.MachineName,
                    ["deployment.environment"] = Environment.GetEnvironmentVariable("DEPLOYMENT_ENVIRONMENT") ?? "unknown"
                });
        }
    }
}
