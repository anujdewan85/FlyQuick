using Mapster;
using checkinmanagement.Infrastructure.ExternalServices.Common.Mappers;
using checkinmanagement.API.DTOs.Requests;
using checkinmanagement.API.DTOs.Responses;
using checkinmanagement.Application.DTOs;

namespace checkinmanagement.API.Configuration
{
    /// <summary>
    /// Configures Mapster mappings for API layer
    /// </summary>
    public static class MapsterConfiguration
    {
        /// <summary>
        /// Configure all mapping rules for API layer
        /// </summary>
        public static void ConfigureApiMappings()
        {
            // API Request to Application Request mapping
            TypeAdapterConfig<DTOs.Requests.RetrieveJourneyRequest, Application.DTOs.RetrieveJourneyRequest>
                .NewConfig()
                .Map(dest => dest.PNR, src => src.Pnr != null ? src.Pnr.Trim().ToUpperInvariant() : null)
                .Map(dest => dest.LastName, src => src.LastName != null ? src.LastName.Trim() : null)
                .Map(dest => dest.EmailId, src => src.EmailId != null ? src.EmailId.Trim().ToLowerInvariant() : null)
                .Map(dest => dest.BookingReference, src => src.BookingReference != null ? src.BookingReference.Trim().ToUpperInvariant() : null);

            // Configure GraphQL mappings for Infrastructure layer
            // This initializes the static constructor which sets up all the mappings
            NavitaireGraphQLMapper.EnsureConfigured();

            // Note: Complex domain-to-API mappings are handled by dedicated extension methods 
            // in DtoMappingExtensions.cs for better maintainability
        }
    }
}
