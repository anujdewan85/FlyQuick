using Microsoft.OpenApi.Models;
using System.Reflection;

namespace checkinmanagement.API.Configuration;

/// <summary>
/// Configuration for Swagger/OpenAPI documentation
/// </summary>
public static class SwaggerConfiguration
{
    private const string ApiDescription = @"
**Checkin Management Service API** provides endpoints for managing the airline check-in operations.

**Description**: It enables users to retrieve journey details, check-in passengers, and manage contact information.

**Version**: 1.0.0

**Base URL**: `/checkin/v1`

**Supported Formats**: JSON

## API Design Principles

### Immutable Data with Records (.NET 8)
This API uses **C# record types** for better data integrity and performance:
- **Immutability**: DTOs use `init` properties, preventing accidental mutations
- **Value-based Equality**: Records provide automatic equality comparison
- **Thread Safety**: Immutable objects are inherently thread-safe
- **Better Serialization**: Clean JSON serialization with `JsonPropertyName` attributes

### Data Types & Validation Rules

#### Request Data Types:
- **PNR**: `string` (6-10 characters, alphanumeric uppercase) - Example: `ABC123`
- **LastName**: `string` (minimum 2 characters) - Example: `Sharma`
- **EmailId**: `string` (valid email format) - Example: `rohit.sharma@example.com`
- **BookingReference**: `string` (6-20 characters) - Example: `BKREF123456`

#### Response Data Types:
- **JourneyKey**: `string` (max 100 characters) - Example: `ABC123~2025-08-15~DEL~BOM~AI101`
- **Airport Codes**: `string` (exactly 3 characters, uppercase) - Example: `DEL`, `BOM`
- **DateTime**: `DateTime` (ISO 8601 UTC format) - Example: `2025-08-15T10:30:00Z`
- **Status**: `string` (max 20 characters) - Values: `eligible`, `noteligible`, `schedule`
- **CheckedinStatus**: `string` (max 20 characters) - Values: `None`, `All`, `Partial`

### Request Patterns
The API supports three search patterns (exactly one must be provided):

1. **BookingReference only**
   ```json
   { ""BookingReference"": ""ABC123"" }
   ```

2. **PNR + LastName**
   ```json
   { ""PNR"": ""ABC123"", ""LastName"": ""Sharma"" }
   ```

3. **PNR + EmailId**
   ```json
   { ""PNR"": ""ABC123"", ""EmailId"": ""rohit.sharma@example.com"" }
   ```

### Error Handling
- **400 Bad Request**: Validation errors with detailed field-level messages
- **404 Not Found**: No journeys found for search criteria
- **500 Internal Server Error**: Unexpected server errors

### Observability Features
This API includes comprehensive telemetry integration:
- **Request Tracing**: All HTTP requests are automatically traced
- **Performance Metrics**: Response times and error rates are captured
- **Error Tracking**: Exceptions and validation errors are logged with correlation IDs
- **Health Monitoring**: Service health endpoints provide operational insights
";

    /// <summary>
    /// Adds Swagger configuration to the service collection
    /// </summary>
    /// <param name="services">The service collection</param>
    /// <returns>The service collection for chaining</returns>
    public static IServiceCollection AddSwaggerConfiguration(this IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "CheckIn Management API",
                Version = "v1",
                Description = ApiDescription,
                Contact = new OpenApiContact
                {
                    Name = "CheckIn Management Team",
                    Email = "checkin-support@example.com"
                }
            });

            // Include XML comments for documentation
            var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            if (File.Exists(xmlPath))
            {
                c.IncludeXmlComments(xmlPath);
            }

            // Configure schema generation for records
            c.UseInlineDefinitionsForEnums();
            c.DescribeAllParametersInCamelCase();
        });

        return services;
    }
}
