using Serilog;
using Serilog.AspNetCore;

namespace checkinmanagement.API.Configuration;

/// <summary>
/// Configuration for Serilog request logging middleware
/// </summary>
public static class SerilogConfiguration
{
    /// <summary>
    /// Configures Serilog request logging with custom message template and diagnostic context enrichment
    /// </summary>
    /// <param name="options">Request logging options to configure</param>
    public static void ConfigureRequestLogging(RequestLoggingOptions options)
    {
        // Custom message template for HTTP requests
        options.MessageTemplate = "HTTP {RequestMethod} {RequestPath} responded {StatusCode} in {Elapsed:0.0000} ms";
        
        // Enrich diagnostic context with additional request information
        options.EnrichDiagnosticContext = EnrichDiagnosticContext;
    }

    /// <summary>
    /// Enriches the diagnostic context with request-specific information
    /// </summary>
    /// <param name="diagnosticContext">The diagnostic context to enrich</param>
    /// <param name="httpContext">The HTTP context containing request information</param>
    private static void EnrichDiagnosticContext(IDiagnosticContext diagnosticContext, HttpContext httpContext)
    {
        // Add host and scheme information
        diagnosticContext.Set("RequestHost", httpContext.Request.Host.Value);
        diagnosticContext.Set("RequestScheme", httpContext.Request.Scheme);
        
        // Add User-Agent if present
        var userAgent = httpContext.Request.Headers["User-Agent"].FirstOrDefault();
        if (!string.IsNullOrEmpty(userAgent))
        {
            diagnosticContext.Set("UserAgent", userAgent);
        }
        
        // Add Correlation ID if present
        if (httpContext.Request.Headers.ContainsKey("X-Correlation-ID"))
        {
            var correlationId = httpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault();
            if (!string.IsNullOrEmpty(correlationId))
            {
                diagnosticContext.Set("CorrelationId", correlationId);
            }
        }
    }
}
