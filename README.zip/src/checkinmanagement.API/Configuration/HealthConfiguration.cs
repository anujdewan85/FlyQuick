namespace checkinmanagement.API.Configuration;

/// <summary>
/// Configuration settings for health endpoints
/// </summary>
public class HealthConfiguration
{
    /// <summary>
    /// Configuration section name
    /// </summary>
    public const string SectionName = "Health";

    /// <summary>
    /// Display name for the service in health responses
    /// </summary>
    public string ServiceDisplayName { get; set; } = "CheckIn Management API";
}
