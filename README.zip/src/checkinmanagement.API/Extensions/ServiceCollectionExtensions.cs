﻿using checkinmanagement.Application.Interfaces;
using checkinmanagement.Application.Interfaces.ExternalServices;
using checkinmanagement.Application.Services;
using checkinmanagement.Application.Extensions; // Add this for validation services
using checkinmanagement.Infrastructure.ExternalServices;
using checkinmanagement.Infrastructure.ExternalServices.GraphQL;
using checkinmanagement.Infrastructure.MockData;
using checkinmanagement.API.Validators;
using checkinmanagement.API.Mappers;
using checkinmanagement.API.Configuration;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Mvc;
using GraphQL.Client.Http;
using GraphQL.Client.Abstractions;
using GraphQL.Client.Serializer.SystemTextJson;
using System.Collections.Concurrent;

namespace checkinmanagement.API.Extensions
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Adds all application services to the dependency injection container
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Configure FluentValidation for automatic validation
            services.AddFluentValidationAutoValidation();
            
            // Register API-level validators (for DTOs and requests)
            services.AddValidatorsFromAssemblyContaining<RetrieveJourneyApiRequestValidator>();
            
            // Register Application-level validators (for domain entities and value objects)
            services.AddValidationServices();

            // Configure custom validation response format
            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var errors = context.ModelState
                        .Where(x => x.Value?.Errors.Count > 0)
                        .ToDictionary(
                            kvp => kvp.Key,
                            kvp => kvp.Value?.Errors.Select(e => e.ErrorMessage).ToArray() ?? Array.Empty<string>()
                        );

                    var customResponse = ValidationErrorMapper.ToCustomValidationErrorResponse(
                        "Validation failed. Please check the provided data.",
                        "VALIDATION_ERROR",
                        errors);

                    return new BadRequestObjectResult(customResponse);
                };
            });

            // Application Services
            services.AddScoped<IJourneyService, JourneyService>();
            services.AddScoped<IContactService, ContactService>();

            // Infrastructure Services
            services.AddSingleton<INavitaireServiceFactory, NavitaireServiceFactory>();
            services.AddSingleton<MockDataLoader>(); // Register JSON data loader

            // GraphQL Services
            services.AddScoped<INavitaireService, NavitaireGraphQLService>();

            // GraphQL Client Configuration
            services.AddGraphQLClientServices(configuration);

            return services;
        }

        /// <summary>
        /// Adds all custom services and configurations
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddCustomServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddApplicationServices(configuration);

            return services;
        }

        /// <summary>
        /// Adds OpenTelemetry configuration for observability
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddTelemetryServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddOpenTelemetry()
                .WithTracing(builder => builder.ConfigureTracing(configuration))
                .WithMetrics(builder => builder.ConfigureMetrics(configuration));

            return services;
        }

        /// <summary>
        /// Adds GraphQL client services for Navitaire integration
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddGraphQLClientServices(this IServiceCollection services, IConfiguration configuration)
        {
            var baseUrl = configuration["NavitaireService:BaseUrl"];
            var authToken = configuration["NavitaireService:AuthToken"];
            var defaultEndpoint = configuration["NavitaireService:Endpoints:GraphQL:BookingRetrieve"] ?? "/api/v2/graph/BookingRetrievev3";
            
            if (string.IsNullOrEmpty(baseUrl))
                throw new ArgumentNullException(nameof(configuration), "NavitaireService:BaseUrl is required");

            // Register a single GraphQL client with the main endpoint
            services.AddSingleton<IGraphQLClient>(provider =>
            {
                var fullUrl = new Uri(new Uri(baseUrl), defaultEndpoint).ToString();
                var client = new GraphQLHttpClient(fullUrl, new SystemTextJsonSerializer());
                
                if (!string.IsNullOrEmpty(authToken))
                {
                    client.HttpClient.DefaultRequestHeaders.Authorization = 
                        new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", authToken);
                }
                
                return client;
            });
            
            return services;
        }
    }
}
