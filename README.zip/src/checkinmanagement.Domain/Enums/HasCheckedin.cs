namespace checkinmanagement.Domain.Enums
{
    /// <summary>
    /// Represents the check-in status of a passenger
    /// </summary>
    public enum HasCheckedin
    {
        /// <summary>
        /// XSAT (Extended Seat Assignment Time) has been applied to the passenger
        /// </summary>
        XSATApplied = 0,

        /// <summary>
        /// Passenger has checked in
        /// </summary>
        Checkedin = 1,

        /// <summary>
        /// Passenger has boarded the aircraft
        /// </summary>
        Boarded = 2,
        
        /// <summary>
        /// Passenger did not show up for the flight
        /// </summary>
        NoShow = 3,
        
        /// <summary>
        /// No check-in status has been set
        /// </summary>
        None = 4  

    }
}
