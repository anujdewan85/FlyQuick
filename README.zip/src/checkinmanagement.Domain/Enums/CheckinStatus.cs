namespace checkinmanagement.Domain.Enums
{
    public enum CheckinStatus   // NotEligible, Schedule, Available, Completed
    {
        NotEligible = 0,
        Schedule = 1,
        Available = 2,
        Completed = 3
    }
}
