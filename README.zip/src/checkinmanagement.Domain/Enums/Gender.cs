namespace checkinmanagement.Domain.Enums
{
    /// <summary>
    /// Represents passenger gender options
    /// </summary>
    public enum Gender
    {
        /// <summary>
        /// Male
        /// </summary>
        Male = 0,
        
        /// <summary>
        /// Female
        /// </summary>
        Female = 1,
        
        /// <summary>
        /// Other/Not specified
        /// </summary>
        Other = 2
    }
}
