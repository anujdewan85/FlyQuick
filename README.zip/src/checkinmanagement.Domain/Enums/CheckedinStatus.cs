namespace checkinmanagement.Domain.Enums
{
    /// <summary>
    /// Represents the check-in status of passengers in a journey
    /// </summary>
    public enum CheckedinStatus
    {
        /// <summary>
        /// No passengers checked in
        /// </summary>
        None = 0,
        
        /// <summary>
        /// Some passengers checked in
        /// </summary>
        Partial = 1,
        
        /// <summary>
        /// All passengers checked in
        /// </summary>
        All = 2
    }
}
