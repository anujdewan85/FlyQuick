using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace checkinmanagement.Domain.Enums
{
    public enum BookingStatus
    {
        Active = 0,
        Cancelled = 1,
        Completed = 2
    }
}
