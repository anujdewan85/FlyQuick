using System;
using System.Collections.Generic;
using System.Linq;
using checkinmanagement.Domain.Enums;
using checkinmanagement.Domain.ValueObjects;

namespace checkinmanagement.Domain.Entities
{
    /// <summary>
    /// Passenger Entity - represents a passenger within a journey
    /// Contains personal information, seats, and SSRs
    /// </summary>
    public class Passenger
    {
        private readonly List<SeatAndSsr> _seatsAndSsrs;

        public string PassengerKey { get; private set; }
        public string PassengerTypeCode { get; private set; }
        public string DiscountCode { get; private set; }
        public string ExtraseatTag { get; private set; }
        public HasCheckedin CheckInStatus { get; private set; }
        public string Nationality { get; private set; }
        public Gender Gender { get; private set; }
        public string DateOfBirth { get; private set; }
        public PassengerName Name { get; private set; }
        public Loyalty? Loyalty { get; private set; }
        public Infant? Infant { get; private set; }
        
        public IReadOnlyList<SeatAndSsr> SeatsAndSsrs => _seatsAndSsrs.AsReadOnly();

        // Private constructor for Entity Framework
        private Passenger()
        {
            _seatsAndSsrs = new List<SeatAndSsr>();
            PassengerKey = string.Empty;
            PassengerTypeCode = string.Empty;
            DiscountCode = string.Empty;
            ExtraseatTag = string.Empty;
            CheckInStatus = HasCheckedin.None;
            Nationality = string.Empty;
            DateOfBirth = string.Empty;
            Name = new PassengerName("John", "Doe");
        }

        public Passenger(string passengerKey, PassengerName name, string passengerTypeCode, 
                        Gender gender, string dateOfBirth, string nationality)
        {
            PassengerKey = passengerKey;
            Name = name;
            PassengerTypeCode = passengerTypeCode ?? string.Empty;
            Gender = gender;
            DateOfBirth = dateOfBirth;
            Nationality = nationality ?? string.Empty;
            DiscountCode = string.Empty;
            ExtraseatTag = string.Empty;
            CheckInStatus = HasCheckedin.None;
            _seatsAndSsrs = new List<SeatAndSsr>();
        }

        public void CheckIn(bool isAutoCheckin = false)
        {
            CheckInStatus = isAutoCheckin ? HasCheckedin.Checkedin : HasCheckedin.None;
        }

        public void SetLoyalty(Loyalty loyalty)
        {
            Loyalty = loyalty;
        }

        public void SetInfant(Infant infant)
        {
            Infant = infant;
        }

        public void AddSeatAndSsr(SeatAndSsr seatAndSsr)
        {
            _seatsAndSsrs.Add(seatAndSsr);
        }

        public void UpdateDiscountCode(string discountCode)
        {
            DiscountCode = discountCode ?? string.Empty;
        }

        public void UpdateExtraseatTag(string extraseatTag)
        {
            ExtraseatTag = extraseatTag ?? string.Empty;
        }

        public bool IsCheckedIn()
        {
            return CheckInStatus != HasCheckedin.None;
        }

        public bool IsAdult()
        {
            return PassengerTypeCode.Equals("ADT", StringComparison.OrdinalIgnoreCase);
        }

        public bool IsChild()
        {
            return PassengerTypeCode.Equals("CHD", StringComparison.OrdinalIgnoreCase);
        }

        public bool IsInfantPassenger()
        {
            return PassengerTypeCode.Equals("INF", StringComparison.OrdinalIgnoreCase);
        }
    }
}
