﻿using System;
using System.Collections.Generic;
using System.Linq;
using checkinmanagement.Domain.Enums;

namespace checkinmanagement.Domain.Entities
{
    /// <summary>
    /// Booking Aggregate Root - represents a complete booking with all journeys
    /// This is the main entity that controls business operations
    /// </summary>
    public class Booking
    {
        private readonly List<Journey> _journeys;

        public string Pnr { get; private set; }
        public string BookingReference { get; private set; }
        public string LastName { get; private set; }
        public string EmailId { get; private set; }
        public BookingStatus Status { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public DateTime? ModifiedAt { get; private set; }
        
        public IReadOnlyList<Journey> Journeys => _journeys.AsReadOnly();

        // Private constructor for Entity Framework
        private Booking() 
        {
            _journeys = new List<Journey>();
            Pnr = string.Empty;
            BookingReference = string.Empty;
            LastName = string.Empty;
            EmailId = string.Empty;
        }

        public Booking(string pnr, string bookingReference, string lastName, string emailId)
        {
            Pnr = pnr;
            BookingReference = bookingReference;
            LastName = lastName;
            EmailId = emailId;
            Status = BookingStatus.Active;
            CreatedAt = DateTime.UtcNow;
            _journeys = new List<Journey>();
        }

        public void AddJourney(Journey journey)
        {
            _journeys.Add(journey);
            ModifiedAt = DateTime.UtcNow;
        }

        public Journey? GetJourney(string journeyKey)
        {
            return _journeys.FirstOrDefault(j => j.JourneyKey == journeyKey);
        }

        public bool CanCheckIn()
        {
            return Status == BookingStatus.Active && _journeys.Any(j => j.IsEligibleForCheckIn());
        }

        public void UpdateStatus(BookingStatus status)
        {
            Status = status;
            ModifiedAt = DateTime.UtcNow;
        }
    }
}
