using checkinmanagement.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace checkinmanagement.Domain.Entities
{
    /// <summary>
    /// Segment Entity - represents a flight segment within a journey
    /// Contains flight details, route information, and leg details
    /// </summary>
    public class Segment
    {
        private readonly List<LegInfo> _legInfo;
        public string? designator;
        public List<LegInfoDto>? legs;

        public string SegmentKey { get; private set; }
        public string Destination { get; private set; }
        public string DestinationName { get; private set; }
        public string DestinationCityName { get; private set; }
        public string Origin { get; private set; }
        public string OriginName { get; private set; }
        public string OriginCityName { get; private set; }
        public DateTime UtcArrival { get; private set; }
        public DateTime UtcDeparture { get; private set; }
        public string ProductClass { get; private set; }
        public bool IsInternational { get; private set; }
        public FlightIdentifier Identifier { get; private set; }
        public FlightIdentifier? ExternalIdentifier { get; private set; }
        
        public IReadOnlyList<LegInfo> LegInfo => _legInfo.AsReadOnly();

        // Private constructor for Entity Framework
        private Segment()
        {
            _legInfo = new List<LegInfo>();
            SegmentKey = string.Empty;
            Destination = string.Empty;
            DestinationName = string.Empty;
            DestinationCityName = string.Empty;
            Origin = string.Empty;
            OriginName = string.Empty;
            OriginCityName = string.Empty;
            ProductClass = string.Empty;
            Identifier = new FlightIdentifier("6E", "123", "");
        }

        public Segment(string segmentKey, string origin, string destination, 
                      DateTime utcDeparture, DateTime utcArrival, FlightIdentifier identifier,
                      string productClass, bool isInternational = false)
        {
            SegmentKey = segmentKey;
            Origin = origin;
            Destination = destination;
            UtcDeparture = utcDeparture;
            UtcArrival = utcArrival;
            Identifier = identifier;
            ProductClass = productClass ?? string.Empty;
            IsInternational = isInternational;
            
            // Default empty values
            DestinationName = string.Empty;
            DestinationCityName = string.Empty;
            OriginName = string.Empty;
            OriginCityName = string.Empty;
            
            _legInfo = new List<LegInfo>();
        }

        public void UpdateLocationNames(string originName, string originCityName, 
                                       string destinationName, string destinationCityName)
        {
            OriginName = originName ?? string.Empty;
            OriginCityName = originCityName ?? string.Empty;
            DestinationName = destinationName ?? string.Empty;
            DestinationCityName = destinationCityName ?? string.Empty;
        }

        public void SetExternalIdentifier(FlightIdentifier externalIdentifier)
        {
            ExternalIdentifier = externalIdentifier;
        }

        public void AddLegInfo(LegInfo legInfo)
        {
            _legInfo.Add(legInfo);
        }

        public TimeSpan FlightDuration => UtcArrival - UtcDeparture;
        
        public bool IsDeparted()
        {
            return DateTime.UtcNow > UtcDeparture;
        }

        public bool IsArrived()
        {
            return DateTime.UtcNow > UtcArrival;
        }

        public string RouteDisplay => $"{Origin} → {Destination}";
    }

    public class LegInfoDto
    {
    }
}
