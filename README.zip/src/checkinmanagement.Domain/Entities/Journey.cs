using System;
using System.Collections.Generic;
using System.Linq;
using checkinmanagement.Domain.Enums;
using checkinmanagement.Domain.ValueObjects;

namespace checkinmanagement.Domain.Entities
{
    /// <summary>
    /// Journey Entity - represents a single journey within a booking
    /// Contains flight details, passengers, and segments
    /// </summary>
    public class Journey
    {
        private readonly List<Passenger> _passengers;
        private readonly List<Segment> _segments;

        public string JourneyKey { get; private set; }
        public string FlightType { get; private set; }
        public int Stops { get; private set; }
        public string ProductClass { get; private set; }
        public bool IsInternational { get; private set; }
        public bool IsCodeshare { get; private set; }
        public CheckinEligibility CheckinEligibility { get; private set; }
        public CheckedinStatus CheckedinStatus { get; private set; }
        public Designator Designator { get; private set; }
        
        public IReadOnlyList<Passenger> Passengers => _passengers.AsReadOnly();
        public IReadOnlyList<Segment> Segments => _segments.AsReadOnly();

        // Private constructor for Entity Framework
        private Journey()
        {
            _passengers = new List<Passenger>();
            _segments = new List<Segment>();
            JourneyKey = string.Empty;
            FlightType = string.Empty;
            ProductClass = string.Empty;
            CheckinEligibility = new CheckinEligibility("schedule", "");
            Designator = new Designator("DEL", "BOM", DateTime.UtcNow.AddHours(2), DateTime.UtcNow);
        }

        public Journey(string journeyKey, string flightType, string productClass, 
                      bool isInternational, bool isCodeshare, Designator designator)
        {
            JourneyKey = journeyKey;
            FlightType = flightType ?? string.Empty;
            ProductClass = productClass ?? string.Empty;
            IsInternational = isInternational;
            IsCodeshare = isCodeshare;
            Designator = designator;
            CheckinEligibility = new CheckinEligibility("schedule", "");
            CheckedinStatus = CheckedinStatus.None;
            Stops = 0;
            _passengers = new List<Passenger>();
            _segments = new List<Segment>();
        }

        public void AddPassenger(Passenger passenger)
        {
            _passengers.Add(passenger);
        }

        public void AddSegment(Segment segment)
        {
            _segments.Add(segment);
            Stops = Math.Max(0, _segments.Count - 1);
        }

        public void UpdateCheckinEligibility(CheckinEligibility eligibility)
        {
            CheckinEligibility = eligibility;
        }

        public void UpdateCheckedinStatus(CheckedinStatus status)
        {
            CheckedinStatus = status;
        }

        public bool IsEligibleForCheckIn()
        {
            return CheckinEligibility.IsEligible;
        }

        public bool HasAllPassengersCheckedIn()
        {
            return CheckedinStatus == CheckedinStatus.All;
        }

        public Passenger? GetPassenger(string passengerKey)
        {
            return _passengers.FirstOrDefault(p => p.PassengerKey == passengerKey);
        }
    }
}
