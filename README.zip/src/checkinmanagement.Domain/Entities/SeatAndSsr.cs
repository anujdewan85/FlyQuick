using System;
using System.Collections.Generic;
using System.Linq;
using checkinmanagement.Domain.ValueObjects;

namespace checkinmanagement.Domain.Entities
{
    /// <summary>
    /// Entity representing seats and SSRs assigned to a passenger for a specific segment
    /// </summary>
    public class SeatAndSsr
    {
        private readonly List<Seat> _seats;
        private readonly List<Ssr> _ssrs;

        public string SegmentKey { get; private set; }
        public IReadOnlyList<Seat> Seats => _seats.AsReadOnly();
        public IReadOnlyList<Ssr> Ssrs => _ssrs.AsReadOnly();

        // Private constructor for Entity Framework
        private SeatAndSsr()
        {
            _seats = new List<Seat>();
            _ssrs = new List<Ssr>();
            SegmentKey = string.Empty;
        }

        public SeatAndSsr(string segmentKey)
        {
            SegmentKey = segmentKey;
            _seats = new List<Seat>();
            _ssrs = new List<Ssr>();
        }

        public void AddSeat(Seat seat)
        {
            _seats.Add(seat);
        }

        public void AddSsr(Ssr ssr)
        {
            _ssrs.Add(ssr);
        }

        public void RemoveSeat(string seatUnitDesignator)
        {
            _seats.RemoveAll(s => s.SeatUnitDesignator == seatUnitDesignator);
        }

        public void RemoveSsr(string ssrNumber)
        {
            _ssrs.RemoveAll(s => s.SsrNumber == ssrNumber);
        }

        public bool HasSeats => _seats.Any();
        public bool HasSsrs => _ssrs.Any();
        public int SeatCount => _seats.Count;
        public int SsrCount => _ssrs.Count;

        public Seat? GetPrimarySeat()
        {
            return _seats.FirstOrDefault();
        }
    }
}
