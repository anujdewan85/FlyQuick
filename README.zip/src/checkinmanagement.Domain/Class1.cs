﻿namespace checkinmanagement.Domain
{
    public class Class1
    {

    }
}
