using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing flight identification details
    /// </summary>
    public class FlightIdentifier
    {
        public string Identifier { get; private set; }
        public string CarrierCode { get; private set; }
        public string OpSuffix { get; private set; }

        public FlightIdentifier(string carrierCode, string identifier, string opSuffix = "")
        {
            CarrierCode = carrierCode;
            Identifier = identifier;
            OpSuffix = opSuffix ?? string.Empty;
        }

        public string FlightNumber => $"{CarrierCode}{Identifier}{OpSuffix}";
        public bool HasOperatingSuffix => !string.IsNullOrWhiteSpace(OpSuffix);

        public override bool Equals(object? obj)
        {
            if (obj is FlightIdentifier other)
            {
                return Identifier == other.Identifier &&
                       CarrierCode == other.CarrierCode &&
                       OpSuffix == other.OpSuffix;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Identifier, CarrierCode, OpSuffix);
        }

        public override string ToString()
        {
            return FlightNumber;
        }
    }
}
