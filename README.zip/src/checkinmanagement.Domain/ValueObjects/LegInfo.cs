using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing flight leg operation details
    /// </summary>
    public class LegInfo
    {
        public string ArrivalTerminal { get; private set; }
        public string DepartureTerminal { get; private set; }
        public string EquipmentType { get; private set; }
        public string EquipmentTypeSuffix { get; private set; }
        public string OnTime { get; private set; }
        public string OperatingCarrier { get; private set; }
        public string OperatingFlightNumber { get; private set; }

        public LegInfo(string operatingCarrier, string operatingFlightNumber, 
                      string equipmentType, string departureTerminal = "", 
                      string arrivalTerminal = "", string onTime = "", 
                      string equipmentTypeSuffix = "")
        {
            OperatingCarrier = operatingCarrier ?? string.Empty;
            OperatingFlightNumber = operatingFlightNumber ?? string.Empty;
            EquipmentType = equipmentType ?? string.Empty;
            DepartureTerminal = departureTerminal ?? string.Empty;
            ArrivalTerminal = arrivalTerminal ?? string.Empty;
            OnTime = onTime ?? string.Empty;
            EquipmentTypeSuffix = equipmentTypeSuffix ?? string.Empty;
        }

        public bool IsCodeshare => !string.IsNullOrWhiteSpace(OperatingCarrier);
        public bool HasTerminalInfo => !string.IsNullOrWhiteSpace(DepartureTerminal) || 
                                      !string.IsNullOrWhiteSpace(ArrivalTerminal);
        public string FullEquipmentType => string.IsNullOrWhiteSpace(EquipmentTypeSuffix) 
            ? EquipmentType 
            : $"{EquipmentType}{EquipmentTypeSuffix}";

        public override bool Equals(object? obj)
        {
            if (obj is LegInfo other)
            {
                return ArrivalTerminal == other.ArrivalTerminal &&
                       DepartureTerminal == other.DepartureTerminal &&
                       EquipmentType == other.EquipmentType &&
                       EquipmentTypeSuffix == other.EquipmentTypeSuffix &&
                       OnTime == other.OnTime &&
                       OperatingCarrier == other.OperatingCarrier &&
                       OperatingFlightNumber == other.OperatingFlightNumber;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ArrivalTerminal, DepartureTerminal, EquipmentType, 
                                   EquipmentTypeSuffix, OnTime, OperatingCarrier, OperatingFlightNumber);
        }

        public override string ToString()
        {
            return $"{OperatingCarrier} {OperatingFlightNumber} ({EquipmentType})";
        }
    }
}
