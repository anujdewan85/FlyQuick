using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing a passenger seat assignment
    /// </summary>
    public class Seat
    {
        public string SeatUnitDesignator { get; private set; }
        public string Type { get; private set; }

        public Seat(string seatUnitDesignator, string type = "")
        {
            SeatUnitDesignator = seatUnitDesignator;
            Type = type ?? string.Empty;
        }

        public bool IsWindowSeat => SeatUnitDesignator.EndsWith("A", StringComparison.OrdinalIgnoreCase) ||
                                   SeatUnitDesignator.EndsWith("F", StringComparison.OrdinalIgnoreCase);
        
        public bool IsAisleSeat => SeatUnitDesignator.EndsWith("C", StringComparison.OrdinalIgnoreCase) ||
                                  SeatUnitDesignator.EndsWith("D", StringComparison.OrdinalIgnoreCase);
        
        public bool IsMiddleSeat => SeatUnitDesignator.EndsWith("B", StringComparison.OrdinalIgnoreCase) ||
                                   SeatUnitDesignator.EndsWith("E", StringComparison.OrdinalIgnoreCase);

        public bool IsPremiumSeat => Type.Contains("Premium", StringComparison.OrdinalIgnoreCase) ||
                                    Type.Contains("Extra", StringComparison.OrdinalIgnoreCase);

        public override bool Equals(object? obj)
        {
            if (obj is Seat other)
            {
                return SeatUnitDesignator == other.SeatUnitDesignator && Type == other.Type;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(SeatUnitDesignator, Type);
        }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(Type) ? SeatUnitDesignator : $"{SeatUnitDesignator} ({Type})";
        }
    }
}
