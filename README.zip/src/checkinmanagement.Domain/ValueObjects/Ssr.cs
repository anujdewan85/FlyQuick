using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing Special Service Request (SSR)
    /// </summary>
    public class Ssr(string ssrNumber, string ssrDetail)
    {
        public string SsrNumber { get; private set; } = ssrNumber;
        public string SsrDetail { get; private set; } = ssrDetail ?? string.Empty;
    }
}
