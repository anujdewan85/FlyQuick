using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing passenger loyalty information
    /// </summary>
    public class Loyalty
    {
        public string Tier { get; private set; }
        public string FfNumber { get; private set; }

        public Loyalty(string tier, string ffNumber)
        {
            Tier = tier ?? string.Empty;
            FfNumber = ffNumber ?? string.Empty;
        }

        public bool HasLoyaltyProgram => !string.IsNullOrWhiteSpace(FfNumber);
        public bool IsPremiumTier => !string.IsNullOrWhiteSpace(Tier) && 
                                    (Tier.Contains("Gold", StringComparison.OrdinalIgnoreCase) || 
                                     Tier.Contains("Platinum", StringComparison.OrdinalIgnoreCase));

        public override bool Equals(object? obj)
        {
            if (obj is Loyalty other)
            {
                return Tier == other.Tier && FfNumber == other.FfNumber;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Tier, FfNumber);
        }

        public override string ToString()
        {
            return $"Tier: {Tier}, FF: {FfNumber}";
        }
    }
}
