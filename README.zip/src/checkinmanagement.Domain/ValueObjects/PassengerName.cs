namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing passenger name components
    /// </summary>
    public class PassengerName(string first, string last, string middle = "", string title = "")
    {
        public string First { get; private set; } = first;
        public string Middle { get; private set; } = middle ?? string.Empty;
        public string Last { get; private set; } = last;
        public string Title { get; private set; } = title ?? string.Empty;
    }
}
