using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing flight route and timing information
    /// </summary>
    public class Designator
    {
        public string Destination { get; private set; }
        public string Origin { get; private set; }
        public DateTime UtcArrival { get; private set; }
        public DateTime UtcDeparture { get; private set; }

        public Designator(string destination, string origin, DateTime utcArrival, DateTime utcDeparture)
        {
            Destination = destination;
            Origin = origin;
            UtcArrival = utcArrival;
            UtcDeparture = utcDeparture;
        }

        public TimeSpan FlightDuration => UtcArrival - UtcDeparture;
        public bool IsToday => UtcDeparture.Date == DateTime.UtcNow.Date;

        public override bool Equals(object? obj)
        {
            if (obj is Designator other)
            {
                return Destination == other.Destination &&
                       Origin == other.Origin &&
                       UtcArrival == other.UtcArrival &&
                       UtcDeparture == other.UtcDeparture;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Destination, Origin, UtcArrival, UtcDeparture);
        }

        public override string ToString()
        {
            return $"{Origin} -> {Destination} ({UtcDeparture:yyyy-MM-dd HH:mm} - {UtcArrival:yyyy-MM-dd HH:mm} UTC)";
        }
    }
}
