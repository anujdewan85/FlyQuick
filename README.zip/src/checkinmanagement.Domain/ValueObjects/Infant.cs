using System.Globalization;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing infant passenger details
    /// </summary>
    public class Infant(PassengerName name, string dateOfBirth, string gender, string residentCountry)
    {
        private const int DefaultMaxInfantAgeDays = 730; // Default: 2 years
        
        public string DateOfBirth { get; private set; } = dateOfBirth;
        public string ResidentCountry { get; private set; } = residentCountry ?? string.Empty;
        public string Gender { get; private set; } = gender ?? string.Empty;
        public PassengerName Name { get; private set; } = name;

        public bool IsValidInfant(int maxAgeDays = DefaultMaxInfantAgeDays)
        {
            // Basic validation - infant should be under specified age
            if (DateTime.TryParse(DateOfBirth, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime birthDate))
            {
                var age = DateTime.UtcNow - birthDate;
                return age.TotalDays < maxAgeDays;
            }
            return false;
        }
    }
}
