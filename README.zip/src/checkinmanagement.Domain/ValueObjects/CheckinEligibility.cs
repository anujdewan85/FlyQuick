﻿using System;

namespace checkinmanagement.Domain.ValueObjects
{
    /// <summary>
    /// Value Object representing check-in eligibility status and reason
    /// </summary>
    public class CheckinEligibility
    {
        public string Status { get; private set; }
        public string Reason { get; private set; }

        public CheckinEligibility(string status, string reason)
        {
            Status = status ?? string.Empty;
            Reason = reason ?? string.Empty;
        }

        public bool IsEligible => Status.Equals("eligible", StringComparison.OrdinalIgnoreCase);
        public bool IsScheduled => Status.Equals("schedule", StringComparison.OrdinalIgnoreCase);
        public bool IsNotEligible => Status.Equals("not_eligible", StringComparison.OrdinalIgnoreCase);

        public override bool Equals(object? obj)
        {
            if (obj is CheckinEligibility other)
            {
                return Status == other.Status && Reason == other.Reason;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Status, Reason);
        }

        public override string ToString()
        {
            return $"Status: {Status}, Reason: {Reason}";
        }
    }
}
