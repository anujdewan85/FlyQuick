using checkinmanagement.Application.DTOs;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Reflection;

namespace checkinmanagement.Infrastructure.MockData
{
    public class MockDataLoader
    {
        private readonly ILogger<MockDataLoader> _logger;
        private readonly MockJourneyData? _journeyData;
        private readonly MockErrorData? _errorData;
        private readonly MockContactData? _contactData;

        public MockDataLoader(ILogger<MockDataLoader> logger)
        {
            _logger = logger;
            
            try
            {
                _journeyData = LoadJourneyData();
                _errorData = LoadErrorData();
                _contactData = LoadContactData();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load mock data");
            }
        }

        public RetrieveJourneyResponse? FindJourneyResponse(RetrieveJourneyRequest request)
        {
            if (_journeyData?.Journeys == null)
            {
                _logger.LogWarning("Journey data is null or empty");
                return null;
            }

            foreach (var journey in _journeyData.Journeys)
            {
                if (IsMatch(journey.MatchCriteria, request))
                {
                    return journey.Response;
                }
            }

            // Check for specific error scenarios
            if (_errorData?.Errors != null)
            {
                foreach (var error in _errorData.Errors)
                {
                    if (IsErrorMatch(error.MatchCriteria, request))
                    {
                        return error.Response;
                    }
                }
            }

            // Return default error  
            return _errorData?.DefaultError ?? new RetrieveJourneyResponse
            {
                Success = false,
                BookingAggregate = null,
                ErrorMessage = "Journey not found",
                ErrorCode = "JOURNEY_NOT_FOUND"
            };
        }

        private MockJourneyData? LoadJourneyData()
        {
            var json = LoadEmbeddedResource("retrieve-journey-responses.json");
            if (json == null) return null;

            return JsonSerializer.Deserialize<MockJourneyData>(json, GetJsonSerializerOptions());
        }

        private MockErrorData? LoadErrorData()
        {
            var json = LoadEmbeddedResource("error-responses.json");
            if (json == null) return null;

            return JsonSerializer.Deserialize<MockErrorData>(json, GetJsonSerializerOptions());
        }

        private MockContactData? LoadContactData()
        {
            var json = LoadEmbeddedResource("contact-responses.json");
            if (json == null) return null;

            return JsonSerializer.Deserialize<MockContactData>(json, GetJsonSerializerOptions());
        }

        private static JsonSerializerOptions GetJsonSerializerOptions()
        {
            return new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                Converters = { new JsonStringEnumConverter() }
            };
        }

        private string? LoadEmbeddedResource(string fileName)
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                var resourceName = $"checkinmanagement.Infrastructure.MockData.{fileName}";
                
                // List all available resources for debugging
                var resourceNames = assembly.GetManifestResourceNames();
                
                using var stream = assembly.GetManifestResourceStream(resourceName);
                if (stream == null)
                {
                    _logger.LogWarning("Embedded resource not found: {ResourceName}", resourceName);
                    
                    // Try loading from file system as fallback
                    var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MockData", fileName);
                    
                    if (File.Exists(filePath))
                    {
                        var content = File.ReadAllText(filePath);
                        return content;
                    }
                    
                    _logger.LogWarning("Could not find mock data file: {FileName} at {FilePath}", fileName, filePath);
                    return null;
                }
                
                using var reader = new StreamReader(stream);
                var result = reader.ReadToEnd();
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading mock data file: {FileName}", fileName);
                return null;
            }
        }

        private bool IsMatch(MatchCriteria criteria, RetrieveJourneyRequest request)
        {
            // Handle BookingReference scenario (option 1)
            if (!string.IsNullOrEmpty(request.BookingReference))
            {
                var match = string.Equals(criteria.BookingReference, request.BookingReference, StringComparison.OrdinalIgnoreCase);
                return match;
            }

            // Handle PNR-based scenarios (options 2 & 3)
            if (!string.IsNullOrEmpty(request.PNR))
            {
                // PNR must match
                if (!string.Equals(criteria.PnR, request.PNR, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }

                // If criteria has lastName, request must have matching lastName (option 2)
                if (!string.IsNullOrEmpty(criteria.LastName))
                {
                    var lastNameMatch = string.Equals(criteria.LastName, request.LastName, StringComparison.OrdinalIgnoreCase);
                    return lastNameMatch;
                }

                // If criteria has email, request must have matching email (option 3)
                if (!string.IsNullOrEmpty(criteria.Email))
                {
                    var emailMatch = string.Equals(criteria.Email, request.EmailId, StringComparison.OrdinalIgnoreCase);
                    return emailMatch;
                }

                // If criteria only has PNR, that's enough
                return true;
            }

            return false;
        }

        private bool IsErrorMatch(ErrorMatchCriteria criteria, RetrieveJourneyRequest request)
        {
            // Handle BookingReference scenario
            if (!string.IsNullOrEmpty(request.BookingReference))
            {
                return string.Equals(criteria.BookingReference, request.BookingReference, StringComparison.OrdinalIgnoreCase);
            }

            // Handle PNR scenario
            if (!string.IsNullOrEmpty(request.PNR))
            {
                return string.Equals(criteria.PnR, request.PNR, StringComparison.OrdinalIgnoreCase);
            }

            return false;
        }

        public JourneyDto? FindJourneyByKey(string journeyKey)
        {
            if (_journeyData?.Journeys == null || string.IsNullOrWhiteSpace(journeyKey))
                return null;

            foreach (var journey in _journeyData.Journeys)
            {
                if (journey.Response?.BookingAggregate?.Journeys != null)
                {
                    var foundJourney = journey.Response.BookingAggregate.Journeys
                        .FirstOrDefault(j => string.Equals(j.JourneyKey, journeyKey, StringComparison.OrdinalIgnoreCase));
                    
                    if (foundJourney != null)
                    {
                        return foundJourney;
                    }
                }
            }

            return null;
        }

        public IEnumerable<ContactDto> GetContactsByJourneyKey(string journeyKey)
        {
            if (string.IsNullOrWhiteSpace(journeyKey) || _contactData?.Contacts == null)
                return Enumerable.Empty<ContactDto>();

            var contacts = _contactData.Contacts
                .Where(c => string.Equals(c.JourneyKey, journeyKey, StringComparison.OrdinalIgnoreCase))
                .Select(contact => new ContactDto
                {
                    JourneyKey = contact.JourneyKey,
                    PhoneNumber = contact.PhoneNumber,
                    Email = contact.Email,
                    Type = contact.Type
                })
                .ToList();
            
            return contacts;
        }
    }

    // Data models for JSON deserialization
    public class MockJourneyData
    {
        public List<MockJourney> Journeys { get; set; } = [];
    }

    public class MockJourney
    {
        public MatchCriteria MatchCriteria { get; set; } = new();
        public RetrieveJourneyResponse Response { get; set; } = new();
    }

    public class MatchCriteria
    {
        [JsonPropertyName("pnr")]
        public string PnR { get; set; } = string.Empty;
        
        [JsonPropertyName("lastName")]
        public string? LastName { get; set; }
        
        [JsonPropertyName("email")]
        public string? Email { get; set; }
        
        [JsonPropertyName("bookingReference")]
        public string? BookingReference { get; set; }
    }

    public class MockErrorData
    {
        public List<MockError> Errors { get; set; } = new();
        public RetrieveJourneyResponse DefaultError { get; set; } = new();
    }

    public class MockError
    {
        public ErrorMatchCriteria MatchCriteria { get; set; } = new();
        public RetrieveJourneyResponse Response { get; set; } = new();
    }

    public class ErrorMatchCriteria
    {
        public string PnR { get; set; } = string.Empty;
        public string? BookingReference { get; set; }
    }

    public class MockContactData
    {
        public List<MockContact> Contacts { get; set; } = new();
    }

    public class MockContact
    {
        public string JourneyKey { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
    }
}
