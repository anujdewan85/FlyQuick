using checkinmanagement.Infrastructure.ExternalServices.Common.Mappers;
using checkinmanagement.Application.DTOs;
using Mapster;

namespace checkinmanagement.Infrastructure.Demo
{
    /// <summary>
    /// Demo class showing how to use Mapster with direct JSON to DTO mapping
    /// </summary>
    public static class MapsterDemo
    {
        /// <summary>
        /// Initialize all Mapster configurations
        /// Call this once at application startup
        /// </summary>
        public static void InitializeMapsterConfigurations()
        {
            // This configures the GraphQL dynamic object mappings to Application DTOs
            NavitaireGraphQLMapper.EnsureConfigured();
        }

        /// <summary>
        /// Example of how the GraphQL dynamic mapping works
        /// This shows the direct GraphQL dynamic object to Application DTO approach:
        /// 1. GraphQL dynamic response goes directly to Application DTOs using Mapster
        /// 2. No intermediate JSON parsing or infrastructure models needed
        /// 3. Better performance and cleaner architecture
        /// </summary>
        public static void ExampleUsage()
        {
            // Direct GraphQL mapping example:
            var exampleGraphQLResponse = new { }; // Real dynamic object from GraphQL.Client
            _ = exampleGraphQLResponse.Adapt<BookingAggregateDto>();
            
            // Benefits of this direct GraphQL approach:
            // ✅ No JSON serialization/deserialization overhead
            // ✅ No intermediate infrastructure models
            // ✅ Direct mapping from GraphQL dynamic objects to Application DTOs
            // ✅ Better performance and memory usage
            // ✅ Cleaner architecture following Clean Architecture principles
            // ✅ Type-safe mapping with compile-time checks
            // ✅ Extensible for multiple GraphQL operations
        }
    }
}
