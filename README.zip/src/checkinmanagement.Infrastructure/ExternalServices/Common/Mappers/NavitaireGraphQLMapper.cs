using Mapster;
using checkinmanagement.Application.DTOs;

namespace checkinmanagement.Infrastructure.ExternalServices.Common.Mappers
{
    /// <summary>
    /// Simplified Mapster mapper for Navitaire GraphQL responses
    /// Focuses only on essential mappings without over-engineering
    /// </summary>
    public static class NavitaireGraphQLMapper
    {
        static NavitaireGraphQLMapper()
        {
            ConfigureEssentialMappings();
        }

        /// <summary>
        /// Public method to ensure Mapster configurations are initialized
        /// </summary>
        public static void EnsureConfigured()
        {
            // Static constructor will have already run
        }

        /// <summary>
        /// Maps GraphQL booking response data to BookingAggregateDto using Mapster
        /// </summary>
        /// <param name="bookingData">Dynamic booking data from GraphQL response</param>
        /// <returns>Mapped BookingAggregateDto</returns>
        public static BookingAggregateDto MapBookingData(dynamic bookingData)
        {
            if (bookingData == null)
            {
                throw new ArgumentNullException(nameof(bookingData), "Booking data cannot be null");
            }

            try
            {
                // Use Mapster with our simplified configuration
                return ((object)bookingData).Adapt<BookingAggregateDto>();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to map booking data: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Configure only essential Mapster mappings for booking operations
        /// </summary>
        private static void ConfigureEssentialMappings()
        {
            // Main booking mapping - focus on what's actually needed
            TypeAdapterConfig<object, BookingAggregateDto>
                .NewConfig()
                .Map(dest => dest.BookingReference, src => GetValue(src, "recordLocator"))
                .Map(dest => dest.Pnr, src => GetValue(src, "recordLocator"))
                .Map(dest => dest.ContactLastName, src => ExtractContactLastName(src))
                .Map(dest => dest.ContactEmailId, src => ExtractContactEmail(src))
                .Map(dest => dest.LastUpdated, src => DateTime.UtcNow)
                .Map(dest => dest.Status, src => "Retrieved")
                .Map(dest => dest.Journeys, src => GetValue(src, "journeys"));

            // Journey mapping - simplified
            TypeAdapterConfig<object, JourneyDto>
                .NewConfig()
                .Map(dest => dest.JourneyKey, src => GetValue(src, "journeyKey"))
                .Map(dest => dest.FlightType, src => GetValue(src, "flightType"))
                .Map(dest => dest.Stops, src => GetIntValue(src, "stops"))
                .Map(dest => dest.ProductClass, src => ExtractFirstSegmentValue(src, "cabinOfService"))
                .Map(dest => dest.IsInternational, src => CheckAnySegmentBool(src, "international"))
                .Map(dest => dest.IsCodeshare, src => false) // Simplified for now
                .Map(dest => dest.CheckinEligibility, src => new CheckinEligibilityDto { Status = "Unknown", Reason = "Not implemented" })
                .Map(dest => dest.CheckedinStatus, src => "Unknown")
                .Map(dest => dest.Designator, src => GetValue(src, "designator"))
                .Map(dest => dest.Passengers, src => new List<PassengerDto>())
                .Map(dest => dest.Segments, src => GetValue(src, "segments"));

            // Designator mapping
            TypeAdapterConfig<object, DesignatorDto>
                .NewConfig()
                .Map(dest => dest.Origin, src => GetValue(src, "origin"))
                .Map(dest => dest.Destination, src => GetValue(src, "destination"))
                .Map(dest => dest.UtcDeparture, src => ParseDateTime(GetValue(src, "departure")))
                .Map(dest => dest.UtcArrival, src => ParseDateTime(GetValue(src, "arrival")));

            // Segment mapping - only essential fields
            TypeAdapterConfig<object, SegmentDto>
                .NewConfig()
                .Map(dest => dest.SegmentKey, src => GetValue(src, "segmentKey"))
                .Map(dest => dest.ProductClass, src => GetValue(src, "cabinOfService"))
                .Map(dest => dest.IsInternational, src => GetBoolValue(src, "international"))
                // Set defaults for fields we don't need right now
                .Map(dest => dest.Destination, src => string.Empty)
                .Map(dest => dest.DestinationName, src => string.Empty)
                .Map(dest => dest.DestinationCityName, src => string.Empty)
                .Map(dest => dest.Origin, src => string.Empty)
                .Map(dest => dest.OriginName, src => string.Empty)
                .Map(dest => dest.OriginCityName, src => string.Empty)
                .Map(dest => dest.UtcArrival, src => DateTime.MinValue)
                .Map(dest => dest.UtcDeparture, src => DateTime.MinValue)
                .Map(dest => dest.Identifier, src => new FlightIdentifierDto())
                .Map(dest => dest.ExternalIdentifier, src => new FlightIdentifierDto())
                .Map(dest => dest.LegInfo, src => new List<LegInfoDto>());
        }

        // Simplified helper methods
        private static string GetValue(object obj, string propertyName)
        {
            try
            {
                if (obj is IDictionary<string, object> dict && dict.TryGetValue(propertyName, out var value))
                    return value?.ToString() ?? string.Empty;
                
                var property = obj?.GetType().GetProperty(propertyName);
                return property?.GetValue(obj)?.ToString() ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static int GetIntValue(object obj, string propertyName)
        {
            var value = GetValue(obj, propertyName);
            return int.TryParse(value, out int result) ? result : 0;
        }

        private static bool GetBoolValue(object obj, string propertyName)
        {
            var value = GetValue(obj, propertyName);
            return bool.TryParse(value, out bool result) && result;
        }

        private static DateTime ParseDateTime(string dateString)
        {
            return DateTime.TryParse(dateString, System.Globalization.CultureInfo.InvariantCulture, 
                System.Globalization.DateTimeStyles.None, out var result) ? result : DateTime.MinValue;
        }

        private static string ExtractFirstSegmentValue(object journey, string propertyName)
        {
            try
            {
                if (journey is IDictionary<string, object> dict && 
                    dict.TryGetValue("segments", out var segments) &&
                    segments is IEnumerable<object> segmentList)
                {
                    var firstSegment = segmentList.FirstOrDefault();
                    return firstSegment != null ? GetValue(firstSegment, propertyName) : string.Empty;
                }
                return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static bool CheckAnySegmentBool(object journey, string propertyName)
        {
            try
            {
                if (journey is IDictionary<string, object> dict && 
                    dict.TryGetValue("segments", out var segments) &&
                    segments is IEnumerable<object> segmentList)
                {
                    return segmentList.Any(segment => GetBoolValue(segment, propertyName));
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        private static string ExtractContactLastName(object booking)
        {
            try
            {
                if (booking is IDictionary<string, object> dict && 
                    dict.TryGetValue("contacts", out var contacts) &&
                    contacts is IEnumerable<object> contactList)
                {
                    var firstContact = contactList.FirstOrDefault();
                    return firstContact != null ? GetValue(firstContact, "lastName") : string.Empty;
                }
                return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string ExtractContactEmail(object booking)
        {
            try
            {
                if (booking is IDictionary<string, object> dict && 
                    dict.TryGetValue("contacts", out var contacts) &&
                    contacts is IEnumerable<object> contactList)
                {
                    var firstContact = contactList.FirstOrDefault();
                    return firstContact != null ? GetValue(firstContact, "emailAddress") : string.Empty;
                }
                return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
