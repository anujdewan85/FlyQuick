using System.Net;

namespace checkinmanagement.Infrastructure.ExternalServices.Common.Constants
{
    /// <summary>
    /// Error codes for external service calls
    /// Maps HTTP status codes to meaningful application error codes
    /// </summary>
    public static class NavitaireErrorCodes
    {
        // Success
        public const string Success = "SUCCESS";

        // Client Errors (4xx)
        public const string BadRequest = "BAD_REQUEST";
        public const string Unauthorized = "UNAUTHORIZED";
        public const string Forbidden = "FORBIDDEN";
        public const string NotFound = "NOT_FOUND";
        public const string MethodNotAllowed = "METHOD_NOT_ALLOWED";
        public const string RequestTimeout = "REQUEST_TIMEOUT";
        public const string Conflict = "CONFLICT";
        public const string UnprocessableEntity = "UNPROCESSABLE_ENTITY";
        public const string TooManyRequests = "TOO_MANY_REQUESTS";

        // Server Errors (5xx)
        public const string InternalServerError = "INTERNAL_SERVER_ERROR";
        public const string BadGateway = "BAD_GATEWAY";
        public const string ServiceUnavailable = "SERVICE_UNAVAILABLE";
        public const string GatewayTimeout = "GATEWAY_TIMEOUT";

        // Application Specific Errors
        public const string NetworkError = "NETWORK_ERROR";
        public const string TimeoutError = "TIMEOUT_ERROR";
        public const string MappingError = "MAPPING_ERROR";
        public const string InvalidResponse = "INVALID_RESPONSE";
        public const string GraphQLError = "GRAPHQL_ERROR";

        /// <summary>
        /// Maps HTTP status code to application error code
        /// </summary>
        public static string MapHttpStatusToErrorCode(HttpStatusCode statusCode)
        {
            return statusCode switch
            {
                HttpStatusCode.BadRequest => BadRequest,
                HttpStatusCode.Unauthorized => Unauthorized,
                HttpStatusCode.Forbidden => Forbidden,
                HttpStatusCode.NotFound => NotFound,
                HttpStatusCode.MethodNotAllowed => MethodNotAllowed,
                HttpStatusCode.RequestTimeout => RequestTimeout,
                HttpStatusCode.Conflict => Conflict,
                HttpStatusCode.UnprocessableEntity => UnprocessableEntity,
                HttpStatusCode.TooManyRequests => TooManyRequests,
                HttpStatusCode.InternalServerError => InternalServerError,
                HttpStatusCode.BadGateway => BadGateway,
                HttpStatusCode.ServiceUnavailable => ServiceUnavailable,
                HttpStatusCode.GatewayTimeout => GatewayTimeout,
                _ => $"HTTP_{(int)statusCode}"
            };
        }

        /// <summary>
        /// Gets user-friendly error message for status code
        /// </summary>
        public static string GetErrorMessage(HttpStatusCode statusCode)
        {
            return statusCode switch
            {
                HttpStatusCode.BadRequest => "Invalid request parameters",
                HttpStatusCode.Unauthorized => "Authentication required",
                HttpStatusCode.Forbidden => "Access denied",
                HttpStatusCode.NotFound => "Booking not found",
                HttpStatusCode.MethodNotAllowed => "Invalid request method",
                HttpStatusCode.RequestTimeout => "Request timed out",
                HttpStatusCode.Conflict => "Data conflict detected",
                HttpStatusCode.UnprocessableEntity => "Invalid data provided",
                HttpStatusCode.TooManyRequests => "Rate limit exceeded",
                HttpStatusCode.InternalServerError => "External service error",
                HttpStatusCode.BadGateway => "Gateway error",
                HttpStatusCode.ServiceUnavailable => "Service temporarily unavailable",
                HttpStatusCode.GatewayTimeout => "Service timeout",
                _ => $"External service returned HTTP {(int)statusCode}"
            };
        }

        /// <summary>
        /// Gets HTTP status code for application error code
        /// </summary>
        public static int GetHttpStatusCode(string errorCode)
        {
            return errorCode switch
            {
                BadRequest => 400,
                Unauthorized => 401,
                Forbidden => 403,
                NotFound => 404,
                MethodNotAllowed => 405,
                RequestTimeout => 408,
                Conflict => 409,
                UnprocessableEntity => 422,
                TooManyRequests => 429,
                InternalServerError => 500,
                BadGateway => 502,
                ServiceUnavailable => 503,
                GatewayTimeout => 504,
                NetworkError => 503,
                TimeoutError => 408,
                MappingError => 500,
                InvalidResponse => 502,
                GraphQLError => 500,
                _ => 500 // Default to Internal Server Error
            };
        }

        /// <summary>
        /// Determines if the error is retryable
        /// </summary>
        public static bool IsRetryableError(HttpStatusCode statusCode)
        {
            return statusCode switch
            {
                HttpStatusCode.RequestTimeout => true,
                HttpStatusCode.TooManyRequests => true,
                HttpStatusCode.InternalServerError => true,
                HttpStatusCode.BadGateway => true,
                HttpStatusCode.ServiceUnavailable => true,
                HttpStatusCode.GatewayTimeout => true,
                _ => false
            };
        }
    }
}
