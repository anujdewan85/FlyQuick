using checkinmanagement.Application.DTOs;
using checkinmanagement.Application.Interfaces.ExternalServices;
using checkinmanagement.Infrastructure.MockData;
using Microsoft.Extensions.Logging;

namespace checkinmanagement.Infrastructure.ExternalServices.Mock
{
    public class MockNavitaireService : INavitaireService
    {
        private readonly ILogger<MockNavitaireService> _logger;
        private readonly MockDataLoader _mockDataLoader;

        public MockNavitaireService(
            ILogger<MockNavitaireService> logger,
            MockDataLoader mockDataLoader)
        {
            _logger = logger;
            _mockDataLoader = mockDataLoader;
        }

        public Task<RetrieveJourneyResponse> RetrieveJourneyAsync(
            RetrieveJourneyRequest request, 
            CancellationToken cancellationToken = default)
        {
            try
            {
                string logKey = GetLogKey(request);
                _logger.LogDebug("Using JSON mock data");

                return Task.FromResult(GetResponseFromJsonData(request));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in mock service");
                return Task.FromResult(new RetrieveJourneyResponse
                {
                    Success = false,
                    BookingAggregate = null,
                    ErrorMessage = "Internal server error",
                    ErrorCode = "INTERNAL_ERROR"
                });
            }
        }

        public Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default)
        {
            // Mock service is always healthy (uses local JSON data)
            return Task.FromResult(true);
        }

        private RetrieveJourneyResponse GetResponseFromJsonData(RetrieveJourneyRequest request)
        {
            var response = _mockDataLoader.FindJourneyResponse(request);
            
            if (response == null)
            {
                string logKey = GetLogKey(request);
                _logger.LogWarning("No mock data found for: {LogKey}", logKey);
                return new RetrieveJourneyResponse
                {
                    Success = false,
                    BookingAggregate = null,
                    ErrorMessage = "Journey not found",
                    ErrorCode = "JOURNEY_NOT_FOUND"
                };
            }

            string successLogKey = GetLogKey(request);
            
            return response;
        }

        private static string GetLogKey(RetrieveJourneyRequest request)
        {
            if (!string.IsNullOrEmpty(request.BookingReference))
                return $"BookingReference: {request.BookingReference}";
            
            if (!string.IsNullOrEmpty(request.PNR) && !string.IsNullOrEmpty(request.LastName))
                return $"PNR: {request.PNR}, LastName: {request.LastName}";
            
            if (!string.IsNullOrEmpty(request.PNR) && !string.IsNullOrEmpty(request.EmailId))
                return $"PNR: {request.PNR}, EmailId: {request.EmailId}";
            
            return "Unknown";
        }

        public JourneyDto? FindJourneyByKey(string journeyKey)
        {
            try
            {
                _logger.LogDebug("Searching for journey with key: {JourneyKey}", journeyKey);
                return _mockDataLoader.FindJourneyByKey(journeyKey);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error finding journey by key: {JourneyKey}", journeyKey);
                return null;
            }
        }

        public Task<IEnumerable<ContactDto>> GetContactsByJourneyKeyAsync(string journeyKey)
        {
            try
            {
                _logger.LogDebug("Getting contacts for journey key: {JourneyKey}", journeyKey);
                var contacts = _mockDataLoader.GetContactsByJourneyKey(journeyKey);
                return Task.FromResult(contacts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting contacts for journey key: {JourneyKey}", journeyKey);
                return Task.FromResult(Enumerable.Empty<ContactDto>());
            }
        }
    }
}
