using checkinmanagement.Application.Interfaces.ExternalServices;
using checkinmanagement.Infrastructure.ExternalServices.GraphQL;
using checkinmanagement.Infrastructure.ExternalServices.Mock;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using GraphQL.Client.Abstractions;

namespace checkinmanagement.Infrastructure.ExternalServices
{
    public class NavitaireServiceFactory(
        IConfiguration configuration,
        IServiceProvider serviceProvider) : INavitaireServiceFactory
    {
        private readonly IConfiguration _configuration = configuration;
        private readonly IServiceProvider _serviceProvider = serviceProvider;
        private INavitaireService? _cachedService;
        private readonly SemaphoreSlim _semaphore = new(1, 1);

        public async Task<INavitaireService> CreateServiceAsync(CancellationToken cancellationToken = default)
        {
            if (_cachedService != null)
                return _cachedService;

            await _semaphore.WaitAsync(cancellationToken);
            try
            {
                if (_cachedService != null)
                    return _cachedService;

                _cachedService = await CreateServiceInternalAsync();
                return _cachedService;
            }
            finally
            {
                _semaphore.Release();
            }
        }

        public INavitaireService CreateService()
        {
            return CreateServiceAsync().GetAwaiter().GetResult();
        }

        private async Task<INavitaireService> CreateServiceInternalAsync()
        {
            var useRealService = _configuration.GetValue<bool>("NavitaireService:UseRealService", false);
            
            if (useRealService)
            {
                var realServiceLogger = _serviceProvider.GetRequiredService<ILogger<NavitaireGraphQLService>>();
                var graphQLClient = _serviceProvider.GetRequiredService<IGraphQLClient>();
                var realService = new NavitaireGraphQLService(
                    realServiceLogger,
                    graphQLClient);
                // Simulate async operation
                await Task.CompletedTask;
                return realService;
            }

            var mockServiceLogger = _serviceProvider.GetRequiredService<ILogger<MockNavitaireService>>();
            var mockService = new MockNavitaireService(
                mockServiceLogger,
                _serviceProvider.GetRequiredService<checkinmanagement.Infrastructure.MockData.MockDataLoader>());
            // Simulate async operation
            await Task.CompletedTask;
            return mockService;
        }
    }
}
