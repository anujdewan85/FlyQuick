namespace checkinmanagement.Infrastructure.ExternalServices.GraphQL.Queries
{
    /// <summary>
    /// Contains all GraphQL queries for Navitaire API
    /// Centralizes query management for better maintainability
    /// </summary>
    public static class NavitaireGraphQLQueries
    {
        /// <summary>
        /// GraphQL mutation for booking retrieval with comprehensive journey and passenger data
        /// </summary>
        public static readonly string BookingRetrievev3 = @"
            mutation BookingRetrievev3($emailAddress: String, $recordLocator: String, $lastName: String) {
                bookingRetrievev3(request: {
                    emailAddress: $emailAddress
                    recordLocator: $recordLocator
                    lastName: $lastName
                }) {
                    bookingKey
                    currencyCode
                    groupName
                    recordLocator
                    selfServiceMoveAvailable
                    systemCode
                    journeys {
                        flightType
                        journeyKey
                        notForGeneralUser
                        stops
                        designator {
                            departure
                            origin
                            arrival
                            destination
                        }
                        segments {
                            cabinOfService
                            changeReasonCode
                            channelType
                            flightReference
                            priorityCode
                            salesDate
                            segmentKey
                            segmentType
                            status
                            legs {
                                legInfo {
                                    arrivalTerminal
                                    departureTerminal
                                    equipmentType
                                    equipmentTypeSuffix
                                    operatingCarrier
                                    operatingFlightNumber
                                    codeShareIndicator
                                }
                            }
                            externalIdentifier {
                                identifier
                                opSuffix
                                carrierCode
                            }
                            identifier {
                                opSuffix
                                identifier
                                carrierCode
                            }
                            designator {
                                destination
                                origin
                                arrival
                                departure
                            }
                            international
                        }
                    }
                    passengers {
                        key
                        value {
                            customerNumber
                            discountCode
                            passengerKey
                            passengerTypeCode
                            weightCategory
                            info {
                                nationality
                                gender
                                dateOfBirth
                            }
                            name {
                                first
                                last
                                title
                                middle
                            }
                        }
                    }
                    queues {
                        passengerId
                        flightReference
                    }
                    contacts { 
                        value { 
                            customerNumber
                            emailAddress
                            lastName
                            firstName
                        } 
                    }
                    breakdown { 
                        passengers { 
                            value { 
                                infant { 
                                    adjustments 
                                    taxes 
                                    total 
                                } 
                            } 
                        } 
                    }
                }
            }";

        /// <summary>
        /// Simplified booking retrieval query for basic information only
        /// </summary>
        public static readonly string BookingRetrievev3Basic = @"
            mutation BookingRetrievev3Basic($emailAddress: String, $recordLocator: String, $lastName: String) {
                bookingRetrievev3(request: {
                    emailAddress: $emailAddress
                    recordLocator: $recordLocator
                    lastName: $lastName
                }) {
                    bookingKey
                    recordLocator
                    journeys {
                        journeyKey
                        flightType
                        stops
                        designator {
                            departure
                            origin
                            arrival
                            destination
                        }
                    }
                }
            }";

        /// <summary>
        /// Query for journey-specific information
        /// </summary>
        public static readonly string JourneyDetails = @"
            query JourneyDetails($journeyKey: String!) {
                journey(journeyKey: $journeyKey) {
                    journeyKey
                    flightType
                    stops
                    segments {
                        segmentKey
                        cabinOfService
                        international
                        designator {
                            destination
                            origin
                            arrival
                            departure
                        }
                        identifier {
                            identifier
                            carrierCode
                            opSuffix
                        }
                    }
                }
            }";

        /// <summary>
        /// Query for passenger-specific information
        /// </summary>
        public static readonly string PassengerDetails = @"
            query PassengerDetails($passengerKey: String!) {
                passenger(passengerKey: $passengerKey) {
                    passengerKey
                    passengerTypeCode
                    name {
                        first
                        last
                        title
                        middle
                    }
                    info {
                        nationality
                        gender
                        dateOfBirth
                    }
                }
            }";

        /// <summary>
        /// Health check query for service availability
        /// </summary>
        public static readonly string HealthCheck = @"
            query HealthCheck {
                __schema {
                    queryType {
                        name
                    }
                }
            }";
    }
}
