using checkinmanagement.Application.DTOs;
using checkinmanagement.Application.Interfaces.ExternalServices;
using checkinmanagement.Infrastructure.ExternalServices.Common.Constants;
using checkinmanagement.Infrastructure.ExternalServices.Common.Mappers;
using checkinmanagement.Infrastructure.ExternalServices.GraphQL.Queries;
using checkinmanagement.Infrastructure.ExternalServices.GraphQL.ResponseBuilders;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text;
using GraphQL;
using Mapster;
using GraphQL.Client.Abstractions;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.SystemTextJson;
using System.Net;

namespace checkinmanagement.Infrastructure.ExternalServices.GraphQL
{
    /// <summary>
    /// GraphQL implementation of Navitaire service
    /// Handles GraphQL queries to Navitaire API with direct response mapping
    /// </summary>
    public class NavitaireGraphQLService(
        ILogger<NavitaireGraphQLService> logger,
        IGraphQLClient graphQLClient) : INavitaireService
    {
    private readonly ILogger<NavitaireGraphQLService> _logger = logger;
    private readonly IGraphQLClient _graphQLClient = graphQLClient ?? throw new ArgumentNullException(nameof(graphQLClient));

        static NavitaireGraphQLService()
        {
            // Ensure Mapster configurations are loaded
            NavitaireGraphQLMapper.EnsureConfigured();
        }

        public async Task<RetrieveJourneyResponse> RetrieveJourneyAsync(
            RetrieveJourneyRequest request, 
            CancellationToken cancellationToken = default)
        {
            try
            {
                _logger.LogInformation("Starting RetrieveJourney operation for request: {@Request}", request);
                
                // Use centralized GraphQL query for booking retrieve
            var graphQLQuery = NavitaireGraphQLQueries.BookingRetrievev3;

            // Only include non-null variables for booking retrieve
            var variablesDict = new Dictionary<string, object?>();
            if (!string.IsNullOrEmpty(request.EmailId)) variablesDict["emailAddress"] = request.EmailId;
            if (!string.IsNullOrEmpty(request.PNR)) variablesDict["recordLocator"] = request.PNR;
            else if (!string.IsNullOrEmpty(request.BookingReference)) variablesDict["recordLocator"] = request.BookingReference;
            if (!string.IsNullOrEmpty(request.LastName)) variablesDict["lastName"] = request.LastName;

            // Execute the booking retrieve query using the generic method
            return await ExecuteGenericGraphQLRequestAsync(
                graphQLQuery, 
                variablesDict, 
                "bookingRetrievev3",
                BookingResponseBuilder.BuildRetrieveJourneyResponse,
                cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in RetrieveJourney operation");
                return new RetrieveJourneyResponse
                {
                    Success = false,
                    ErrorMessage = "An unexpected error occurred",
                    ErrorCode = NavitaireErrorCodes.InternalServerError,
                    HttpStatusCode = NavitaireErrorCodes.GetHttpStatusCode(NavitaireErrorCodes.InternalServerError)
                };
            }
        }

        /// <summary>
        /// Fully generic method to execute any GraphQL request and return any response type
        /// Can be used for future operations that don't return RetrieveJourneyResponse
        /// </summary>
        private async Task<TResponse> ExecuteGenericGraphQLRequestAsync<TResponse>(
            string query,
            Dictionary<string, object?> variables,
            string operationName,
            Func<dynamic?, TResponse> responseBuilder,
            CancellationToken cancellationToken)
        {
            try
            {
                var gqlRequest = new GraphQLRequest
                {
                    Query = query,
                    Variables = variables
                };

                _logger.LogInformation("Sending GraphQL request: {OperationName}", operationName);
                var response = await _graphQLClient.SendQueryAsync<dynamic>(gqlRequest, cancellationToken);

                if (response.Errors != null && response.Errors.Length > 0)
                {
                    var errorMessage = string.Join("; ", response.Errors.Select(e => e.Message));
                    _logger.LogWarning("GraphQL errors: {Errors}", errorMessage);
                    
                    // Let the response builder handle error responses
                    return responseBuilder(null);
                }

                return responseBuilder(response.Data);
            }
            catch (GraphQLHttpRequestException gqlEx)
            {
                _logger.LogError(gqlEx, "GraphQL HTTP error calling Navitaire service");
                
                // Let the response builder handle exception responses
                return responseBuilder(null);
            }
        }

        public async Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                // Simple GraphQL introspection query to check if the service is available
                var healthQuery = new GraphQLRequest
                {
                    Query = "{ __typename }"
                };

                var response = await _graphQLClient.SendQueryAsync<object>(healthQuery, cancellationToken);
                return response.Errors == null || response.Errors.Length == 0;
            }
            catch
            {
                return false;
            }
        }

        public JourneyDto? FindJourneyByKey(string journeyKey)
        {
            // TODO: Implement real API call to find journey by key
            // For now, return null as this would require a specific API endpoint
            _logger.LogWarning("FindJourneyByKey not implemented for RealNavitaireService. JourneyKey: {JourneyKey}", journeyKey);
            return null;
        }

        public Task<IEnumerable<ContactDto>> GetContactsByJourneyKeyAsync(string journeyKey)
        {
            // TODO: Implement real API call to get contacts by journey key
            // For now, return empty list as this would require a specific API endpoint
            _logger.LogWarning("GetContactsByJourneyKeyAsync not implemented for RealNavitaireService. JourneyKey: {JourneyKey}", journeyKey);
            return Task.FromResult(Enumerable.Empty<ContactDto>());
        }
    }
}
