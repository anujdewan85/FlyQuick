using checkinmanagement.Application.DTOs;
using checkinmanagement.Infrastructure.ExternalServices.Common.Constants;
using checkinmanagement.Infrastructure.ExternalServices.Common.Mappers;
using System.Net;

namespace checkinmanagement.Infrastructure.ExternalServices.GraphQL.ResponseBuilders
{
    /// <summary>
    /// Builds responses for booking-related GraphQL operations
    /// Handles response transformation and error scenarios for booking endpoints
    /// </summary>
    public static class BookingResponseBuilder
    {
        /// <summary>
        /// Builds a RetrieveJourneyResponse from GraphQL response data
        /// Handles both success and error scenarios for booking retrieval
        /// </summary>
        public static RetrieveJourneyResponse BuildRetrieveJourneyResponse(dynamic? responseData)
        {
            if (responseData == null)
            {
                return new RetrieveJourneyResponse
                {
                    Success = false,
                    ErrorMessage = "No response data received",
                    ErrorCode = NavitaireErrorCodes.InvalidResponse,
                    HttpStatusCode = (int)HttpStatusCode.BadRequest
                };
            }

            try
            {
                // Extract booking data from GraphQL response structure
                var bookingData = responseData?.data?.bookingRetrievev3;

                if (bookingData == null)
                {
                    return new RetrieveJourneyResponse
                    {
                        Success = false,
                        ErrorMessage = "No booking data found in response",
                        ErrorCode = NavitaireErrorCodes.InvalidResponse,
                        HttpStatusCode = (int)HttpStatusCode.BadRequest
                    };
                }

                // Use NavitaireGraphQLMapper for proper mapping
                var bookingAggregate = NavitaireGraphQLMapper.MapBookingData(bookingData);

                return new RetrieveJourneyResponse
                {
                    Success = true,
                    BookingAggregate = bookingAggregate,
                    ErrorMessage = null,
                    ErrorCode = null
                };
            }
            catch (Exception ex)
            {
                return new RetrieveJourneyResponse
                {
                    Success = false,
                    ErrorMessage = $"Error processing response: {ex.Message}",
                    ErrorCode = NavitaireErrorCodes.InvalidResponse,
                    HttpStatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        // Future booking-related response builders can be added here:
        // public static BookingModificationResponse BuildBookingModificationResponse(dynamic? responseData)
        // public static BookingCancellationResponse BuildBookingCancellationResponse(dynamic? responseData)
    }
}
