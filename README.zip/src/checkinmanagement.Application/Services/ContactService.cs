using checkinmanagement.Application.DTOs;
using checkinmanagement.Application.Interfaces;
using checkinmanagement.Application.Interfaces.ExternalServices;
using Microsoft.Extensions.Logging;

namespace checkinmanagement.Application.Services
{
    /// <summary>
    /// Service for contact operations
    /// </summary>
    public class ContactService(INavitaireServiceFactory navitaireServiceFactory, ILogger<ContactService> logger) : IContactService
    {
        private readonly INavitaireServiceFactory _navitaireServiceFactory = navitaireServiceFactory;
        private readonly ILogger<ContactService> _logger = logger;

        /// <summary>
        /// Get contact information by journey key
        /// </summary>
        /// <param name="journeyKey">The journey key to get contacts for</param>
        /// <returns>List of contact information or empty list if not found</returns>
        public async Task<IEnumerable<ContactDto>> GetContactsByJourneyKeyAsync(string journeyKey)
        {
            _logger.LogInformation("Getting contacts for journey key: {JourneyKey}", journeyKey);

            try
            {
                var navitaireService = await _navitaireServiceFactory.CreateServiceAsync(CancellationToken.None);
                var contacts = await navitaireService.GetContactsByJourneyKeyAsync(journeyKey);
                
                if (contacts == null || !contacts.Any())
                {
                    _logger.LogWarning("No contacts found for journey key: {JourneyKey}", journeyKey);
                    return Enumerable.Empty<ContactDto>();
                }

                _logger.LogInformation("Successfully retrieved {ContactCount} contacts for journey key: {JourneyKey}", contacts.Count(), journeyKey);
                return contacts;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving contacts for journey key: {JourneyKey}", journeyKey);
                throw;
            }
        }
    }
}
