using checkinmanagement.Application.DTOs;
using checkinmanagement.Application.Interfaces;
using checkinmanagement.Application.Interfaces.ExternalServices;
using checkinmanagement.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace checkinmanagement.Application.Services
{
    public class JourneyService(
        INavitaireServiceFactory navitaireServiceFactory,
        ILogger<JourneyService> logger) : IJourneyService
    {
        private readonly INavitaireServiceFactory _navitaireServiceFactory = navitaireServiceFactory;
        private readonly ILogger<JourneyService> _logger = logger;

        public async Task<RetrieveJourneyResponse> RetrieveJourneyAsync(
            RetrieveJourneyRequest request, 
            CancellationToken cancellationToken = default)
        {
            var requestType = GetRequestType(request);
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Operation"] = nameof(RetrieveJourneyAsync),
                ["RequestType"] = requestType
            });

            try
            {
                var navitaireService = await _navitaireServiceFactory.CreateServiceAsync(cancellationToken);
                
                _logger.LogDebug("Navitaire service created successfully, calling retrieve journey");
                
                var response = await navitaireService.RetrieveJourneyAsync(request, cancellationToken);

                if (!response.Success)
                {
                    _logger.LogWarning("Journey retrieval failed: {ErrorCode} - {ErrorMessage}", 
                        response.ErrorCode, response.ErrorMessage);
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving journey for {RequestType}", requestType);
                return new RetrieveJourneyResponse
                {
                    Success = false,
                    BookingAggregate = null,
                    ErrorMessage = "An error occurred while retrieving journey information",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        public async Task<BookingAggregateDto?> GetJourneyListAsync(
            RetrieveJourneyRequest request,
            CancellationToken cancellationToken = default)
        {
            var requestType = GetRequestType(request);
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Operation"] = nameof(GetJourneyListAsync),
                ["RequestType"] = requestType
            });

            try
            {
                var navitaireService = await _navitaireServiceFactory.CreateServiceAsync(cancellationToken);
                
                _logger.LogDebug("Navitaire service created successfully, calling retrieve journey for list");
                
                var response = await navitaireService.RetrieveJourneyAsync(request, cancellationToken);
                _logger.LogInformation("Output === {@Response}", response);

                if (!response.Success || response.BookingAggregate == null)
                {
                    _logger.LogWarning("Journey list retrieval failed: {ErrorCode} - {ErrorMessage}",
                        response.ErrorCode, response.ErrorMessage);
                    return null;
                }

                return response.BookingAggregate;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving journey list for {RequestType}", requestType);
                return null;
            }
        }

        public async Task<JourneyDto?> GetJourneyByKeyAsync(
            string journeyKey,
            CancellationToken cancellationToken = default)
        {
            using var scope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["Operation"] = nameof(GetJourneyByKeyAsync),
                ["JourneyKey"] = journeyKey
            });

            try
            {
                var navitaireService = await _navitaireServiceFactory.CreateServiceAsync(cancellationToken);
                _logger.LogDebug("Searching for journey with key: {JourneyKey}", journeyKey);

                // Use the direct method to find journey by key
                var journey = navitaireService.FindJourneyByKey(journeyKey);

                if (journey != null)
                {
                    _logger.LogDebug("Found journey with key: {JourneyKey}", journeyKey);
                }
                else
                {
                    _logger.LogWarning("Journey not found with key: {JourneyKey}", journeyKey);
                }

                return journey;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving journey by key: {JourneyKey}", journeyKey);
                return null;
            }
        }

        private static string GetRequestType(RetrieveJourneyRequest request)
        {
            if (!string.IsNullOrEmpty(request.BookingReference))
                return "BookingReference";
            
            if (!string.IsNullOrEmpty(request.PNR) && !string.IsNullOrEmpty(request.LastName))
                return "PNR+LastName";
            
            if (!string.IsNullOrEmpty(request.PNR) && !string.IsNullOrEmpty(request.EmailId))
                return "PNR+Email";
            
            return "Unknown";
        }
    }
}
