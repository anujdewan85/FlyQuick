using checkinmanagement.Application.Validators;
using checkinmanagement.Domain.Entities;
using checkinmanagement.Domain.ValueObjects;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace checkinmanagement.Application.Extensions
{
    /// <summary>
    /// Extension methods for registering validation services
    /// </summary>
    public static class ValidationServiceCollectionExtensions
    {
        /// <summary>
        /// Registers all FluentValidation validators with the DI container
        /// </summary>
        public static IServiceCollection AddValidationServices(this IServiceCollection services)
        {
            // Register the validation service
            services.AddScoped<IValidationService, ValidationService>();

            // Register Entity Validators
            services.AddScoped<IValidator<Booking>, BookingValidator>();
            services.AddScoped<IValidator<Journey>, JourneyValidator>();
            services.AddScoped<IValidator<Passenger>, PassengerValidator>();
            services.AddScoped<IValidator<Segment>, SegmentValidator>();
            services.AddScoped<IValidator<SeatAndSsr>, SeatAndSsrValidator>();

            // Register Value Object Validators
            services.AddScoped<IValidator<CheckinEligibility>, CheckinEligibilityValidator>();
            services.AddScoped<IValidator<Designator>, DesignatorValidator>();
            services.AddScoped<IValidator<FlightIdentifier>, FlightIdentifierValidator>();
            services.AddScoped<IValidator<PassengerName>, PassengerNameValidator>();
            services.AddScoped<IValidator<Loyalty>, LoyaltyValidator>();
            services.AddScoped<IValidator<Infant>, InfantValidator>();
            services.AddScoped<IValidator<Seat>, SeatValidator>();
            services.AddScoped<IValidator<Ssr>, SsrValidator>();
            services.AddScoped<IValidator<LegInfo>, LegInfoValidator>();

            return services;
        }
    }
}
