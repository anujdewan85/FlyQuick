using checkinmanagement.Application.DTOs;

namespace checkinmanagement.Application.Interfaces
{
    public interface IJourneyService
    {
        Task<RetrieveJourneyResponse> RetrieveJourneyAsync(RetrieveJourneyRequest request, CancellationToken cancellationToken = default);
        Task<BookingAggregateDto?> GetJourneyListAsync(RetrieveJourneyRequest request, CancellationToken cancellationToken = default);
        Task<JourneyDto?> GetJourneyByKeyAsync(string journeyKey, CancellationToken cancellationToken = default);
    }
}
