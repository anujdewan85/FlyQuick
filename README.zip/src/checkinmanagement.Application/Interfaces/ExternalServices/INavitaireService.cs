using checkinmanagement.Application.DTOs;

namespace checkinmanagement.Application.Interfaces.ExternalServices
{
    public interface INavitaireService
    {
        Task<RetrieveJourneyResponse> RetrieveJourneyAsync(RetrieveJourneyRequest request, CancellationToken cancellationToken = default);
        Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default);
        JourneyDto? FindJourneyByKey(string journeyKey);
        Task<IEnumerable<ContactDto>> GetContactsByJourneyKeyAsync(string journeyKey);
    }
}
