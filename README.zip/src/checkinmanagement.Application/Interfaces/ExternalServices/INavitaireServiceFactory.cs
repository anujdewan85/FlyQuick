using checkinmanagement.Application.DTOs;

namespace checkinmanagement.Application.Interfaces.ExternalServices
{
    public interface INavitaireServiceFactory
    {
        Task<INavitaireService> CreateServiceAsync(CancellationToken cancellationToken = default);
        INavitaireService CreateService();
    }
}
