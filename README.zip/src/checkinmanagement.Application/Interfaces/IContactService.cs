using checkinmanagement.Application.DTOs;

namespace checkinmanagement.Application.Interfaces
{
    /// <summary>
    /// Service interface for contact operations
    /// </summary>
    public interface IContactService
    {
        /// <summary>
        /// Get contact information by journey key
        /// </summary>
        /// <param name="journeyKey">The journey key to get contacts for</param>
        /// <returns>List of contact information or empty list if not found</returns>
        Task<IEnumerable<ContactDto>> GetContactsByJourneyKeyAsync(string journeyKey);
    }
}
