using checkinmanagement.Domain.Entities;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Journey entity
    /// </summary>
    public class JourneyValidator : AbstractValidator<Journey>
    {
        public JourneyValidator()
        {
            RuleFor(x => x.JourneyKey)
                .NotEmpty()
                .WithMessage("Journey key is required")
                .Length(10, 50)
                .WithMessage("Journey key must be between 10 and 50 characters");

            RuleFor(x => x.FlightType)
                .NotEmpty()
                .WithMessage("Flight type is required")
                .Must(BeValidFlightType)
                .WithMessage("Flight type must be either 'Domestic' or 'International'");

            RuleFor(x => x.ProductClass)
                .NotEmpty()
                .WithMessage("Product class is required")
                .Must(BeValidProductClass)
                .WithMessage("Product class must be 'Economy', 'Premium Economy', 'Business', or 'First'");

            RuleFor(x => x.Stops)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Stops cannot be negative")
                .LessThanOrEqualTo(5)
                .WithMessage("Maximum 5 stops allowed");

            RuleFor(x => x.Designator)
                .NotNull()
                .WithMessage("Designator is required")
                .SetValidator(new DesignatorValidator());

            RuleFor(x => x.CheckinEligibility)
                .NotNull()
                .WithMessage("Check-in eligibility is required")
                .SetValidator(new CheckinEligibilityValidator());

            RuleFor(x => x.Passengers)
                .NotEmpty()
                .WithMessage("At least one passenger is required");

            RuleForEach(x => x.Passengers)
                .SetValidator(new PassengerValidator());

            RuleFor(x => x.Segments)
                .NotEmpty()
                .WithMessage("At least one segment is required");

            RuleForEach(x => x.Segments)
                .SetValidator(new SegmentValidator());

            // Business rule: Number of stops should match segments count minus 1
            RuleFor(x => x)
                .Must(HaveConsistentStopsAndSegments)
                .WithMessage("Number of stops should be one less than the number of segments");
        }

        private static bool BeValidFlightType(string flightType)
        {
            return flightType is "Domestic" or "International";
        }

        private static bool BeValidProductClass(string productClass)
        {
            return productClass is "Economy" or "Premium Economy" or "Business" or "First";
        }

        private static bool HaveConsistentStopsAndSegments(Journey journey)
        {
            return journey.Stops == Math.Max(0, journey.Segments.Count - 1);
        }
    }
}
