using FluentValidation;
using FluentValidation.Results;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// Service for validating domain entities using FluentValidation
    /// </summary>
    public interface IValidationService
    {
        Task<ValidationResult> ValidateAsync<T>(T entity, CancellationToken cancellationToken = default);
        ValidationResult Validate<T>(T entity);
        void ValidateAndThrow<T>(T entity);
    }

    public class ValidationService : IValidationService
    {
        private readonly IServiceProvider _serviceProvider;

        public ValidationService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task<ValidationResult> ValidateAsync<T>(T entity, CancellationToken cancellationToken = default)
        {
            var validator = GetValidator<T>();
            if (validator == null)
            {
                return new ValidationResult(); // No validator found, assume valid
            }

            return await validator.ValidateAsync(entity, cancellationToken);
        }

        public ValidationResult Validate<T>(T entity)
        {
            var validator = GetValidator<T>();
            if (validator == null)
            {
                return new ValidationResult(); // No validator found, assume valid
            }

            return validator.Validate(entity);
        }

        public void ValidateAndThrow<T>(T entity)
        {
            var validator = GetValidator<T>();
            validator?.ValidateAndThrow(entity);
        }

        private IValidator<T>? GetValidator<T>()
        {
            return _serviceProvider.GetService(typeof(IValidator<T>)) as IValidator<T>;
        }
    }
}
