using checkinmanagement.Domain.Entities;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for SeatAndSsr entity
    /// </summary>
    public class SeatAndSsrValidator : AbstractValidator<SeatAndSsr>
    {
        public SeatAndSsrValidator()
        {
            RuleFor(x => x.SegmentKey)
                .NotEmpty()
                .WithMessage("Segment key is required")
                .Length(5, 50)
                .WithMessage("Segment key must be between 5 and 50 characters");

            RuleForEach(x => x.Seats)
                .SetValidator(new SeatValidator());

            RuleForEach(x => x.Ssrs)
                .SetValidator(new SsrValidator());

            // Business rule: Should have at least one seat or SSR
            RuleFor(x => x)
                .Must(HaveAtLeastOneSeatOrSsr)
                .WithMessage("Must have at least one seat assignment or special service request");
        }

        private static bool HaveAtLeastOneSeatOrSsr(SeatAndSsr seatAndSsr)
        {
            return seatAndSsr.HasSeats || seatAndSsr.HasSsrs;
        }
    }
}
