using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Designator value object
    /// </summary>
    public class DesignatorValidator : AbstractValidator<Designator>
    {
        public DesignatorValidator()
        {
            RuleFor(x => x.Origin)
                .NotEmpty()
                .WithMessage("Origin is required")
                .Length(3, 3)
                .WithMessage("Origin must be a 3-character airport code")
                .Matches("^[A-Z]{3}$")
                .WithMessage("Origin must be 3 uppercase letters");

            RuleFor(x => x.Destination)
                .NotEmpty()
                .WithMessage("Destination is required")
                .Length(3, 3)
                .WithMessage("Destination must be a 3-character airport code")
                .Matches("^[A-Z]{3}$")
                .WithMessage("Destination must be 3 uppercase letters");

            RuleFor(x => x.UtcDeparture)
                .NotEmpty()
                .WithMessage("Departure time is required");

            RuleFor(x => x.UtcArrival)
                .NotEmpty()
                .WithMessage("Arrival time is required")
                .GreaterThan(x => x.UtcDeparture)
                .WithMessage("Arrival time must be after departure time");

            // Business rule: Origin and destination must be different
            RuleFor(x => x)
                .Must(HaveDifferentOriginAndDestination)
                .WithMessage("Origin and destination must be different");

            // Business rule: Flight duration should be reasonable
            RuleFor(x => x)
                .Must(HaveReasonableFlightDuration)
                .WithMessage("Flight duration must be between 15 minutes and 20 hours");
        }

        private static bool HaveDifferentOriginAndDestination(Designator designator)
        {
            return designator.Origin != designator.Destination;
        }

        private static bool HaveReasonableFlightDuration(Designator designator)
        {
            var duration = designator.FlightDuration;
            return duration >= TimeSpan.FromMinutes(15) && duration <= TimeSpan.FromHours(20);
        }
    }
}
