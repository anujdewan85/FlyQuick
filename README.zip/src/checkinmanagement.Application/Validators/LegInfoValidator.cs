using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for LegInfo value object
    /// </summary>
    public class LegInfoValidator : AbstractValidator<LegInfo>
    {
        public LegInfoValidator()
        {
            RuleFor(x => x.OperatingCarrier)
                .Length(2, 3)
                .When(x => !string.IsNullOrEmpty(x.OperatingCarrier))
                .WithMessage("Operating carrier must be 2 or 3 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.OperatingCarrier))
                .WithMessage("Operating carrier must contain only uppercase letters and numbers");

            RuleFor(x => x.OperatingFlightNumber)
                .Length(1, 6)
                .When(x => !string.IsNullOrEmpty(x.OperatingFlightNumber))
                .WithMessage("Operating flight number must be between 1 and 6 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.OperatingFlightNumber))
                .WithMessage("Operating flight number must contain only uppercase letters and numbers");

            RuleFor(x => x.EquipmentType)
                .Length(2, 5)
                .When(x => !string.IsNullOrEmpty(x.EquipmentType))
                .WithMessage("Equipment type must be between 2 and 5 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.EquipmentType))
                .WithMessage("Equipment type must contain only uppercase letters and numbers");

            RuleFor(x => x.EquipmentTypeSuffix)
                .MaximumLength(2)
                .When(x => !string.IsNullOrEmpty(x.EquipmentTypeSuffix))
                .WithMessage("Equipment type suffix cannot exceed 2 characters")
                .Matches("^[A-Z]+$")
                .When(x => !string.IsNullOrEmpty(x.EquipmentTypeSuffix))
                .WithMessage("Equipment type suffix must contain only uppercase letters");

            RuleFor(x => x.DepartureTerminal)
                .Length(1, 3)
                .When(x => !string.IsNullOrEmpty(x.DepartureTerminal))
                .WithMessage("Departure terminal must be between 1 and 3 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.DepartureTerminal))
                .WithMessage("Departure terminal must contain only uppercase letters and numbers");

            RuleFor(x => x.ArrivalTerminal)
                .Length(1, 3)
                .When(x => !string.IsNullOrEmpty(x.ArrivalTerminal))
                .WithMessage("Arrival terminal must be between 1 and 3 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.ArrivalTerminal))
                .WithMessage("Arrival terminal must contain only uppercase letters and numbers");

            RuleFor(x => x.OnTime)
                .Must(BeValidOnTimeStatus)
                .When(x => !string.IsNullOrEmpty(x.OnTime))
                .WithMessage("On time status must be 'OnTime', 'Delayed', 'Cancelled', or 'Boarding'");
        }

        private static bool BeValidOnTimeStatus(string onTime)
        {
            var validStatuses = new[] { "OnTime", "Delayed", "Cancelled", "Boarding", "Departed", "Arrived" };
            return validStatuses.Contains(onTime, StringComparer.OrdinalIgnoreCase);
        }
    }
}
