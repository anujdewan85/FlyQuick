using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for FlightIdentifier value object
    /// </summary>
    public class FlightIdentifierValidator : AbstractValidator<FlightIdentifier>
    {
        public FlightIdentifierValidator()
        {
            RuleFor(x => x.CarrierCode)
                .NotEmpty()
                .WithMessage("Carrier code is required")
                .Length(2, 3)
                .WithMessage("Carrier code must be 2 or 3 characters")
                .Matches("^[A-Z0-9]+$")
                .WithMessage("Carrier code must contain only uppercase letters and numbers");

            RuleFor(x => x.Identifier)
                .NotEmpty()
                .WithMessage("Flight identifier is required")
                .Length(1, 6)
                .WithMessage("Flight identifier must be between 1 and 6 characters")
                .Matches("^[0-9]+$")
                .WithMessage("Flight identifier must contain only numbers");

            RuleFor(x => x.OpSuffix)
                .Length(0, 2)
                .WithMessage("Operating suffix cannot exceed 2 characters")
                .Matches("^[A-Z]*$")
                .When(x => !string.IsNullOrEmpty(x.OpSuffix))
                .WithMessage("Operating suffix must contain only uppercase letters");

            // Business rule: Flight number should be within valid range
            RuleFor(x => x.Identifier)
                .Must(BeValidFlightNumber)
                .WithMessage("Flight number must be between 1 and 9999");
        }

        private static bool BeValidFlightNumber(string identifier)
        {
            if (int.TryParse(identifier, out int flightNumber))
            {
                return flightNumber >= 1 && flightNumber <= 9999;
            }
            return false;
        }
    }
}
