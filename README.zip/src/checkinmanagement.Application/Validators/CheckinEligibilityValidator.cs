using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for CheckinEligibility value object
    /// </summary>
    public class CheckinEligibilityValidator : AbstractValidator<CheckinEligibility>
    {
        public CheckinEligibilityValidator()
        {
            RuleFor(x => x.Status)
                .NotEmpty()
                .WithMessage("Check-in eligibility status is required")
                .Must(BeValidStatus)
                .WithMessage("Status must be 'eligible', 'not_eligible', or 'schedule'");

            RuleFor(x => x.Reason)
                .MaximumLength(200)
                .WithMessage("Reason cannot exceed 200 characters");

            // Business rule: If not eligible, reason should be provided
            RuleFor(x => x.Reason)
                .NotEmpty()
                .When(x => x.Status.Equals("not_eligible", StringComparison.OrdinalIgnoreCase))
                .WithMessage("Reason is required when check-in is not eligible");
        }

        private static bool BeValidStatus(string status)
        {
            return status is "eligible" or "not_eligible" or "schedule";
        }
    }
}
