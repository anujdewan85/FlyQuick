using checkinmanagement.Domain.Entities;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Booking entity
    /// </summary>
    public class BookingValidator : AbstractValidator<Booking>
    {
        public BookingValidator()
        {
            RuleFor(x => x.Pnr)
                .NotEmpty()
                .WithMessage("PNR is required")
                .Length(6, 10)
                .WithMessage("PNR must be between 6 and 10 characters")
                .Matches("^[A-Z0-9]+$")
                .WithMessage("PNR must contain only uppercase letters and numbers");

            RuleFor(x => x.LastName)
                .NotEmpty()
                .WithMessage("Last name is required")
                .Length(2, 50)
                .WithMessage("Last name must be between 2 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .WithMessage("Last name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.EmailId)
                .EmailAddress()
                .When(x => !string.IsNullOrEmpty(x.EmailId))
                .WithMessage("Email must be a valid email address");

            RuleFor(x => x.BookingReference)
                .Length(6, 15)
                .When(x => !string.IsNullOrEmpty(x.BookingReference))
                .WithMessage("Booking reference must be between 6 and 15 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.BookingReference))
                .WithMessage("Booking reference must contain only uppercase letters and numbers");

            RuleFor(x => x.Journeys)
                .NotEmpty()
                .WithMessage("At least one journey is required");

            RuleForEach(x => x.Journeys)
                .SetValidator(new JourneyValidator());
        }
    }
}
