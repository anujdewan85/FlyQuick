using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Ssr value object
    /// </summary>
    public class SsrValidator : AbstractValidator<Ssr>
    {
        public SsrValidator()
        {
            RuleFor(x => x.SsrNumber)
                .NotEmpty()
                .WithMessage("SSR number is required")
                .Length(3, 10)
                .WithMessage("SSR number must be between 3 and 10 characters")
                .Matches("^[A-Z0-9]+$")
                .WithMessage("SSR number must contain only uppercase letters and numbers");

            RuleFor(x => x.SsrDetail)
                .MaximumLength(200)
                .WithMessage("SSR detail cannot exceed 200 characters");

            // Business rule: Some SSRs require details
            RuleFor(x => x.SsrDetail)
                .NotEmpty()
                .When(x => RequiresDetail(x.SsrNumber))
                .WithMessage("This type of SSR requires additional details");
        }

        private static bool RequiresDetail(string ssrNumber)
        {
            // SSRs that typically require additional details
            var ssrsRequiringDetails = new[]
            {
                "SPML", // Special Meal
                "PETC", // Pet in Cabin
                "BLND", // Blind passenger
                "DEAF", // Deaf passenger
                "MEDA", // Medical Case
                "OXYG"  // Oxygen
            };

            return ssrsRequiringDetails.Any(ssr => 
                ssrNumber.StartsWith(ssr, StringComparison.OrdinalIgnoreCase));
        }
    }
}
