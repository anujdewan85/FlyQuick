using checkinmanagement.Domain.Entities;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Passenger entity
    /// </summary>
    public class PassengerValidator : AbstractValidator<Passenger>
    {
        public PassengerValidator()
        {
            RuleFor(x => x.PassengerKey)
                .NotEmpty()
                .WithMessage("Passenger key is required")
                .Length(5, 50)
                .WithMessage("Passenger key must be between 5 and 50 characters");

            RuleFor(x => x.Name)
                .NotNull()
                .WithMessage("Passenger name is required")
                .SetValidator(new PassengerNameValidator());

            RuleFor(x => x.PassengerTypeCode)
                .NotEmpty()
                .WithMessage("Passenger type code is required")
                .Must(BeValidPassengerType)
                .WithMessage("Passenger type code must be 'ADT' (Adult), 'CHD' (Child), or 'INF' (Infant)");

            RuleFor(x => x.DateOfBirth)
                .NotEmpty()
                .WithMessage("Date of birth is required")
                .Must(BeValidDateOfBirth)
                .WithMessage("Date of birth must be a valid date in the past");

            RuleFor(x => x.Nationality)
                .NotEmpty()
                .WithMessage("Nationality is required")
                .Length(2, 3)
                .WithMessage("Nationality must be a 2 or 3 character country code")
                .Matches("^[A-Z]+$")
                .WithMessage("Nationality must be uppercase letters only");

            RuleFor(x => x.Gender)
                .IsInEnum()
                .WithMessage("Gender must be a valid enum value");

            RuleFor(x => x.Loyalty)
                .SetValidator(new LoyaltyValidator()!)
                .When(x => x.Loyalty != null);

            RuleFor(x => x.Infant)
                .SetValidator(new InfantValidator()!)
                .When(x => x.Infant != null);

            RuleForEach(x => x.SeatsAndSsrs)
                .SetValidator(new SeatAndSsrValidator());

            // Business rule: Infant passengers must have infant details
            RuleFor(x => x.Infant)
                .NotNull()
                .When(x => x.PassengerTypeCode == "INF")
                .WithMessage("Infant passengers must have infant details");

            // Business rule: Adult passengers should not have infant details
            RuleFor(x => x.Infant)
                .Null()
                .When(x => x.PassengerTypeCode == "ADT")
                .WithMessage("Adult passengers should not have infant details");
        }

        private static bool BeValidPassengerType(string passengerType)
        {
            return passengerType is "ADT" or "CHD" or "INF";
        }

        private static bool BeValidDateOfBirth(string dateOfBirth)
        {
            if (DateTime.TryParse(dateOfBirth, out DateTime dob))
            {
                return dob <= DateTime.Today && dob >= DateTime.Today.AddYears(-120);
            }
            return false;
        }
    }
}
