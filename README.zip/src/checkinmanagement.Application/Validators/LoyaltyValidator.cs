using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Loyalty value object
    /// </summary>
    public class LoyaltyValidator : AbstractValidator<Loyalty>
    {
        public LoyaltyValidator()
        {
            RuleFor(x => x.Tier)
                .Length(2, 20)
                .When(x => !string.IsNullOrEmpty(x.Tier))
                .WithMessage("Loyalty tier must be between 2 and 20 characters")
                .Must(BeValidTier)
                .When(x => !string.IsNullOrEmpty(x.Tier))
                .WithMessage("Loyalty tier must be one of: Bronze, Silver, Gold, Platinum, Diamond");

            RuleFor(x => x.FfNumber)
                .NotEmpty()
                .When(x => !string.IsNullOrEmpty(x.Tier))
                .WithMessage("Frequent flyer number is required when tier is provided")
                .Length(6, 15)
                .When(x => !string.IsNullOrEmpty(x.FfNumber))
                .WithMessage("Frequent flyer number must be between 6 and 15 characters")
                .Matches("^[A-Z0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.FfNumber))
                .WithMessage("Frequent flyer number must contain only uppercase letters and numbers");
        }

        private static bool BeValidTier(string tier)
        {
            var validTiers = new[] { "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Blue", "Red" };
            return validTiers.Contains(tier, StringComparer.OrdinalIgnoreCase);
        }
    }
}
