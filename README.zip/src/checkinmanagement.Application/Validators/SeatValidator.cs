using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Seat value object
    /// </summary>
    public class SeatValidator : AbstractValidator<Seat>
    {
        public SeatValidator()
        {
            RuleFor(x => x.SeatUnitDesignator)
                .NotEmpty()
                .WithMessage("Seat unit designator is required")
                .Length(2, 4)
                .WithMessage("Seat unit designator must be between 2 and 4 characters")
                .Matches("^[0-9]+[A-Z]$")
                .WithMessage("Seat unit designator must be in format '12A' (row number + letter)");

            RuleFor(x => x.Type)
                .MaximumLength(50)
                .WithMessage("Seat type cannot exceed 50 characters");

            // Business rule: Row number should be reasonable
            RuleFor(x => x.SeatUnitDesignator)
                .Must(HaveValidRowNumber)
                .WithMessage("Seat row number must be between 1 and 99");

            // Business rule: Seat letter should be valid
            RuleFor(x => x.SeatUnitDesignator)
                .Must(HaveValidSeatLetter)
                .WithMessage("Seat letter must be A-K (excluding I)");
        }

        private static bool HaveValidRowNumber(string seatDesignator)
        {
            if (string.IsNullOrEmpty(seatDesignator) || seatDesignator.Length < 2)
                return false;

            var rowNumberPart = seatDesignator[..^1]; // All characters except the last one
            if (int.TryParse(rowNumberPart, out int rowNumber))
            {
                return rowNumber >= 1 && rowNumber <= 99;
            }
            return false;
        }

        private static bool HaveValidSeatLetter(string seatDesignator)
        {
            if (string.IsNullOrEmpty(seatDesignator))
                return false;

            var seatLetter = seatDesignator[^1]; // Last character
            var validLetters = "ABCDEFGHJK"; // I is typically not used
            return validLetters.Contains(seatLetter);
        }
    }
}
