using checkinmanagement.Domain.ValueObjects;
using System.Globalization;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Infant value object
    /// </summary>
    public class InfantValidator : AbstractValidator<Infant>
    {
        public InfantValidator()
        {
            RuleFor(x => x.Name)
                .NotNull()
                .WithMessage("Infant name is required");

            RuleFor(x => x.Name.First)
                .NotEmpty()
                .WithMessage("Infant first name is required")
                .Length(1, 50)
                .WithMessage("Infant first name must be between 1 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .WithMessage("Infant first name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.Name.Last)
                .NotEmpty()
                .WithMessage("Infant last name is required")
                .Length(1, 50)
                .WithMessage("Infant last name must be between 1 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .WithMessage("Infant last name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.Name.Middle)
                .Length(0, 50)
                .When(x => !string.IsNullOrEmpty(x.Name.Middle))
                .WithMessage("Infant middle name must be no more than 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .When(x => !string.IsNullOrEmpty(x.Name.Middle))
                .WithMessage("Infant middle name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.DateOfBirth)
                .NotEmpty()
                .WithMessage("Infant date of birth is required")
                .Must(BeValidInfantDateOfBirth)
                .WithMessage("Infant date of birth must be a valid date within the last 2 years");

            RuleFor(x => x.Gender)
                .NotEmpty()
                .WithMessage("Infant gender is required")
                .Must(BeValidGender)
                .WithMessage("Gender must be 'Male', 'Female', or 'Other'");

            RuleFor(x => x.ResidentCountry)
                .Length(2, 3)
                .When(x => !string.IsNullOrEmpty(x.ResidentCountry))
                .WithMessage("Resident country must be a 2 or 3 character country code")
                .Matches("^[A-Z]+$")
                .When(x => !string.IsNullOrEmpty(x.ResidentCountry))
                .WithMessage("Resident country must be uppercase letters only");
        }

        private static bool BeValidInfantDateOfBirth(string dateOfBirth)
        {
            if (DateTime.TryParse(dateOfBirth, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dob))
            {
                var age = DateTime.Today - dob;
                return age.TotalDays >= 0 && age.TotalDays <= 730; // 0 to 2 years
            }
            return false;
        }

        private static bool BeValidGender(string gender)
        {
            return gender is "Male" or "Female" or "Other" or "M" or "F" or "O";
        }
    }
}
