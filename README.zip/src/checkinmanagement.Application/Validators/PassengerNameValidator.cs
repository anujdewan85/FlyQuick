using checkinmanagement.Domain.ValueObjects;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for PassengerName value object
    /// </summary>
    public class PassengerNameValidator : AbstractValidator<PassengerName>
    {
        public PassengerNameValidator()
        {
            RuleFor(x => x.First)
                .NotEmpty()
                .WithMessage("First name is required")
                .Length(1, 50)
                .WithMessage("First name must be between 1 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .WithMessage("First name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.Last)
                .NotEmpty()
                .WithMessage("Last name is required")
                .Length(1, 50)
                .WithMessage("Last name must be between 1 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .WithMessage("Last name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.Middle)
                .Length(1, 50)
                .When(x => !string.IsNullOrEmpty(x.Middle))
                .WithMessage("Middle name must be between 1 and 50 characters")
                .Matches("^[a-zA-Z\\s'-]+$")
                .When(x => !string.IsNullOrEmpty(x.Middle))
                .WithMessage("Middle name must contain only letters, spaces, hyphens, and apostrophes");

            RuleFor(x => x.Title)
                .Length(2, 10)
                .When(x => !string.IsNullOrEmpty(x.Title))
                .WithMessage("Title must be between 2 and 10 characters")
                .Must(BeValidTitle)
                .When(x => !string.IsNullOrEmpty(x.Title))
                .WithMessage("Title must be one of: Mr, Mrs, Ms, Miss, Dr, Prof");
        }

        private static bool BeValidTitle(string title)
        {
            var validTitles = new[] { "Mr", "Mrs", "Ms", "Miss", "Dr", "Prof", "Sir", "Lady" };
            return validTitles.Contains(title, StringComparer.OrdinalIgnoreCase);
        }
    }
}
