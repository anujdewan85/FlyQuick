using checkinmanagement.Domain.Entities;
using FluentValidation;

namespace checkinmanagement.Application.Validators
{
    /// <summary>
    /// FluentValidation validator for Segment entity
    /// </summary>
    public class SegmentValidator : AbstractValidator<Segment>
    {
        public SegmentValidator()
        {
            RuleFor(x => x.SegmentKey)
                .NotEmpty()
                .WithMessage("Segment key is required")
                .Length(5, 50)
                .WithMessage("Segment key must be between 5 and 50 characters");

            RuleFor(x => x.Origin)
                .NotEmpty()
                .WithMessage("Origin is required")
                .Length(3, 3)
                .WithMessage("Origin must be a 3-character airport code")
                .Matches("^[A-Z]{3}$")
                .WithMessage("Origin must be 3 uppercase letters");

            RuleFor(x => x.Destination)
                .NotEmpty()
                .WithMessage("Destination is required")
                .Length(3, 3)
                .WithMessage("Destination must be a 3-character airport code")
                .Matches("^[A-Z]{3}$")
                .WithMessage("Destination must be 3 uppercase letters");

            RuleFor(x => x.UtcDeparture)
                .NotEmpty()
                .WithMessage("Departure time is required")
                .Must(BeInFuture)
                .WithMessage("Departure time must be in the future");

            RuleFor(x => x.UtcArrival)
                .NotEmpty()
                .WithMessage("Arrival time is required")
                .GreaterThan(x => x.UtcDeparture)
                .WithMessage("Arrival time must be after departure time");

            RuleFor(x => x.ProductClass)
                .NotEmpty()
                .WithMessage("Product class is required")
                .Must(BeValidProductClass)
                .WithMessage("Product class must be 'Economy', 'Premium Economy', 'Business', or 'First'");

            RuleFor(x => x.Identifier)
                .NotNull()
                .WithMessage("Flight identifier is required")
                .SetValidator(new FlightIdentifierValidator());

            RuleFor(x => x.ExternalIdentifier)
                .SetValidator(new FlightIdentifierValidator()!)
                .When(x => x.ExternalIdentifier != null);

            RuleForEach(x => x.LegInfo)
                .SetValidator(new LegInfoValidator());

            // Business rule: Origin and destination should be different
            RuleFor(x => x)
                .Must(HaveDifferentOriginAndDestination)
                .WithMessage("Origin and destination must be different");

            // Business rule: Flight duration should be reasonable (15 minutes to 20 hours)
            RuleFor(x => x)
                .Must(HaveReasonableFlightDuration)
                .WithMessage("Flight duration must be between 15 minutes and 20 hours");
        }

        private static bool BeInFuture(DateTime departureTime)
        {
            return departureTime > DateTime.UtcNow.AddMinutes(-30); // Allow 30 minutes grace period
        }

        private static bool BeValidProductClass(string productClass)
        {
            return productClass is "Economy" or "Premium Economy" or "Business" or "First";
        }

        private static bool HaveDifferentOriginAndDestination(Segment segment)
        {
            return segment.Origin != segment.Destination;
        }

        private static bool HaveReasonableFlightDuration(Segment segment)
        {
            var duration = segment.UtcArrival - segment.UtcDeparture;
            return duration >= TimeSpan.FromMinutes(15) && duration <= TimeSpan.FromHours(20);
        }
    }
}
