using checkinmanagement.Domain.Entities;
using System.Net;

namespace checkinmanagement.Application.DTOs
{
    public class RetrieveJourneyResponse
    {
        public bool Success { get; set; }
        public BookingAggregateDto? BookingAggregate { get; set; }
        public string? ErrorMessage { get; set; }
        
        /// <summary>
        /// Application-specific error code (e.g., "BAD_REQUEST", "NOT_FOUND", "MAPPING_ERROR")
        /// </summary>
        public string? ErrorCode { get; set; }
        
        /// <summary>
        /// HTTP status code for the error (e.g., 400, 404, 500)
        /// </summary>
        public int? HttpStatusCode { get; set; }
    }
}
