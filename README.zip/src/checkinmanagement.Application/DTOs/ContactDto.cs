namespace checkinmanagement.Application.DTOs
{
    /// <summary>
    /// Contact information data transfer object
    /// </summary>
    public record ContactDto
    {
        /// <summary>
        /// Phone number
        /// </summary>
        public string PhoneNumber { get; init; } = string.Empty;

        /// <summary>
        /// Email address
        /// </summary>
        public string Email { get; init; } = string.Empty;

        /// <summary>
        /// Type of contact (ContactDetail or EmergencyContact)
        /// </summary>
        public string Type { get; init; } = string.Empty;

        /// <summary>
        /// Journey key associated with the contact
        /// </summary>
        public string JourneyKey { get; init; } = string.Empty;
    }
}
