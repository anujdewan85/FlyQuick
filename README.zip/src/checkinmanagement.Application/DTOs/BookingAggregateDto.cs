using System;
using System.Collections.Generic;
using checkinmanagement.Domain.Enums;

// ============================================================================
// APPLICATION LAYER - Single Reusable Aggregate DTO
// ============================================================================
namespace checkinmanagement.Application.DTOs
{
    /// <summary>
    /// Single comprehensive DTO that contains all booking data from domain
    /// Reusable across multiple API endpoints and external integrations
    /// Maps directly from Booking domain aggregate
    /// </summary>
    public class BookingAggregateDto
    {
        // Booking level information
        public string? BookingReference { get; set; }
        public string? Pnr { get; set; }
        public string? ContactLastName { get; set; }
        public string? ContactEmailId { get; set; }
        public DateTime LastUpdated { get; set; }
        public string Status { get; set; }

        // All journeys in this booking
        public List<JourneyDto> Journeys { get; set; } = new List<JourneyDto>();

        // Helper methods for API layer
        public JourneyDto GetJourneyByKey(string journeyKey)
        {
            return Journeys?.FirstOrDefault(j => j.JourneyKey == journeyKey);
        }
    }

    public class JourneyDto
    {
        public required string JourneyKey { get; set; }
        public string FlightType { get; set; }
        public int Stops { get; set; }
        public string ProductClass { get; set; }
        public bool IsInternational { get; set; }
        public bool IsCodeshare { get; set; }
        public CheckinEligibilityDto CheckinEligibility { get; set; }
        public string CheckedinStatus { get; set; }
        public DesignatorDto Designator { get; set; }
        public List<PassengerDto> Passengers { get; set; } = new List<PassengerDto>();
        public List<SegmentDto> Segments { get; set; } = new List<SegmentDto>();
    }

    public class CheckinEligibilityDto
    {
        public string Status { get; set; }
        public string Reason { get; set; }
    }

    public class DesignatorDto
    {
        public string Destination { get; set; }
        public string Origin { get; set; }
        public DateTime UtcArrival { get; set; }
        public DateTime UtcDeparture { get; set; }

        public static implicit operator DesignatorDto(string v)
        {
            throw new NotImplementedException();
        }
    }

    public class PassengerDto
    {
        public string PassengerKey { get; set; }
        public string PassengerTypeCode { get; set; }
        public string DiscountCode { get; set; }
        public string ExtraseatTag { get; set; }
        public HasCheckedin HasCheckedIn { get; set; }
        public string Nationality { get; set; }
        public int Gender { get; set; }
        public string DateOfBirth { get; set; }
        public PassengerNameDto Name { get; set; }
        public LoyaltyDto Loyalty { get; set; }
        public InfantDto Infant { get; set; }
        public List<SeatAndSsrDto> SeatsAndSsrs { get; set; } = new List<SeatAndSsrDto>();
    }

    public class PassengerNameDto
    {
        public string First { get; set; }
        public string Middle { get; set; }
        public string Last { get; set; }
        public string Title { get; set; }
    }

    public class LoyaltyDto
    {
        public string Tier { get; set; }
        public string FfNumber { get; set; }
    }

    public class InfantDto
    {
        public string DateOfBirth { get; set; }
        public string ResidentCountry { get; set; }
        public string Gender { get; set; }
        public PassengerNameDto Name { get; set; }
    }

    public class SeatAndSsrDto
    {
        public string SegmentKey { get; set; }
        public List<SeatDto> Seats { get; set; } = new List<SeatDto>();
        public List<SsrDto> Ssrs { get; set; } = new List<SsrDto>();
    }

    public class SeatDto
    {
        public string SeatUnitDesignator { get; set; }
        public string Type { get; set; }
    }

    public class SsrDto
    {
        public string SsrNumber { get; set; }
        public string SsrDetail { get; set; }
    }

    public class SegmentDto
    {
        public string SegmentKey { get; set; }
        public string Destination { get; set; }
        public string DestinationName { get; set; }
        public string DestinationCityName { get; set; }
        public string Origin { get; set; }
        public string OriginName { get; set; }
        public string OriginCityName { get; set; }
        public DateTime UtcArrival { get; set; }
        public DateTime UtcDeparture { get; set; }
        public string ProductClass { get; set; }
        public bool IsInternational { get; set; }
        public FlightIdentifierDto Identifier { get; set; }
        public FlightIdentifierDto ExternalIdentifier { get; set; }
        public List<LegInfoDto> LegInfo { get; set; } = new List<LegInfoDto>();
    }

    public class FlightIdentifierDto
    {
        public string Identifier { get; set; }
        public string CarrierCode { get; set; }
        public string OpSuffix { get; set; }
    }

    public class LegInfoDto
    {
        public string ArrivalTerminal { get; set; }
        public string DepartureTerminal { get; set; }
        public string EquipmentType { get; set; }
        public string EquipmentTypeSuffix { get; set; }
        public string OnTime { get; set; }
        public string OperatingCarrier { get; set; }
        public string OperatingFlightNumber { get; set; }
    }
}
