namespace checkinmanagement.Application.DTOs
{
    /// <summary>
    /// Application layer journey request - immutable record
    /// Provides value-based equality and immutability for business logic
    /// </summary>
    public record RetrieveJourneyRequest
    {
        public string? PNR { get; init; }
        
        public string? LastName { get; init; }
        
        public string? EmailId { get; init; }
        
        public string? BookingReference { get; init; }
    }
}
