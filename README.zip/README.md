# CheckIn Management Service

A comprehensive .NET 8 REST API service for airline check-in operations, built using Clean Architecture principles and modern development practices.

## 🏗️ Architecture Overview

This service follows **Clean Architecture** pattern, ensuring separation of concerns, testability, and maintainability:

```
┌─────────────────────────────────────────────┐
│                API Layer                    │
│  Controllers, DTOs, Validators, Mappers     │
├─────────────────────────────────────────────┤
│             Application Layer               │
│     Services, Interfaces, Use Cases        │
├─────────────────────────────────────────────┤
│              Domain Layer                   │
│      Entities, Enums, Business Logic       │
├─────────────────────────────────────────────┤
│           Infrastructure Layer              │
│   External Services, Data Access, Mock     │
└─────────────────────────────────────────────┘
```

### Layer Responsibilities

#### 🎯 **API Layer** (`checkinmanagement.API`)
- **Controllers**: RESTful endpoints with proper HTTP semantics
- **DTOs**: Data Transfer Objects for request/response isolation
- **Validators**: FluentValidation rules for input validation
- **Mappers**: Mapster configurations for object mapping
- **Configuration**: Service registration and middleware setup

#### 🔧 **Application Layer** (`checkinmanagement.Application`)
- **Services**: Business logic implementation
- **Interfaces**: Service contracts and abstractions
- **DTOs**: Internal data transfer objects
- **Use Cases**: Orchestration of business operations

#### 🏛️ **Domain Layer** (`checkinmanagement.Domain`)
- **Entities**: Core business entities (Journey, Passenger, etc.)
- **Enums**: Domain-specific enumerations (JourneyStatus)
- **Business Rules**: Domain logic and constraints

#### 🔌 **Infrastructure Layer** (`checkinmanagement.Infrastructure`)
- **External Services**: Navitaire GraphQL integration with modern .NET GraphQL client
- **GraphQL Services**: Scalable GraphQL client implementation with response builders
- **Response Mappers**: Mapster-based mapping from GraphQL responses to application DTOs
- **Mock Data**: Development and testing data providers
- **Service Implementations**: Concrete implementations of application interfaces

### GraphQL Integration Architecture

The service implements a modern **GraphQL client architecture** for Navitaire API integration:

```
┌─────────────────────────────────────────────┐
│               API Layer                     │
│  Controllers → Application DTOs → API DTOs  │
├─────────────────────────────────────────────┤
│            Application Layer                │
│      Services → BookingAggregateDto         │
├─────────────────────────────────────────────┤
│           Infrastructure Layer              │
│  GraphQL Client → Response Builders →       │
│  NavitaireGraphQLMapper → Application DTOs  │
└─────────────────────────────────────────────┘
```

#### GraphQL Client Features
- **Modern Implementation**: Uses `GraphQL.Client` (v6.0.2) with SystemTextJson serialization
- **Generic Execution**: Reusable `ExecuteGenericGraphQLRequestAsync<TResponse>` method
- **Response Builders**: Separated response building logic for different operations
- **Mapster Integration**: Simplified mapping configuration for GraphQL dynamic responses
- **Error Handling**: Comprehensive error management with proper HTTP status codes
- **Caching**: Client instance caching for memory efficiency
- **Extensible Design**: Easy to add new GraphQL operations

1. **Clean Architecture** Compliance:
External Layer (GraphQL) → Application Layer (DTOs) → API Layer (Responses)
Each layer has its own concerns and contracts
Follows dependency inversion principle
2. **Separation of Concerns**:
Application DTOs: Business logic representation (domain-focused)
API Response DTOs: Client contract representation (API-focused)
GraphQL Response: External service representation (integration-focused)

## 🚀 Key Features

### API Versioning
- **Framework**: `Asp.Versioning.Mvc` (v8.1.0)
- **Strategies**: URL Segment, Query String, Header-based versioning
- **Current Version**: v1.0
- **URL Pattern**: `/checkin/v{version:apiVersion}/journeys`

**Supported Version Formats:**
```http
GET /checkin/v1.0/journeys/health
GET /checkin/v1/journeys/health
GET /checkin/journeys/health?version=1.0
GET /checkin/journeys/health (Header: X-Version: 1.0)
```

### Journey Retrieval Endpoint
**Endpoint**: `POST /checkin/v1/journeys/retrieve`

**Supported Scenarios:**

1. **Booking Reference Only**: `{ "bookingReference": "ABC123" }`
2. **PNR + Last Name**: `{ "pnr": "PNR123", "lastName": "Smith" }`
3. **PNR + Email**: `{ "pnr": "PNR123", "emailId": "john@example.com" }`

### Contact Information Endpoint

**Endpoint**: `GET /checkin/v1/contacts?journeyKey={journeyKey}`

**Features:**

- Retrieves contact information for a specific journey
- Supports multiple contact types per journey:
  - **ContactDetail**: Primary contact information
  - **EmergencyContact**: Emergency contact details
- Returns an array of contacts with phone numbers, emails, and types
- Uses authentic Indian test data for realistic scenarios

**Response Format:**

```json
{
  "data": {
    "journeyKey": "ABC123~2025-08-15~DEL~BOM~AI101",
    "contacts": [
      {
        "phoneNumber": "+91-9876543210",
        "email": "rajesh.sharma@test.com",
        "type": "ContactDetail"
      },
      {
        "phoneNumber": "+91-9876543211",
        "email": "emergency.sharma@test.com",
        "type": "EmergencyContact"
      }
    ]
  },
  "errors": {}
}
```

**Contact Distribution:**

- **Journeys with both types**: ABC123, JKL012 (2 journeys)
- **ContactDetail only**: XYZ789, MNO345, STU901, RT456789 (5 journeys)
- **EmergencyContact only**: DEF456, PQR678, MUL123 (3 journeys)

**Logging Implementation:**
```csharp
using var scope = _logger.BeginScope(new Dictionary<string, object>
{
    ["Action"] = nameof(GetContacts),
    ["RequestId"] = HttpContext.TraceIdentifier,
    ["CorrelationId"] = HttpContext.Request.Headers["X-Correlation-ID"].FirstOrDefault() ?? Guid.NewGuid().ToString()
});
```

**Benefits of Logging Scope:**
- **Distributed Tracing**: Correlation IDs help track requests across services
- **Request Tracking**: Unique request identifiers for debugging
- **Action Context**: Method names for categorizing log entries
- **Automatic Cleanup**: `using` statement ensures proper scope disposal

## 🛠️ Technology Stack

### Core Framework
- **.NET 8**: Latest LTS version with improved performance
- **ASP.NET Core**: Web API framework with built-in DI container

### Validation Framework
- **FluentValidation**: Powerful validation library with clean syntax
- **Features**:
  - Complex business rule validation
  - Automatic model binding integration
  - Custom validation methods
  - Detailed error messages

```csharp
// Example validation rule
RuleFor(x => x)
    .Must(BeValidCombination)
    .WithMessage("Invalid combination of parameters");
```

### Object Mapping
- **Mapster**: High-performance object mapping library
- **Configuration**: Simplified mapping for GraphQL dynamic responses
- **Benefits**:
  - Faster than AutoMapper
  - Type-safe mapping
  - Compile-time configuration
  - Handles complex GraphQL response structures

```csharp
// API to Application mapping
public static RetrieveJourneyRequest ToApplicationRequest(this RetrieveJourneyApiRequest apiRequest)
    => apiRequest.Adapt<RetrieveJourneyRequest>();
```

### GraphQL Client
- **GraphQL.Client**: Modern .NET GraphQL client library (v6.0.2)
- **Serialization**: SystemTextJson for high performance
- **Generic Methods**: Reusable execution patterns for scalability
- **Response Builders**: Separated response building logic by domain
- **Error Handling**: Comprehensive GraphQL error management
- **HTTP Status Mapping**: Proper status code handling for different scenarios

```csharp
// Generic GraphQL execution
public async Task<TResponse> ExecuteGenericGraphQLRequestAsync<TResponse>(
    string query, object variables = null)
{
    var request = new GraphQLRequest { Query = query, Variables = variables };
    return await _graphQLClient.SendQueryAsync<TResponse>(request);
}
```

### Structured Logging
- **Serilog**: High-performance structured logging framework
- **Packages Used**:
  - `Serilog.AspNetCore` (9.0.0) - Core ASP.NET integration
  - `Serilog.Sinks.Console` (6.0.0) - Console output
  - `Serilog.Sinks.File` (7.0.0) - File logging with rolling
  - `Serilog.Enrichers.Environment` (3.0.1) - Environment enrichments
  - `Serilog.Enrichers.Process` (3.0.0) - Process information
  - `Serilog.Enrichers.Thread` (4.0.0) - Thread tracking

**Features:**
- **Request/Response Logging**: Automatic HTTP logging with duration
- **Structured Data**: JSON-like properties for querying
- **Multiple Sinks**: Console (dev) and File (persistent) outputs
- **Log Enrichment**: Process ID, Thread ID, Environment, Machine name
- **Correlation IDs**: Distributed tracing support
- **Rolling Files**: Daily rotation with size limits (100MB)
- **Performance Tracking**: Request duration and performance metrics

**Log Configuration:**
```json
{
  "Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Warning",
        "checkinmanagement": "Debug"
      }
    },
    "WriteTo": [
      { "Name": "Console" },
      { "Name": "File", "Args": { "path": "logs/checkinmanagement-.log" } }
    ]
  }
}
```

### Observability & Telemetry
- **OpenTelemetry**: Comprehensive observability framework for distributed systems
- **Packages Used**:
  - `OpenTelemetry` (1.9.0) - Core OpenTelemetry SDK
  - `OpenTelemetry.Exporter.Console` (1.9.0) - Console telemetry output
  - `OpenTelemetry.Exporter.OpenTelemetryProtocol` (1.9.0) - OTLP exporter for production
  - `OpenTelemetry.Extensions.Hosting` (1.9.0) - ASP.NET Core integration
  - `OpenTelemetry.Instrumentation.AspNetCore` (1.9.0) - HTTP request tracing
  - `OpenTelemetry.Instrumentation.Http` (1.9.0) - HTTP client instrumentation
  - `OpenTelemetry.Instrumentation.Runtime` (1.9.0) - .NET runtime metrics

**Features:**
- **Distributed Tracing**: Track requests across service boundaries with trace/span correlation
- **HTTP Instrumentation**: Automatic capture of all HTTP requests/responses with timing
- **Runtime Metrics**: .NET GC, memory, thread pool, and JIT compilation metrics
- **Exception Tracking**: Automatic exception capture with context and stack traces
- **Custom Business Tracing**: Manual instrumentation for business operations
- **Multiple Exporters**: Console output (development) and OTLP (production)
- **Configuration-Driven**: Service name, version, and endpoints configurable via appsettings

**Telemetry Configuration:**
```json
{
  "OpenTelemetry": {
    "Endpoint": "",
    "ServiceName": "checkin-management-service",
    "ServiceVersion": "1.0.0"
  }
}
```

**Custom Business Tracing Example:**
```csharp
public async Task<IActionResult> RetrieveJourney(RetrieveJourneyRequest request)
{
    using var activity = TelemetryConfiguration.ActivitySource.StartActivity("Journey.Retrieve");
    activity?.SetTag("journey.booking_reference", request.BookingReference);
    activity?.SetTag("journey.passenger_count", request.PassengerCount);
    
    try
    {
        var result = await _journeyService.RetrieveAsync(request);
        activity?.SetTag("journey.segments_found", result.Segments.Count);
        return Ok(result);
    }
    catch (Exception ex)
    {
        activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
        throw; // Middleware handles structured error response
    }
}
```

**Available Telemetry Data:**
- **HTTP Requests**: Method, URL, status codes, duration, user agent
- **Business Operations**: Booking retrievals, passenger check-ins, journey processing
- **External Dependencies**: Navitaire API calls, database operations
- **Runtime Performance**: Memory usage, GC collections, thread pool metrics
- **Error Context**: Exception types, error rates, failure correlation

**Production Integration:**
Supports major observability platforms including Jaeger, Zipkin, New Relic, Datadog, Azure Monitor, AWS X-Ray, and Google Cloud Trace.

### GraphQL Implementation

### Architecture Overview

The service implements a **modern GraphQL client architecture** for seamless Navitaire API integration with clean separation of concerns:

```
API Layer (Controllers)
    ↓ API DTOs
Application Layer (Services)
    ↓ Application DTOs
Infrastructure Layer
    ↓ GraphQL Client
    ↓ Response Builders
    ↓ Mapster Mapping
External API (Navitaire GraphQL)
```

### Key Components

#### NavitaireGraphQLService
- **Purpose**: Single consolidated GraphQL service with generic execution patterns
- **Generic Method**: `ExecuteGenericGraphQLRequestAsync<TResponse>` for scalable future endpoints
- **Error Handling**: Comprehensive GraphQL error management with proper HTTP status codes
- **Caching**: Client instance caching for memory efficiency

#### Response Builders
- **BookingResponseBuilder**: Separated booking-specific response transformation logic
- **Domain Separation**: Each domain gets its own response builder for better organization
- **Error Mapping**: Converts GraphQL errors to application-specific error responses

#### NavitaireGraphQLMapper
- **Simplified Configuration**: Streamlined from complex implementation to essential mappings only
- **Dynamic Response Handling**: Handles GraphQL's dynamic response structures
- **Performance**: Mapster's compile-time mapping generation for maximum efficiency

### Implementation Benefits

- **Scalability**: Generic execution patterns make adding new endpoints simple
- **Maintainability**: Clear separation of concerns with dedicated response builders
- **Performance**: Mapster's compile-time mapping and client caching
- **Flexibility**: Easy to extend for new GraphQL operations
- **Clean Architecture**: Proper DTO flow maintains architectural boundaries

### DTO Flow Pattern

The service follows a validated **three-layer DTO pattern**:

1. **GraphQL Response** → Raw response from Navitaire API
2. **Application DTO** → Internal business representation
3. **API Response DTO** → Public API contract

This pattern ensures proper separation of concerns and maintains clean architectural boundaries.

## API Documentation
- **Swagger/OpenAPI**: Comprehensive API documentation
- **Annotations**: Detailed response type definitions
- **Examples**: Request/response samples

## 📊 Data Transfer Objects (DTOs)

### 🎯 **API DTOs** - Public Contract
Located in `checkinmanagement.API/DTOs/`

#### Request DTOs
```csharp
public class RetrieveJourneyApiRequest
{
    public string? Pnr { get; set; }
    public string? LastName { get; set; }
    public string? EmailId { get; set; }
    public string? BookingReference { get; set; }
}
```

#### Response DTOs
```csharp
public class RetrieveJourneyApiResponse
{
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public string? ErrorCode { get; set; }
    public JourneyData? Journey { get; set; }
}
```

### 🔧 **Application DTOs** - Internal Contract
Located in `checkinmanagement.Application/DTOs/`

**Purpose**: Isolation between API and Application layers

**Benefits**:
- **Stability**: API changes don't affect business logic
- **Flexibility**: Different validation rules per layer
- **Security**: Internal data structures remain hidden
- **Versioning**: Support multiple API versions with same business logic

## 🔐 Validation Strategy

### Three-Scenario Validation
The service implements complex validation logic supporting three distinct input scenarios:

```csharp
private static bool BeValidCombination(RetrieveJourneyApiRequest request)
{
    // Scenario 1: Booking Reference only
    var hasBookingReference = !string.IsNullOrWhiteSpace(request.BookingReference);
    
    // Scenario 2: PNR + Last Name
    var hasPnrAndLastName = !string.IsNullOrWhiteSpace(request.Pnr) && 
                           !string.IsNullOrWhiteSpace(request.LastName);
    
    // Scenario 3: PNR + Email
    var hasPnrAndEmail = !string.IsNullOrWhiteSpace(request.Pnr) && 
                        !string.IsNullOrWhiteSpace(request.EmailId);
    
    return hasBookingReference || hasPnrAndLastName || hasPnrAndEmail;
}
```

## 🧪 Testing Strategy

### Behavior-Driven Development (BDD)
- **Framework**: Reqnroll (SpecFlow successor)
- **Location**: `test/checkinmanagement.BDD/`
- **Features**: Gherkin-based scenarios
- **Benefits**: Living documentation, stakeholder collaboration

## 🚀 Getting Started

### Prerequisites
- .NET 8 SDK
- Visual Studio 2022 or VS Code
- Git

### Running the Service

1. **Clone the repository**
```bash
git clone <repository-url>
cd checkinmanagement-service
```

2. **Restore dependencies**
```bash
dotnet restore
```

3. **Build the solution**
```bash
dotnet build
```

4. **Run the API**
```bash
cd src/checkinmanagement.API
dotnet run
```

5. **Access Swagger Documentation**
```
http://localhost:5237/swagger
```

### Example API Calls

#### Health Check
```bash
curl -X GET "http://localhost:5237/checkin/v1/journeys/health"
```

#### Journey Retrieval (Booking Reference)
```bash
curl -X POST "http://localhost:5237/checkin/v1/journeys/retrieve" \
  -H "Content-Type: application/json" \
  -d '{"bookingReference": "ABC123"}'
```

#### Journey Retrieval (PNR + Email)
```bash
curl -X POST "http://localhost:5237/checkin/v1/journeys/retrieve" \
  -H "Content-Type: application/json" \
  -d '{"pnr": "PNR123", "emailId": "john@example.com"}'
```

#### Journey Details by Key
```bash
curl -X GET "http://localhost:5237/checkin/v1/journeys/ABC123~2025-08-15~DEL~BOM~AI101" \
  -H "Accept: application/json" \
  -H "X-Correlation-ID: 12350"
```

#### Contact Management - GET
```bash
curl -X GET "http://localhost:5237/checkin/v1/contacts" \
  -H "Accept: application/json" \
  -H "X-Correlation-ID: 12351"
```

#### Contact Management - POST
```bash
curl -X POST "http://localhost:5237/checkin/v1/contacts" \
  -H "Content-Type: application/json" \
  -H "X-Correlation-ID: 12352" \
  -d '{"testData": "sample"}'
```

## 📁 Project Structure

```
checkinmanagement-service/
├── src/
│   ├── checkinmanagement.API/          # 🎯 API Layer
│   │   ├── Controllers/
│   │   │   ├── v1/                     # Version 1 controllers
│   │   │   └── BaseController.cs       # Common controller functionality
│   │   ├── DTOs/                       # 📝 Data Transfer Objects
│   │   │   ├── Requests/              # Request models
│   │   │   └── Responses/             # Response models
│   │   ├── Validators/                 # ✅ FluentValidation rules
│   │   ├── Mappers/                    # 🔄 Mapster configurations
│   │   ├── Extensions/                 # 🔧 Service registration
│   │   └── Configuration/              # ⚙️ App configuration
│   ├── checkinmanagement.Application/  # 🔧 Application Layer
│   │   ├── Services/                   # Business logic
│   │   ├── Interfaces/                 # Service contracts
│   │   └── DTOs/                       # Internal DTOs
│   ├── checkinmanagement.Domain/       # 🏛️ Domain Layer
│   │   ├── Entities/                   # Core entities
│   │   └── Enums/                      # Domain enums
│   └── checkinmanagement.Infrastructure/ # 🔌 Infrastructure Layer
│       ├── ExternalServices/           # External integrations
│       └── MockData/                   # Development data
└── test/
    └── checkinmanagement.BDD/          # 🧪 BDD Tests
        ├── Features/                   # Gherkin scenarios
        └── StepDefinitions/            # Test implementations
```

## 🔧 Configuration

### API Versioning Configuration
```csharp
builder.Services.AddApiVersioning(opt =>
{
    opt.DefaultApiVersion = new ApiVersion(1, 0);
    opt.AssumeDefaultVersionWhenUnspecified = true;
    opt.ApiVersionReader = ApiVersionReader.Combine(
        new UrlSegmentApiVersionReader(),
        new QueryStringApiVersionReader("version"),
        new HeaderApiVersionReader("X-Version")
    );
}).AddMvc();
```

### Service Registration
```csharp
// Custom services registration
builder.Services.AddCustomServices();

// FluentValidation automatic registration
builder.Services.AddFluentValidationAutoValidation();
```

## 🎯 Best Practices Implemented

1. **SOLID Principles**: Single responsibility, dependency inversion
2. **Clean Architecture**: Clear separation of concerns
3. **API Design**: RESTful endpoints with proper HTTP semantics
4. **Error Handling**: Comprehensive error responses with codes
5. **Validation**: Multi-layer validation (API + Business rules)
6. **Documentation**: Swagger/OpenAPI with detailed annotations
7. **Logging**: Structured logging with correlation IDs
8. **Observability**: OpenTelemetry distributed tracing and metrics
9. **Testing**: BDD scenarios for business requirements
10. **Contaier File**: Containerization

## 🚧 Future Enhancements

### Planned Features
- [ ] Authentication & Authorization (JWT)
- [ ] Rate Limiting
- [ ] Caching Strategy (Redis)
- [ ] API Gateway Integration
- [ ] CI/CD Pipeline

### Already Implemented ✅
- [x] **OpenTelemetry Integration**: Distributed tracing, metrics, and observability
- [x] **Structured Logging**: Serilog with correlation IDs and enrichment
- [x] **HTTP Instrumentation**: Automatic request/response tracking
- [x] **Runtime Metrics**: .NET performance monitoring
- [x] **Exception Tracking**: Automatic error capture and correlation

## 🤝 Contributing

1. Follow Clean Architecture principles
2. Maintain test coverage
3. Update documentation
4. Follow coding standards
5. Create feature branches

## 📜 License

This project is licensed