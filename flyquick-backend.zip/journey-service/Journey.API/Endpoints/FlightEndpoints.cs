using Carter;
using Journey.Application.Features.Flights.Queries;
using Journey.Application.Features.Seats.Queries;
using Journey.Application.Features.Seats.Commands;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Journey.API.Endpoints;

public class FlightEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var flights = app.MapGroup("/api/flights")
            .WithTags("Flights")
            .WithOpenApi();

        flights.MapGet("/{flightNumber}", GetFlight)
            .WithName("GetFlight")
            .WithSummary("Get flight information")
            .Produces<FlightResponse>(200);

        flights.MapGet("/{flightNumber}/seats", GetAvailableSeats)
            .WithName("GetAvailableSeats")
            .WithSummary("Get available seats for flight")
            .Produces<SeatsResponse>(200);

        flights.MapPost("/{flightNumber}/seats/{seatNumber}/assign", AssignSeat)
            .WithName("AssignSeat")
            .WithSummary("Assign seat to passenger")
            .Produces<SeatAssignmentResponse>(200);
    }

    private static async Task<IResult> GetFlight(
        string flightNumber,
        [FromQuery] string departureDate,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetFlightQuery(flightNumber, DateTime.Parse(departureDate));
        var result = await mediator.Send(query, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> GetAvailableSeats(
        string flightNumber,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetAvailableSeatsQuery(flightNumber);
        var result = await mediator.Send(query, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> AssignSeat(
        string flightNumber,
        string seatNumber,
        [FromBody] AssignSeatRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = new AssignSeatCommand(flightNumber, seatNumber, request.Pnr);
        var result = await mediator.Send(command, cancellationToken);
        return Results.Ok(result);
    }
}

public record FlightResponse(
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Aircraft,
    string Gate);

public record SeatsResponse(string FlightNumber, SeatModel[] AvailableSeats);

public record SeatModel(
    string SeatNumber,
    string SeatType,
    bool IsAvailable,
    decimal? Price);

public record SeatAssignmentResponse(string Pnr, string SeatNumber, bool Success);

public record AssignSeatRequest(string Pnr);
