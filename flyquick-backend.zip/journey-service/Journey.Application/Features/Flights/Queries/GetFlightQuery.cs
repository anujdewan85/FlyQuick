using MediatR;

namespace Journey.Application.Features.Flights.Queries;

public record GetFlightQuery(string FlightNumber, DateTime DepartureDate) : IRequest<FlightDto>;

public record FlightDto(
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Aircraft,
    string Gate);

public class GetFlightQueryHandler : IRequestHandler<GetFlightQuery, FlightDto>
{
    public Task<FlightDto> Handle(GetFlightQuery request, CancellationToken cancellationToken)
    {
        // Mock implementation
        return Task.FromResult(new FlightDto(
            request.FlightNumber,
            request.DepartureDate,
            "BOM",
            "DEL",
            "A320",
            "A12"
        ));
    }
}
