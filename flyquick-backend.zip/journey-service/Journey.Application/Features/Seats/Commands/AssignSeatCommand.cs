using MediatR;

namespace Journey.Application.Features.Seats.Commands;

public record AssignSeatCommand(string FlightNumber, string SeatNumber, string Pnr) : IRequest<SeatAssignmentDto>;

public record SeatAssignmentDto(
    string Pnr,
    string SeatNumber,
    bool Success,
    string? ErrorMessage = null);

public class AssignSeatCommandHandler : IRequestHandler<AssignSeatCommand, SeatAssignmentDto>
{
    public Task<SeatAssignmentDto> Handle(AssignSeatCommand request, CancellationToken cancellationToken)
    {
        // Mock implementation - always succeed for demo
        return Task.FromResult(new SeatAssignmentDto(
            request.Pnr,
            request.SeatNumber,
            true
        ));
    }
}
