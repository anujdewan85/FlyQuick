using Passenger.Domain.Common;

namespace Passenger.Domain.Events;

public class PassengerCreatedEvent : IDomainEvent
{
    public string EventId { get; }
    public DateTime OccurredOn { get; }
    public string PassengerId { get; }
    public string FirstName { get; }
    public string LastName { get; }
    public string Email { get; }

    public PassengerCreatedEvent(string passengerId, string firstName, string lastName, string email)
    {
        EventId = Guid.NewGuid().ToString();
        OccurredOn = DateTime.UtcNow;
        PassengerId = passengerId;
        FirstName = firstName;
        LastName = lastName;
        Email = email;
    }
}
