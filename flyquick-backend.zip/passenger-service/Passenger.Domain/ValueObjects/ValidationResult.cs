using System.Collections.Generic;
using System.Linq;

namespace Passenger.Domain.ValueObjects;

/// <summary>
/// Represents the result of a domain validation operation
/// </summary>
public record ValidationResult
{
    public bool IsValid { get; init; }
    public IEnumerable<string> Errors { get; init; } = Array.Empty<string>();
    public IEnumerable<string> Warnings { get; init; } = Array.Empty<string>();

    private ValidationResult(bool isValid, IEnumerable<string> errors, IEnumerable<string> warnings)
    {
        IsValid = isValid;
        Errors = errors ?? Array.Empty<string>();
        Warnings = warnings ?? Array.Empty<string>();
    }

    /// <summary>
    /// Creates a successful validation result
    /// </summary>
    public static ValidationResult Success(IEnumerable<string>? warnings = null)
        => new(true, Array.Empty<string>(), warnings ?? Array.Empty<string>());

    /// <summary>
    /// Creates a failed validation result with error messages
    /// </summary>
    public static ValidationResult Failure(IEnumerable<string> errors, IEnumerable<string>? warnings = null)
        => new(false, errors, warnings ?? Array.Empty<string>());

    /// <summary>
    /// Creates a failed validation result with a single error message
    /// </summary>
    public static ValidationResult Failure(string error, IEnumerable<string>? warnings = null)
        => new(false, new[] { error }, warnings ?? Array.Empty<string>());

    /// <summary>
    /// Combines multiple validation results
    /// </summary>
    public static ValidationResult Combine(params ValidationResult[] results)
    {
        var allErrors = results.SelectMany(r => r.Errors).ToList();
        var allWarnings = results.SelectMany(r => r.Warnings).ToList();
        var isValid = !allErrors.Any();

        return new ValidationResult(isValid, allErrors, allWarnings);
    }

    /// <summary>
    /// Combines this result with another validation result
    /// </summary>
    public ValidationResult CombineWith(ValidationResult other)
    {
        var combinedErrors = Errors.Concat(other.Errors).ToList();
        var combinedWarnings = Warnings.Concat(other.Warnings).ToList();
        var isValid = !combinedErrors.Any();

        return new ValidationResult(isValid, combinedErrors, combinedWarnings);
    }

    /// <summary>
    /// Adds warnings to an existing result
    /// </summary>
    public ValidationResult WithWarnings(params string[] warnings)
    {
        var combinedWarnings = Warnings.Concat(warnings).ToList();
        return new ValidationResult(IsValid, Errors, combinedWarnings);
    }

    /// <summary>
    /// Gets all messages (errors and warnings) as a single collection
    /// </summary>
    public IEnumerable<string> GetAllMessages()
        => Errors.Concat(Warnings);
}
