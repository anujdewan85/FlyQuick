namespace Passenger.Domain.ValueObjects;

public enum CheckInStatus
{
    NotCheckedIn,
    CheckedIn,
    BoardingPassIssued,
    Boarded,
    NoShow,
    Cancelled
}
