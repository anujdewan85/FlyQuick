// Alternative: Provider-specific interfaces (NOT RECOMMENDED for your case)

namespace Passenger.Application.Abstractions;

public interface INavitaireApiService
{
    Task<PassengerDto?> GetPassengerAsync(string passengerId, CancellationToken cancellationToken = default);
    // ... Navitaire-specific methods
}

public interface IAmadeusApiService  
{
    Task<PassengerDto?> GetTravelerAsync(string travelerId, CancellationToken cancellationToken = default);
    // ... Amadeus-specific methods (different method names)
}

// BUT this defeats the purpose of polymorphism and makes handlers provider-specific
