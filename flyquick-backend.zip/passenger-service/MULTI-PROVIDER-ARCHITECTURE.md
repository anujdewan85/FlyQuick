# Multi-Provider Airline System API Architecture

This document explains the flexible architecture for supporting multiple external airline system providers (Navitaire, Amadeus, Sabre, etc.) in the Passenger Service.

## Architecture Overview

### Key Components

1. **`IAirlineSystemApiService`** - Generic interface for all airline system operations
2. **`IAirlineSystemApiServiceFactory`** - Factory for creating provider-specific services
3. **Provider-specific implementations** - Each airline system has its own service implementation
4. **Standardized DTOs** - Common data transfer objects used across all providers

### Supported Providers

- ✅ **Navitaire** - Fully implemented
- 🚧 **Amadeus** - Structure ready, implementation in progress
- ⏳ **Sabre** - Planned
- ⏳ **Travelport** - Planned

## Configuration

### appsettings.json Structure

```json
{
  "AirlineSystemProviders": {
    "Default": "Navitaire",
    "Navitaire": {
      "BaseUrl": "https://api.navitaire.com",
      "ApiKey": "your-navitaire-api-key",
      "Timeout": "00:00:30"
    },
    "Amadeus": {
      "BaseUrl": "https://api.amadeus.com",
      "ApiKey": "your-amadeus-api-key",
      "Timeout": "00:00:30"
    }
  }
}
```

### Switching Providers

To switch the default provider, simply change the `Default` value in configuration:

```json
"AirlineSystemProviders": {
  "Default": "Amadeus"  // Switch from Navitaire to Amadeus
}
```

## Usage in CQRS Handlers

Your command and query handlers remain unchanged regardless of the provider:

```csharp
public class CreatePassengerCommandHandler : IRequestHandler<CreatePassengerCommand, CreatePassengerResponse>
{
    private readonly IAirlineSystemApiService _airlineSystemApiService;

    public CreatePassengerCommandHandler(IAirlineSystemApiService airlineSystemApiService)
    {
        _airlineSystemApiService = airlineSystemApiService; // Will inject the configured provider
    }

    public async Task<CreatePassengerResponse> Handle(CreatePassengerCommand request, CancellationToken cancellationToken)
    {
        // This will call the appropriate provider (Navitaire, Amadeus, etc.)
        var result = await _airlineSystemApiService.CreatePassengerAsync(createRequest, cancellationToken);
        // ...
    }
}
```

## Adding a New Provider

To add support for a new airline system provider:

### 1. Add the Provider Enum

```csharp
public enum AirlineSystemProvider
{
    Navitaire,
    Amadeus,
    Sabre,
    YourNewProvider  // Add here
}
```

### 2. Create Provider-Specific Service

```csharp
public class YourNewProviderAirlineSystemApiService : IAirlineSystemApiService
{
    // Implement all interface methods with provider-specific logic
}
```

### 3. Update Factory

```csharp
public IAirlineSystemApiService CreateService(AirlineSystemProvider provider)
{
    return provider switch
    {
        // ... existing cases
        AirlineSystemProvider.YourNewProvider => _serviceProvider.GetRequiredService<YourNewProviderAirlineSystemApiService>(),
        _ => throw new ArgumentException($"Unsupported provider: {provider}")
    };
}
```

### 4. Register in DI Container

```csharp
services.AddHttpClient<YourNewProviderAirlineSystemApiService>();
services.AddScoped<YourNewProviderAirlineSystemApiService>();
```

### 5. Add Configuration

```json
{
  "AirlineSystemProviders": {
    "YourNewProvider": {
      "BaseUrl": "https://api.yournewprovider.com",
      "ApiKey": "your-api-key",
      "Timeout": "00:00:30"
    }
  }
}
```

## Benefits

- ✅ **Provider Agnostic**: CQRS handlers don't need to know about specific providers
- ✅ **Easy Switching**: Change providers through configuration only
- ✅ **Scalable**: Add new providers without changing existing code
- ✅ **Testable**: Mock `IAirlineSystemApiService` for unit tests
- ✅ **Maintainable**: Each provider has its own isolated implementation
- ✅ **Runtime Selection**: Can potentially support runtime provider selection per request

## Provider-Specific Considerations

### Navitaire
- Uses X-API-Key authentication
- Standard REST endpoints
- Camel case JSON responses

### Amadeus
- Uses Bearer token authentication
- Different endpoint structure (`/v1/travelers/` vs `/api/passengers/`)
- Requires response mapping from Amadeus format to standardized DTOs

### Future Providers
Each provider may have:
- Different authentication mechanisms
- Different endpoint structures
- Different request/response formats
- Different error handling patterns

The factory pattern and provider-specific services handle these differences while maintaining a consistent interface for your CQRS handlers.
