using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Passenger.Application.Abstractions;
using Passenger.Infrastructure.Services;

namespace Passenger.Infrastructure.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // NOTE: Database and repositories are available but not used in CQRS handlers
        // Uncomment below if you want to use them for caching, audit logging, etc.
        /*
        // Add Entity Framework (optional - for caching, audit logging, or backup)
        services.AddDbContext<PassengerDbContext>(options =>
            options.UseSqlite(configuration.GetConnectionString("DefaultConnection")));

        // Add repositories (optional - can be used alongside external APIs)
        services.AddScoped<IPassengerRepository, PassengerRepository>();
        services.AddScoped<IFlightReservationRepository, FlightReservationRepository>();
        */

        // Add HttpClient for each airline system provider
        services.AddHttpClient<NavitaireAirlineSystemApiService>();
        services.AddHttpClient<AmadeusAirlineSystemApiService>();

        // Register provider-specific services
        services.AddScoped<NavitaireAirlineSystemApiService>();
        services.AddScoped<AmadeusAirlineSystemApiService>();
        
        // Register the factory (for potential future use)
        services.AddScoped<IAirlineSystemApiServiceFactory, AirlineSystemApiServiceFactory>();
        
        // Register the main service interface - resolved once per scope
        services.AddScoped<IAirlineSystemApiService>(provider =>
        {
            var factory = provider.GetRequiredService<IAirlineSystemApiServiceFactory>();
            var defaultService = factory.GetDefaultService();
            
            // Optional: Log which provider is being used at startup
            var logger = provider.GetRequiredService<ILogger<IAirlineSystemApiService>>();
            logger.LogInformation("Configured airline system provider resolved successfully");
            
            return defaultService;
        });
        
        return services;
    }
}
