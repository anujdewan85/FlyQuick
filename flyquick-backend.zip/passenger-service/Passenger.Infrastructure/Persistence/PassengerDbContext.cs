using Microsoft.EntityFrameworkCore;
using Passenger.Domain.Entities;

namespace Passenger.Infrastructure.Persistence;

/// <summary>
/// Entity Framework DbContext for the Passenger service
/// Can be used for caching, audit logging, or backup alongside external API calls
/// </summary>
public class PassengerDbContext : DbContext
{
    public PassengerDbContext(DbContextOptions<PassengerDbContext> options) : base(options)
    {
    }

    public DbSet<Domain.Entities.Passenger> Passengers { get; set; }
    public DbSet<FlightBooking> FlightBookings { get; set; }
    public DbSet<PassengerFlightReservation> PassengerFlightReservations { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Configure Passenger entity
        modelBuilder.Entity<Domain.Entities.Passenger>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(255);
            entity.Property(e => e.Phone).HasMaxLength(20);
            entity.Property(e => e.PassportNumber).HasMaxLength(20);
        });

        // Configure FlightBooking entity
        modelBuilder.Entity<FlightBooking>(entity =>
        {
            entity.HasKey(e => e.BookingReference);
            entity.Property(e => e.BookingReference).IsRequired().HasMaxLength(10);
            entity.Property(e => e.BookingDate).IsRequired();
            entity.Property(e => e.BookingStatus).IsRequired().HasMaxLength(50);
            entity.Property(e => e.TotalAmount).HasColumnType("decimal(18,2)");
            entity.Property(e => e.Currency).IsRequired().HasMaxLength(3);
            entity.Property(e => e.ContactEmail).IsRequired().HasMaxLength(255);
            entity.Property(e => e.ContactPhone).HasMaxLength(20);
            
            // Configure relationship with reservations
            entity.HasMany(e => e.Reservations)
                  .WithOne()
                  .HasForeignKey("BookingReference")
                  .OnDelete(DeleteBehavior.Cascade);
        });

        // Configure PassengerFlightReservation entity
        modelBuilder.Entity<PassengerFlightReservation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Pnr).IsRequired().HasMaxLength(10);
            entity.Property(e => e.PassengerId).IsRequired().HasMaxLength(50);
            entity.Property(e => e.FlightNumber).IsRequired().HasMaxLength(10);
            entity.Property(e => e.DepartureTime).IsRequired();
            entity.Property(e => e.Origin).IsRequired().HasMaxLength(3);
            entity.Property(e => e.Destination).IsRequired().HasMaxLength(3);
            entity.Property(e => e.SeatNumber).HasMaxLength(5);
            entity.Property(e => e.CreatedAt).IsRequired();
            entity.Property(e => e.UpdatedAt);
            entity.Property(e => e.CheckInTime);
            
            // Configure the CheckInStatus enum
            entity.Property(e => e.Status)
                  .HasConversion<string>()
                  .IsRequired();
            
            // Configure relationship with Passenger
            entity.HasOne(e => e.Passenger)
                  .WithMany()
                  .HasForeignKey(e => e.PassengerId)
                  .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
