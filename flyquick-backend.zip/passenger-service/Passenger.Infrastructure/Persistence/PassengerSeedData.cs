using Passenger.Domain.Entities;

namespace Passenger.Infrastructure.Persistence;

/// <summary>
/// Seed data for passengers - can be used for testing or initial data
/// </summary>
public static class PassengerSeedData
{
    public static IEnumerable<Domain.Entities.Passenger> GetSeedPassengers()
    {
        return new List<Domain.Entities.Passenger>
        {
            new("John", "Doe", "john.doe@email.com", "+1234567890", 
                new DateTime(1990, 1, 15), "P123456789"),
            new("Jane", "Smith", "jane.smith@email.com", "+1234567891", 
                new DateTime(1985, 5, 20), "P987654321"),
            new("Bob", "Johnson", "bob.johnson@email.com", "+1234567892", 
                new DateTime(1992, 8, 10), "P456789123")
        };
    }
}
