using Passenger.Application.Abstractions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Passenger.Infrastructure.Services;

/// <summary>
/// Factory for creating airline system API services based on provider
/// </summary>
public class AirlineSystemApiServiceFactory(
    IServiceProvider serviceProvider,
    IConfiguration configuration,
    ILogger<AirlineSystemApiServiceFactory> logger) : IAirlineSystemApiServiceFactory
{
    private readonly IServiceProvider _serviceProvider = serviceProvider;
    private readonly IConfiguration _configuration = configuration;
    private readonly ILogger<AirlineSystemApiServiceFactory> _logger = logger;

    public IAirlineSystemApiService CreateService(AirlineSystemProvider provider)
    {
        _logger.LogInformation("Creating airline system API service for provider: {Provider}", provider);

        return provider switch
        {
            AirlineSystemProvider.Navitaire => _serviceProvider.GetRequiredService<NavitaireAirlineSystemApiService>(),
            AirlineSystemProvider.Amadeus => _serviceProvider.GetRequiredService<AmadeusAirlineSystemApiService>(),
            AirlineSystemProvider.Sabre => throw new NotImplementedException("Sabre provider not yet implemented"),
            AirlineSystemProvider.Travelport => throw new NotImplementedException("Travelport provider not yet implemented"),
            _ => throw new ArgumentException($"Unsupported airline system provider: {provider}")
        };
    }

    public IAirlineSystemApiService GetDefaultService()
    {
        var defaultProvider = _configuration.GetValue<AirlineSystemProvider>("AirlineSystemProviders:Default");
        _logger.LogInformation("Using default airline system provider: {Provider}", defaultProvider);
        
        return CreateService(defaultProvider);
    }
}
