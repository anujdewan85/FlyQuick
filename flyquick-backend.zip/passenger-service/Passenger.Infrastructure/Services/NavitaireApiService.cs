using Passenger.Application.Abstractions;
using Passenger.Application.DTOs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;

namespace Passenger.Infrastructure.Services;

public class NavitaireApiService : IAirlineSystemApiService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<NavitaireApiService> _logger;
    private readonly string _baseUrl;
    private readonly JsonSerializerOptions _jsonOptions;

    public NavitaireApiService(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<NavitaireApiService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
        _baseUrl = configuration["NavitaireApi:BaseUrl"] ?? throw new ArgumentNullException("NavitaireApi:BaseUrl");
        
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true
        };

        // Configure HttpClient with base settings
        _httpClient.BaseAddress = new Uri(_baseUrl);
        _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
        
        // Add API key if required
        var apiKey = configuration["NavitaireApi:ApiKey"];
        if (!string.IsNullOrEmpty(apiKey))
        {
            _httpClient.DefaultRequestHeaders.Add("X-API-Key", apiKey);
        }
    }

    public async Task<PassengerDto?> GetPassengerAsync(string passengerId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Fetching passenger from Navitaire API: {PassengerId}", passengerId);
            
            var response = await _httpClient.GetAsync($"/api/passengers/{passengerId}", cancellationToken);
            
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
            
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<PassengerDto>(content, _jsonOptions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching passenger from Navitaire API: {PassengerId}", passengerId);
            throw;
        }
    }

    public async Task<IEnumerable<PassengerDto>> GetPassengersAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Fetching all passengers from Navitaire API");
            
            var response = await _httpClient.GetAsync("/api/passengers", cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<IEnumerable<PassengerDto>>(content, _jsonOptions) ?? Enumerable.Empty<PassengerDto>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching passengers from Navitaire API");
            throw;
        }
    }

    public async Task<PassengerDto> CreatePassengerAsync(CreatePassengerRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Creating passenger in Navitaire API: {Email}", request.Email);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("/api/passengers", content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<PassengerDto>(responseContent, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating passenger in Navitaire API: {Email}", request.Email);
            throw;
        }
    }

    public async Task<FlightReservationDto?> GetFlightReservationAsync(string reservationId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Fetching flight reservation from Navitaire API: {ReservationId}", reservationId);
            
            var response = await _httpClient.GetAsync($"/api/reservations/{reservationId}", cancellationToken);
            
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
            
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<FlightReservationDto>(content, _jsonOptions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching flight reservation from Navitaire API: {ReservationId}", reservationId);
            throw;
        }
    }

    public async Task<FlightReservationDto?> GetFlightReservationByPnrAsync(string pnr, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Fetching flight reservation by PNR from Navitaire API: {Pnr}", pnr);
            
            var response = await _httpClient.GetAsync($"/api/reservations/pnr/{pnr}", cancellationToken);
            
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
            
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<FlightReservationDto>(content, _jsonOptions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching flight reservation by PNR from Navitaire API: {Pnr}", pnr);
            throw;
        }
    }

    public async Task<FlightReservationDto> CreateFlightReservationAsync(CreateFlightReservationRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Creating flight reservation in Navitaire API for passenger: {PassengerId}", request.PassengerId);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("/api/reservations", content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<FlightReservationDto>(responseContent, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating flight reservation in Navitaire API for passenger: {PassengerId}", request.PassengerId);
            throw;
        }
    }

    public async Task<CheckInStatusDto?> GetCheckInStatusAsync(string passengerId, string flightNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Fetching check-in status from Navitaire API: {PassengerId}, {FlightNumber}", passengerId, flightNumber);
            
            var response = await _httpClient.GetAsync($"/api/checkin/{passengerId}/{flightNumber}", cancellationToken);
            
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
            
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<CheckInStatusDto>(content, _jsonOptions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching check-in status from Navitaire API: {PassengerId}, {FlightNumber}", passengerId, flightNumber);
            throw;
        }
    }

    public async Task<CheckInResultDto> CheckInPassengerAsync(CheckInPassengerRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Checking in passenger in Navitaire API: {PassengerId}, {FlightNumber}", request.PassengerId, request.FlightNumber);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("/api/checkin", content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<CheckInResultDto>(responseContent, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking in passenger in Navitaire API: {PassengerId}, {FlightNumber}", request.PassengerId, request.FlightNumber);
            throw;
        }
    }

    public async Task<PassengerDto> UpdatePassengerAsync(string passengerId, UpdatePassengerRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Updating passenger in Navitaire API: {PassengerId}", passengerId);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PutAsync($"/api/passengers/{passengerId}", content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            return JsonSerializer.Deserialize<PassengerDto>(responseContent, _jsonOptions)!;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating passenger in Navitaire API: {PassengerId}", passengerId);
            throw;
        }
    }
}
