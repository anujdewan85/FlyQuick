using Carter;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Passenger.Application.Features.CheckInOperations.Commands;
using Passenger.API.DTOs;
using Mapster;

namespace Passenger.API.Endpoints;

public class CheckInEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/passengers/checkin")
            .WithTags("Check-in Operations")
            .WithOpenApi();

        group.MapPost("/", CheckInPassenger)
            .WithName("CheckInPassenger")
            .WithSummary("Check in a passenger using PNR")
            .Produces<CheckInPassengerResponse>(200)
            .Produces(400)
            .Produces(404);

        // New API-based check-in endpoint using Domain Services
        group.MapPost("/api", CheckInPassengerApi)
            .WithName("CheckInPassengerApi")
            .WithSummary("Check in a passenger using external API and domain validation")
            .Produces<CheckInPassengerApiResponse>(200)
            .Produces(400)
            .Produces(404);

        group.MapPut("/status/{pnr}", UpdateCheckinStatus)
            .WithName("UpdateCheckinStatus")
            .WithSummary("Update passenger check-in status")
            .Produces<UpdateCheckinStatusResponse>(200)
            .Produces(404);
    }

    private static async Task<IResult> CheckInPassenger(
        [FromBody] CheckInPassengerRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = request.Adapt<CheckInPassengerCommand>();
        var result = await mediator.Send(command, cancellationToken);
        var response = result.Adapt<CheckInPassengerResponse>();
        return Results.Ok(response);
    }

    private static async Task<IResult> CheckInPassengerApi(
        [FromBody] CheckInPassengerApiRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        try
        {
            var command = new CheckInPassengerApiCommand
            {
                PassengerId = request.PassengerId,
                Pnr = request.Pnr,
                FlightNumber = request.FlightNumber,
                CheckInTime = request.CheckInTime ?? DateTime.UtcNow,
                SeatPreference = request.SeatPreference,
                HasSpecialServices = request.HasSpecialServices
            };

            var result = await mediator.Send(command, cancellationToken);
            
            if (!result.IsSuccess)
            {
                return Results.BadRequest(new CheckInPassengerApiResponse
                {
                    IsSuccess = false,
                    Message = result.Message,
                    Errors = result.Errors.ToArray()
                });
            }

            return Results.Ok(new CheckInPassengerApiResponse
            {
                IsSuccess = true,
                Message = result.Message,
                CheckInTime = result.CheckInTime,
                Warnings = result.Warnings.ToArray()
            });
        }
        catch (Exception)
        {
            return Results.Problem(
                detail: "An unexpected error occurred during check-in.",
                statusCode: 500);
        }
    }

    private static async Task<IResult> UpdateCheckinStatus(
        string pnr,
        [FromBody] UpdateStatusRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = new UpdateCheckinStatusCommand(pnr, request.Status);
        var result = await mediator.Send(command, cancellationToken);
        var response = result.Adapt<UpdateCheckinStatusResponse>();
        return Results.Ok(response);
    }
}
