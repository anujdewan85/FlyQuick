namespace Passenger.API.DTOs;

// ===== CHECK-IN OPERATION DTOs =====
// These DTOs handle check-in workflows and status management

public record CheckInPassengerRequest(string PNR);

public record CheckInPassengerResponse(
    bool IsSuccess,
    string Message,
    DateTime? CheckInTime,
    string PNR,
    string SeatNumber = "",
    string GateNumber = "");

// ===== NEW API-BASED CHECK-IN DTOs =====
// These DTOs support the new Domain Services pattern with external API integration

public record CheckInPassengerApiRequest
{
    public string PassengerId { get; init; } = string.Empty;
    public string Pnr { get; init; } = string.Empty;
    public string FlightNumber { get; init; } = string.Empty;
    public DateTime? CheckInTime { get; init; }
    public string? SeatPreference { get; init; }
    public bool HasSpecialServices { get; init; }
}

public record CheckInPassengerApiResponse
{
    public bool IsSuccess { get; init; }
    public string Message { get; init; } = string.Empty;
    public DateTime? CheckInTime { get; init; }
    public string[] Errors { get; init; } = Array.Empty<string>();
    public string[] Warnings { get; init; } = Array.Empty<string>();
}

public record UpdateStatusRequest(string Status);

public record UpdateCheckinStatusResponse(
    string ReservationId,
    string Pnr,
    string Status,
    DateTime? CheckInTime);

public record GetCheckInStatusRequest(string PNR);

public record GetCheckInStatusResponse(
    string PNR,
    string Status,
    DateTime? CheckInTime,
    string SeatNumber = "",
    string GateNumber = "",
    bool CanCheckIn = false);

public record BulkCheckInRequest(
    List<string> PNRs);

public record BulkCheckInResponse(
    int SuccessCount,
    int FailureCount,
    List<CheckInResult> Results);

public record CheckInResult(
    string PNR,
    bool IsSuccess,
    string Message,
    DateTime? CheckInTime = null);
