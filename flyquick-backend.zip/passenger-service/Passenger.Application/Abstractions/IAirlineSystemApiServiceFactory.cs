namespace Passenger.Application.Abstractions;

/// <summary>
/// Enumeration of supported airline system providers
/// </summary>
public enum AirlineSystemProvider
{
    Navitaire,
    Amadeus,
    Sabre,
    Travelport
}

/// <summary>
/// Factory interface for creating airline system API services
/// </summary>
public interface IAirlineSystemApiServiceFactory
{
    IAirlineSystemApiService CreateService(AirlineSystemProvider provider);
    IAirlineSystemApiService GetDefaultService();
}

/// <summary>
/// Configuration for airline system providers
/// </summary>
public record AirlineSystemConfig(
    AirlineSystemProvider Provider,
    string BaseUrl,
    string? ApiKey,
    TimeSpan Timeout,
    bool IsDefault = false);
