using PassengerEntity = Passenger.Domain.Entities.Passenger;

namespace Passenger.Application.Abstractions;

/// <summary>
/// Repository interface for passenger operations
/// </summary>
public interface IPassengerRepository
{
    Task<PassengerEntity?> GetByIdAsync(string passengerId, CancellationToken cancellationToken = default);
    Task<IEnumerable<PassengerEntity>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<PassengerEntity> AddAsync(PassengerEntity passenger, CancellationToken cancellationToken = default);
    Task<PassengerEntity> UpdateAsync(PassengerEntity passenger, CancellationToken cancellationToken = default);
    Task DeleteAsync(string passengerId, CancellationToken cancellationToken = default);
}
