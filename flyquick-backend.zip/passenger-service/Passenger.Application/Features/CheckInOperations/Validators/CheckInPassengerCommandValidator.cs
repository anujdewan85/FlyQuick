using FluentValidation;
using Passenger.Application.Features.CheckInOperations.Commands;

namespace Passenger.Application.Features.CheckInOperations.Validators;

public class CheckInPassengerCommandValidator : AbstractValidator<CheckInPassengerCommand>
{
    public CheckInPassengerCommandValidator()
    {
        RuleFor(x => x.PNR)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 10)
            .WithMessage("PNR must be between 6 and 10 characters")
            .Matches("^[A-Z0-9]+$")
            .WithMessage("PNR must contain only uppercase letters and numbers");
            
        // Add a custom rule with detailed message
        RuleFor(x => x.PNR)
            .Must(BeTestPnr)
            .WithMessage("🚨 FluentValidation IS WORKING! This is proof that validation runs before the handler! 🚨")
            .When(x => x.PNR == "TEST");
    }

    private static bool BeValidGuid(string passengerId)
    {
        return Guid.TryParse(passengerId, out _);
    }
    
    private static bool BeTestPnr(string pnr)
    {
        return pnr != "TEST"; // This will always fail for "TEST"
    }
}
