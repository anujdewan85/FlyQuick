using MediatR;
using Microsoft.Extensions.Logging;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.CheckInOperations.Commands;

// Command to check in a passenger using PNR
public record CheckInPassengerCommand(string PNR) : IRequest<CheckInPassengerResult>;

// Response for check-in command
public record CheckInPassengerResult(
    bool IsSuccess,
    string Message,
    DateTime? CheckInTime);

// Command handler for passenger check-in
public class CheckInPassengerCommandHandler(
    ILogger<CheckInPassengerCommandHandler> logger,
    IFlightReservationRepository repository) : IRequestHandler<CheckInPassengerCommand, CheckInPassengerResult>
{
    private readonly ILogger<CheckInPassengerCommandHandler> _logger = logger;
    private readonly IFlightReservationRepository _repository = repository;

    public async Task<CheckInPassengerResult> Handle(CheckInPassengerCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Processing check-in for PNR: {PNR}", request.PNR);

        try
        {
            // Get the flight reservation by PNR
            var reservation = await _repository.GetByPnrAsync(request.PNR, cancellationToken);
            
            if (reservation == null)
            {
                _logger.LogWarning("Flight reservation not found with PNR: {PNR}", request.PNR);
                return new CheckInPassengerResult(
                    false,
                    "Flight reservation not found.",
                    null);
            }

            // Perform check-in using domain method
            var checkInResult = reservation.CheckIn();
            
            if (!checkInResult.IsSuccess)
            {
                _logger.LogWarning("Check-in failed for PNR: {PNR}. Reason: {Reason}", 
                    request.PNR, checkInResult.ErrorMessage);
                return new CheckInPassengerResult(
                    false,
                    checkInResult.ErrorMessage ?? "Check-in failed.",
                    null);
            }

            // Update the reservation
            await _repository.UpdateAsync(reservation, cancellationToken);

            _logger.LogInformation("Successfully checked in reservation for PNR: {PNR}", request.PNR);

            return new CheckInPassengerResult(
                true,
                "Passenger checked in successfully.",
                reservation.CheckInTime);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while checking in PNR: {PNR}", request.PNR);
            return new CheckInPassengerResult(
                false,
                "An error occurred while processing check-in. Please try again later.",
                null);
        }
    }
}
