using MediatR;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Passenger.Application.Abstractions;
using Passenger.Domain.ValueObjects;
using Passenger.Application.Services;

namespace Passenger.Application.Features.CheckInOperations.Commands;

/// <summary>
/// Modern check-in command using external API services and domain validation
/// </summary>
public record CheckInPassengerApiCommand : IRequest<CheckInPassengerApiResult>
{
    public string PassengerId { get; init; } = string.Empty;
    public string Pnr { get; init; } = string.Empty;
    public string FlightNumber { get; init; } = string.Empty;
    public DateTime CheckInTime { get; init; } = DateTime.UtcNow;
    public string? SeatPreference { get; init; }
    public bool HasSpecialServices { get; init; }
}

/// <summary>
/// Result for the modern check-in command
/// </summary>
public record CheckInPassengerApiResult
{
    public bool IsSuccess { get; init; }
    public string Message { get; init; } = string.Empty;
    public DateTime? CheckInTime { get; init; }
    public IEnumerable<string> Errors { get; init; } = Array.Empty<string>();
    public IEnumerable<string> Warnings { get; init; } = Array.Empty<string>();

    public static CheckInPassengerApiResult Success(string message, DateTime checkInTime, IEnumerable<string>? warnings = null)
        => new()
        {
            IsSuccess = true,
            Message = message,
            CheckInTime = checkInTime,
            Warnings = warnings ?? Array.Empty<string>()
        };

    public static CheckInPassengerApiResult Failed(string message, IEnumerable<string>? errors = null)
        => new()
        {
            IsSuccess = false,
            Message = message,
            Errors = errors ?? Array.Empty<string>()
        };
}

/// <summary>
/// FluentValidation validator for check-in command
/// </summary>
public class CheckInPassengerApiCommandValidator : AbstractValidator<CheckInPassengerApiCommand>
{
    public CheckInPassengerApiCommandValidator()
    {
        RuleFor(x => x.PassengerId)
            .NotEmpty()
            .WithMessage("Passenger ID is required");

        RuleFor(x => x.Pnr)
            .NotEmpty()
            .WithMessage("PNR is required")
            .Length(6, 10)
            .WithMessage("PNR must be between 6 and 10 characters");

        RuleFor(x => x.FlightNumber)
            .NotEmpty()
            .WithMessage("Flight number is required")
            .Matches(@"^[A-Z]{2}\d{3,4}$")
            .WithMessage("Flight number must be in format like 'AI123' or 'BA1234'");

        RuleFor(x => x.CheckInTime)
            .NotEmpty()
            .WithMessage("Check-in time is required")
            .Must(BeReasonableCheckInTime)
            .WithMessage("Check-in time must be within the last 24 hours");
    }

    private static bool BeReasonableCheckInTime(DateTime checkInTime)
    {
        var now = DateTime.UtcNow;
        return checkInTime >= now.AddDays(-1) && checkInTime <= now.AddMinutes(5);
    }
}

/// <summary>
/// CQRS handler integrating FluentValidation, Domain Services, and API Services
/// </summary>
public class CheckInPassengerApiCommandHandler : IRequestHandler<CheckInPassengerApiCommand, CheckInPassengerApiResult>
{
    private readonly IValidator<CheckInPassengerApiCommand> _validator;
    private readonly CheckInDomainService _domainService;
    private readonly IAirlineSystemApiService _apiService;
    private readonly ILogger<CheckInPassengerApiCommandHandler> _logger;

    public CheckInPassengerApiCommandHandler(
        IValidator<CheckInPassengerApiCommand> validator,
        CheckInDomainService domainService,
        IAirlineSystemApiService apiService,
        ILogger<CheckInPassengerApiCommandHandler> logger)
    {
        _validator = validator ?? throw new ArgumentNullException(nameof(validator));
        _domainService = domainService ?? throw new ArgumentNullException(nameof(domainService));
        _apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<CheckInPassengerApiResult> Handle(CheckInPassengerApiCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Processing API-based check-in for passenger {PassengerId} with PNR {Pnr} on flight {FlightNumber}", 
            request.PassengerId, request.Pnr, request.FlightNumber);

        try
        {
            // Step 1: FluentValidation - Input structure validation
            var validationResult = await _validator.ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                var errors = validationResult.Errors.Select(e => e.ErrorMessage);
                _logger.LogWarning("Check-in validation failed for passenger {PassengerId}: {Errors}", 
                    request.PassengerId, string.Join(", ", errors));
                
                return CheckInPassengerApiResult.Failed("Invalid input data provided.", errors);
            }

            // Step 2: Build initial context (flight details will be enriched later)
            var context = CheckInContext.Create(
                request.PassengerId,
                request.Pnr,
                request.FlightNumber,
                DateTime.UtcNow.Date, // placeholder, will be updated during enrichment
                DateTime.UtcNow,      // placeholder, will be updated during enrichment
                request.CheckInTime);

            // Step 3: Enrich context with API data (parallel calls)
            var enrichedContext = await _domainService.EnrichContextAsync(context, cancellationToken);

            // Add command-specific data
            enrichedContext = enrichedContext with 
            { 
                SeatPreference = request.SeatPreference,
                HasSpecialServices = request.HasSpecialServices
            };

            // Step 4: Domain Services - Business logic validation
            var businessValidation = await _domainService.ValidateCheckInAsync(enrichedContext, cancellationToken);
            if (!businessValidation.IsValid)
            {
                _logger.LogWarning("Business rule validation failed for passenger {PassengerId}: {Errors}", 
                    request.PassengerId, string.Join(", ", businessValidation.Errors));
                
                return CheckInPassengerApiResult.Failed("Check-in business rules validation failed.", businessValidation.Errors);
            }

            // Step 5: Execute check-in via external API service
            var checkInRequest = new CheckInPassengerRequest(
                request.PassengerId,
                request.FlightNumber,
                request.SeatPreference ?? "");

            var apiResult = await _apiService.CheckInPassengerAsync(checkInRequest, cancellationToken);

            _logger.LogInformation("Successfully checked in passenger {PassengerId} via external API. Success: {Success}", 
                request.PassengerId, apiResult.Success);

            var checkInTime = apiResult.Success ? DateTime.UtcNow : (DateTime?)null;
            return CheckInPassengerApiResult.Success(
                "Passenger checked in successfully.",
                checkInTime ?? DateTime.UtcNow,
                businessValidation.Warnings);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid argument during check-in for passenger {PassengerId}", request.PassengerId);
            return CheckInPassengerApiResult.Failed($"Invalid data: {ex.Message}");
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning(ex, "Invalid operation during check-in for passenger {PassengerId}", request.PassengerId);
            return CheckInPassengerApiResult.Failed($"Check-in not allowed: {ex.Message}");
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "External API error during check-in for passenger {PassengerId}", request.PassengerId);
            return CheckInPassengerApiResult.Failed("External system temporarily unavailable. Please try again later.");
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            _logger.LogError(ex, "Timeout during check-in for passenger {PassengerId}", request.PassengerId);
            return CheckInPassengerApiResult.Failed("Request timed out. Please try again.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during check-in for passenger {PassengerId}", request.PassengerId);
            return CheckInPassengerApiResult.Failed("An unexpected error occurred. Please try again later.");
        }
    }
}
