using MediatR;
using Passenger.Application.Abstractions;
using Passenger.Domain.ValueObjects;

namespace Passenger.Application.Features.CheckInOperations.Commands;

public record UpdateCheckinStatusCommand(string Pnr, string Status) : IRequest<PassengerStatusDto?>;

public record PassengerStatusDto(
    string Pnr,
    string Status,
    DateTime UpdatedAt);

public class UpdateCheckinStatusCommandHandler(IFlightReservationRepository repository) : IRequestHandler<UpdateCheckinStatusCommand, PassengerStatusDto?>
{
    private readonly IFlightReservationRepository _repository = repository;

    public async Task<PassengerStatusDto?> Handle(UpdateCheckinStatusCommand request, CancellationToken cancellationToken)
    {
        // Get the flight reservation by PNR
        var reservation = await _repository.GetByPnrAsync(request.Pnr, cancellationToken);
        
        if (reservation == null)
        {
            return null;
        }

        // Parse the status and update accordingly
        if (Enum.TryParse<CheckInStatus>(request.Status, true, out var newStatus))
        {
            if (newStatus == CheckInStatus.CheckedIn && reservation.Status != CheckInStatus.CheckedIn)
            {
                var checkInResult = reservation.CheckIn();
                if (!checkInResult.IsSuccess)
                {
                    // Return current status if check-in failed
                    return new PassengerStatusDto(
                        reservation.Pnr,
                        reservation.Status.ToString(),
                        reservation.UpdatedAt ?? DateTime.UtcNow
                    );
                }
            }
            else if (newStatus == CheckInStatus.NotCheckedIn && reservation.Status == CheckInStatus.CheckedIn)
            {
                reservation.CancelCheckIn();
            }

            // Save the changes
            await _repository.UpdateAsync(reservation, cancellationToken);

            return new PassengerStatusDto(
                reservation.Pnr,
                reservation.Status.ToString(),
                reservation.UpdatedAt ?? DateTime.UtcNow
            );
        }

        // Return current status if status parsing failed
        return new PassengerStatusDto(
            reservation.Pnr,
            reservation.Status.ToString(),
            reservation.UpdatedAt ?? DateTime.UtcNow
        );
    }
}
