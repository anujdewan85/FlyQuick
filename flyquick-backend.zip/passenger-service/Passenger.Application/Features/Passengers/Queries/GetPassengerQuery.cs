using MediatR;
using Passenger.Application.Abstractions;
using Passenger.Application.DTOs;
using Microsoft.Extensions.Logging;

namespace Passenger.Application.Features.Passengers.Queries;

public record GetPassengerQuery(string PassengerId) : IRequest<GetPassengerResponse>;

public record GetPassengerResponse(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public class GetPassengerQueryHandler : IRequestHandler<GetPassengerQuery, GetPassengerResponse?>
{
    private readonly IAirlineSystemApiService _airlineSystemApiService;
    private readonly ILogger<GetPassengerQueryHandler> _logger;

    public GetPassengerQueryHandler(
        IAirlineSystemApiService airlineSystemApiService,
        ILogger<GetPassengerQueryHandler> logger)
    {
        _airlineSystemApiService = airlineSystemApiService;
        _logger = logger;
    }

    public async Task<GetPassengerResponse?> Handle(GetPassengerQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Retrieving passenger: {PassengerId}", request.PassengerId);

        try
        {
            var passenger = await _airlineSystemApiService.GetPassengerAsync(request.PassengerId, cancellationToken);

            if (passenger == null)
            {
                _logger.LogWarning("Passenger not found: {PassengerId}", request.PassengerId);
                return null;
            }

            return new GetPassengerResponse(
                passenger.PassengerId,
                passenger.FirstName,
                passenger.LastName,
                passenger.Email,
                passenger.Phone,
                passenger.DateOfBirth,
                passenger.PassportNumber);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve passenger: {PassengerId}", request.PassengerId);
            throw;
        }
    }
}
