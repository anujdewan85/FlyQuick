using MediatR;
using Passenger.Application.Abstractions;
using Microsoft.Extensions.Logging;

namespace Passenger.Application.Features.PassengerManagement.Commands;

public record CreatePassengerCommand(
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber = "") : IRequest<CreatePassengerResult>;

public record CreatePassengerResult(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public class CreatePassengerCommandHandler : IRequestHandler<CreatePassengerCommand, CreatePassengerResult>
{
    private readonly IAirlineSystemApiService _airlineSystemApiService;
    private readonly ILogger<CreatePassengerCommandHandler> _logger;

    public CreatePassengerCommandHandler(
        IAirlineSystemApiService airlineSystemApiService,
        ILogger<CreatePassengerCommandHandler> logger)
    {
        _airlineSystemApiService = airlineSystemApiService;
        _logger = logger;
    }

    public async Task<CreatePassengerResult> Handle(CreatePassengerCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Creating passenger via external API: {Email}", request.Email);

        var createRequest = new CreatePassengerRequest(
            request.FirstName,
            request.LastName,
            request.Email,
            request.Phone,
            request.DateOfBirth,
            request.PassportNumber);

        try
        {
            var createdPassenger = await _airlineSystemApiService.CreatePassengerAsync(createRequest, cancellationToken);

            _logger.LogInformation("Successfully created passenger with ID: {PassengerId}", createdPassenger.PassengerId);

            return new CreatePassengerResult(
                createdPassenger.PassengerId,
                createdPassenger.FirstName,
                createdPassenger.LastName,
                createdPassenger.Email,
                createdPassenger.Phone,
                createdPassenger.DateOfBirth,
                createdPassenger.PassportNumber);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create passenger via external API: {Email}", request.Email);
            throw;
        }
    }
}
