using FluentValidation;
using PassengerEntity = Passenger.Domain.Entities.Passenger;

namespace Passenger.Application.Features.PassengerManagement.Validators;

public class PassengerValidator : AbstractValidator<PassengerEntity>
{
    public PassengerValidator()
    {
        RuleFor(x => x.FirstName)
            .NotEmpty()
            .WithMessage("First name is required")
            .MaximumLength(100)
            .WithMessage("First name cannot exceed 100 characters")
            .Matches("^[a-zA-Z\\s]+$")
            .WithMessage("First name can only contain letters and spaces");

        RuleFor(x => x.LastName)
            .NotEmpty()
            .WithMessage("Last name is required")
            .MaximumLength(100)
            .WithMessage("Last name cannot exceed 100 characters")
            .Matches("^[a-zA-Z\\s]+$")
            .WithMessage("Last name can only contain letters and spaces");

        RuleFor(x => x.Email)
            .NotEmpty()
            .WithMessage("Email is required")
            .EmailAddress()
            .WithMessage("Email must be a valid email address")
            .MaximumLength(255)
            .WithMessage("Email cannot exceed 255 characters");

        RuleFor(x => x.Phone)
            .NotEmpty()
            .WithMessage("Phone number is required")
            .Matches("^[+]?[0-9\\s\\-\\(\\)]+$")
            .WithMessage("Phone number must be valid")
            .MinimumLength(10)
            .WithMessage("Phone number must be at least 10 digits")
            .MaximumLength(20)
            .WithMessage("Phone number cannot exceed 20 characters");

        RuleFor(x => x.DateOfBirth)
            .NotEmpty()
            .WithMessage("Date of birth is required")
            .LessThan(DateTime.UtcNow.AddYears(-2))
            .WithMessage("Passenger must be at least 2 years old")
            .GreaterThan(DateTime.UtcNow.AddYears(-120))
            .WithMessage("Date of birth cannot be more than 120 years ago");

        RuleFor(x => x.PassportNumber)
            .MaximumLength(20)
            .WithMessage("Passport number cannot exceed 20 characters")
            .Matches("^[A-Z0-9]*$")
            .WithMessage("Passport number can only contain uppercase letters and numbers")
            .When(x => !string.IsNullOrEmpty(x.PassportNumber));
    }
}
