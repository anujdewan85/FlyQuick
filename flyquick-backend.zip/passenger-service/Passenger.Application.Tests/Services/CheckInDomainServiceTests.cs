using FluentAssertions;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Passenger.Application.Abstractions;
using Passenger.Application.DTOs;
using Passenger.Domain.ValueObjects;
using Passenger.Application.Services;
using Xunit;

namespace Passenger.Application.Tests.Services;

public class CheckInDomainServiceTests
{
    private readonly Mock<IAirlineSystemApiService> _mockApiService;
    private readonly Mock<IMemoryCache> _mockCache;
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<ILogger<CheckInDomainService>> _mockLogger;
    private readonly CheckInDomainService _domainService;

    public CheckInDomainServiceTests()
    {
        _mockApiService = new Mock<IAirlineSystemApiService>();
        _mockCache = new Mock<IMemoryCache>();
        _mockConfiguration = new Mock<IConfiguration>();
        _mockLogger = new Mock<ILogger<CheckInDomainService>>();

        // Setup configuration defaults
        _mockConfiguration.Setup(c => c.GetValue<int>("BusinessRules:CheckIn:MinHoursBeforeFlight", 2))
                         .Returns(2);
        _mockConfiguration.Setup(c => c.GetValue<int>("BusinessRules:CheckIn:MaxHoursBeforeFlight", 24))
                         .Returns(24);
        _mockConfiguration.Setup(c => c.GetValue<bool>("BusinessRules:CheckIn:RequireDocumentValidation", true))
                         .Returns(true);
        _mockConfiguration.Setup(c => c.GetValue<bool>("BusinessRules:CheckIn:EnableFlightStatusCheck", true))
                         .Returns(true);

        _domainService = new CheckInDomainService(
            _mockApiService.Object,
            _mockCache.Object,
            _mockConfiguration.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task ValidateCheckInAsync_ValidContext_ReturnsSuccess()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(4)
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Setup cache miss and API response
        object? cacheValue = null;
        _mockCache.Setup(c => c.TryGetValue(It.IsAny<string>(), out cacheValue))
                  .Returns(false);

        _mockApiService.Setup(s => s.GetFlightReservationByPnrAsync("ABC123", It.IsAny<CancellationToken>()))
                      .ReturnsAsync(reservation);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeTrue();
        result.Errors.Should().BeEmpty();
    }

    [Fact]
    public async Task ValidateCheckInAsync_CheckInTooEarly_ReturnsFailure()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(30) // 30 hours in future
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(error => error.Contains("not yet available"));
    }

    [Fact]
    public async Task ValidateCheckInAsync_CheckInTooLate_ReturnsFailure()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(1) // Only 1 hour left
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(error => error.Contains("closed"));
    }

    [Fact]
    public async Task ValidateCheckInAsync_MissingDocuments_ReturnsFailure()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), ""); // Missing document number

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(4)
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(error => error.Contains("document"));
    }

    [Fact]
    public async Task ValidateCheckInAsync_CancelledFlight_ReturnsFailure()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(4)
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Setup cache miss and API response for cancelled flight
        object? cacheValue = null;
        _mockCache.Setup(c => c.TryGetValue(It.IsAny<string>(), out cacheValue))
                  .Returns(false);

        var cancelledReservation = reservation with { Status = "Cancelled" };
        _mockApiService.Setup(s => s.GetFlightReservationByPnrAsync("ABC123", It.IsAny<CancellationToken>()))
                      .ReturnsAsync(cancelledReservation);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(error => error.Contains("cancelled"));
    }

    [Fact]
    public async Task ValidateCheckInAsync_CachedFlightStatus_UsesCachedData()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(4)
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow, passenger, reservation);

        // Setup cache hit
        object cacheValue = "OnTime";
        _mockCache.Setup(c => c.TryGetValue(It.IsAny<string>(), out cacheValue))
                  .Returns(true);

        // Act
        var result = await _domainService.ValidateCheckInAsync(context);

        // Assert
        result.IsValid.Should().BeTrue();
        
        // Verify that API service was not called because of cache hit
        _mockApiService.Verify(
            s => s.GetFlightReservationByPnrAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task EnrichContextAsync_LoadsMissingData()
    {
        // Arrange
        var passenger = new PassengerDto(
            "P123", "John", "Doe", "john@example.com", "+1234567890", 
            DateTime.Now.AddYears(-30), "ABC123456");

        var reservation = new FlightReservationDto
        {
            ReservationId = "R123",
            Pnr = "ABC123",
            Status = "Confirmed",
            FlightNumber = "AI123",
            FlightDate = DateTime.UtcNow.Date,
            DepartureTime = DateTime.UtcNow.AddHours(4)
        };

        var context = CheckInContext.Create("P123", "ABC123", "AI123", DateTime.UtcNow);

        _mockApiService.Setup(s => s.GetPassengerAsync("P123", It.IsAny<CancellationToken>()))
                      .ReturnsAsync(passenger);

        _mockApiService.Setup(s => s.GetFlightReservationByPnrAsync("ABC123", It.IsAny<CancellationToken>()))
                      .ReturnsAsync(reservation);

        // Act
        var enrichedContext = await _domainService.EnrichContextAsync(context);

        // Assert
        enrichedContext.Passenger.Should().Be(passenger);
        enrichedContext.Reservation.Should().Be(reservation);
        
        _mockApiService.Verify(s => s.GetPassengerAsync("P123", It.IsAny<CancellationToken>()), Times.Once);
        _mockApiService.Verify(s => s.GetFlightReservationByPnrAsync("ABC123", It.IsAny<CancellationToken>()), Times.Once);
    }
}
