
# Aviation Microservices - Independent Services Architecture

This repository contains production-ready .NET 8 microservices for an aviation system, implementing check-in, passenger management, and journey services as completely independent deployable units following 12-Factor App principles.

## 🚀 Quick Start

### Full System (All Services)
```bash
# Start all services with shared infrastructure
docker-compose up -d

# View all services status
docker-compose ps

# View logs
docker-compose logs -f
```

### Individual Services
Each service can be developed and deployed independently:

```bash
# Checkin Service (Port 5001)
cd checkin-service
docker-compose up -d

# Passenger Service (Port 5002)  
cd passenger-service
docker-compose up -d

# Journey Service (Port 5003)
cd journey-service
docker-compose up -d
```

## 🏗️ Independent Microservices Architecture

This solution implements fully independent microservices, each with its own:

```
checkin-backend/
├── checkin-service/           # 🔵 Independent Checkin Service
│   ├── checkin-service.sln   # Service-specific solution
│   ├── Checkin.API/          # API layer with Elsa workflows
│   ├── Checkin.Application/  # Business logic (CQRS/MediatR)
│   ├── Checkin.Domain/       # Domain entities and rules
│   ├── Checkin.Infrastructure/ # Data access and external services
│   ├── tests/                # Comprehensive test suite
│   ├── compose.yml           # Service + dependencies
│   ├── .devcontainer/        # Dev environment config
│   ├── Containerfile         # Production container
│   └── README.md             # Service-specific documentation
│
├── passenger-service/         # 🟢 Independent Passenger Service
│   ├── passenger-service.sln # Service-specific solution
│   ├── Passenger.API/        # API layer
│   ├── Passenger.Application/ # Business logic (CQRS/MediatR)
│   ├── Passenger.Domain/     # Domain entities and rules
│   ├── Passenger.Infrastructure/ # PSS integration & data access
│   ├── tests/                # Comprehensive test suite
│   ├── compose.yml           # Service + dependencies
│   ├── .devcontainer/        # Dev environment config
│   ├── Containerfile         # Production container
│   └── README.md             # Service-specific documentation
│
├── journey-service/           # 🟡 Independent Journey Service
│   ├── journey-service.sln   # Service-specific solution
│   ├── Journey.API/          # API layer
│   ├── Journey.Application/  # Business logic (CQRS/MediatR)
│   ├── Journey.Domain/       # Domain entities and rules
│   ├── Journey.Infrastructure/ # Flight systems & data access
│   ├── tests/                # Comprehensive test suite
│   ├── compose.yml           # Service + dependencies
│   ├── .devcontainer/        # Dev environment config
│   ├── Containerfile         # Production container
│   └── README.md             # Service-specific documentation
│
├── compose.yml               # 🌐 Full system orchestration
├── dev-setup.sh             # Development environment setup
└── README.md                 # This file
```

### Service Independence Benefits

✅ **Separate Development**: Each team can work independently  
✅ **Independent Deployment**: Deploy services separately  
✅ **Technology Diversity**: Different tech stacks per service  
✅ **Isolated Scaling**: Scale services individually  
✅ **Fault Isolation**: Service failures don't cascade  
✅ **Database Per Service**: Each service owns its data  

## 🎯 Services Overview

### 🔵 Checkin Service (Port 5001)
**Backend-for-Frontend (BFF) for mobile applications**
- Elsa workflow orchestration for check-in processes
- Integration with Passenger and Journey services
- Mobile-optimized API design
- Caching for performance

**Key Features:**
- Workflow-based check-in process
- Passenger validation and seat assignment
- Boarding pass generation
- Real-time status updates

### 🟢 Passenger Service (Port 5002)
**Core passenger data management**
- Navitaire PSS integration
- Passenger profile management
- Booking and reservation data
- GDPR-compliant data handling

**Key Features:**
- Passenger CRUD operations
- PNR-based lookups
- Check-in status management
- Data synchronization with PSS

### 🟡 Journey Service (Port 5003)
**Flight and journey management**
- Flight information and schedules
- Seat inventory and assignment
- Route planning and management
- Real-time flight updates

**Key Features:**
- Flight schedule management
- Seat availability and assignment
- Aircraft configuration
- Schedule change notifications

### 🟣 UserJourney Service (Port 5004)
**NRules-based mobile screen determination**
- Smart mobile UX flow orchestration using NRules business rules engine
- Dynamic screen determination based on passenger context
- Mobile app backend for user experience flows
- Real-time rule evaluation with caching

**Key Features:**
- Business rules engine (NRules) for screen determination
- Context-aware mobile experience
- Passenger scenario analysis (check-in status, flight status, special needs)
- Configurable business rules for different user journeys
- Fast rule evaluation with intelligent caching

## 🔧 Technology Stack

### Core Framework
- **.NET 8** - Modern framework with native AOT support
- **Carter** - Lightweight HTTP API framework
- **MediatR** - CQRS and mediator pattern
- **FluentValidation** - Request validation

### Workflows & Business Logic
- **Elsa 3.1.4** - Workflow engine (Checkin service)
- **NRules** - Business rules engine (UserJourney service)
- **AutoMapper** - Object-to-object mapping
- **FluentResults** - Railway-oriented programming

### Data & Caching
- **Entity Framework Core** - ORM with migrations
- **Redis** - Distributed caching and session store
- **SQLite** - Development database (easily switched to SQL Server/PostgreSQL)

### Messaging & Integration
- **RabbitMQ + MassTransit** - Reliable message bus
- **Polly** - Resilience and fault tolerance
- **HTTP Client Factory** - Resilient HTTP communications

### Observability
- **Serilog** - Structured logging with enrichers
- **Seq** - Centralized log aggregation and analysis
- **OpenTelemetry** - Distributed tracing and metrics
- **Health Checks** - Comprehensive health monitoring

### Testing & Quality
- **xUnit** - Primary testing framework
- **FluentAssertions** - Expressive assertions
- **SpecFlow** - Behavior-driven development
- **TestContainers** - Integration testing with real dependencies
- **Moq** - Mocking framework
- **AutoFixture** - Test data generation
- **Bogus** - Fake data generation

### Container & Deployment
- **Red Hat UBI 8** - Secure container base images
- **Multi-stage Docker builds** - Optimized container images
- **Docker Compose** - Local development orchestration
- **Health checks** - Container and application health

## 🏃‍♂️ Development Setup

### Prerequisites
```bash
# Install .NET 8 SDK
# Install Docker Desktop
# Install VS Code (recommended)
```

### Quick Setup
```bash
# Clone the repository
git clone <repository-url>
cd checkin-backend

# Make setup script executable and run
chmod +x dev-setup.sh
./dev-setup.sh

# Start all services
docker-compose up -d
```

### Individual Service Development
Each service can be developed independently:

```bash
# Checkin Service
cd checkin-service
code .  # Opens in VS Code with service-specific settings
dotnet restore
dotnet run --project Checkin.API

# Or use Dev Containers for isolated environment
# Command Palette: "Dev Containers: Reopen in Container"
```

## 🧪 Testing Strategy

### Test Pyramid Implementation
```bash
# Run all tests across all services
find . -name "*.csproj" -path "*/tests/*" -exec dotnet test {} \;

# Service-specific testing
cd checkin-service
dotnet test                    # All tests
dotnet test tests/Checkin.UnitTests/         # Unit tests only
dotnet test tests/Checkin.IntegrationTests/  # Integration tests
dotnet test tests/Checkin.AcceptanceTests/   # E2E/BDD tests

# With coverage
dotnet test --collect:"XPlat Code Coverage" --results-directory ./coverage
```

### Test Categories
- **Unit Tests**: Fast, isolated, business logic testing
- **Integration Tests**: Database and external service integration
- **Acceptance Tests**: BDD scenarios with SpecFlow
- **Contract Tests**: API contract verification
- **Performance Tests**: Load and stress testing

## 📊 Monitoring & Observability

### Health Check Endpoints
- **System Health**: http://localhost:5000 (Health UI)
- **Checkin Service**: http://localhost:5001/health
- **Passenger Service**: http://localhost:5002/health  
- **Journey Service**: http://localhost:5003/health
- **UserJourney Service**: http://localhost:5004/health

### Logging & Monitoring
- **Seq Dashboard**: http://localhost:8080
- **RabbitMQ Management**: http://localhost:15672 (guest/guest)
- **Service APIs**: Swagger UI available at `/swagger` for each service

### Structured Logging
All services implement structured logging with:
- Request/Response logging with correlation IDs
- Performance metrics and timing
- Error tracking with context
- Business event logging
- Security audit logs

## 🚀 Deployment

### Container Registry
```bash
# Build all services for production
docker-compose -f compose.yml -f compose.prod.yml build

# Push to registry
docker-compose -f compose.yml -f compose.prod.yml push
```

### Kubernetes (Coming Soon)
- Helm charts for each service
- Horizontal Pod Autoscaling
- Service mesh integration (Istio)
- GitOps deployment pipelines

### Environment Configurations
- **Development**: Full logging, hot reload, debug symbols
- **Staging**: Production-like with enhanced monitoring
- **Production**: Optimized performance, security hardening

## 🔒 Security

### Authentication & Authorization
- JWT Bearer token authentication
- Role-based access control (RBAC)
- API key authentication for service-to-service
- Rate limiting and request throttling

### Data Protection
- HTTPS enforcement (TLS 1.3)
- Data encryption at rest and in transit
- PII masking in logs
- GDPR compliance features
- Audit trail for sensitive operations

### Container Security
- Non-root container execution
- Minimal attack surface with UBI base images
- Regular security scanning
- Secrets management (not in environment variables)

## 🔧 Configuration

Each service supports:
- **appsettings.json**: Base configuration
- **Environment variables**: Runtime overrides
- **Azure Key Vault**: Secrets management (production)
- **Configuration hot reload**: Runtime updates without restart

### Key Configuration Areas
- Database connection strings
- Redis cache settings
- RabbitMQ messaging
- External service endpoints
- Logging levels and targets
- Security settings

## 📈 Performance

### Optimization Features
- **Async/await** throughout for non-blocking I/O
- **Distributed caching** with Redis
- **Connection pooling** for databases and HTTP clients
- **Response compression** and caching
- **Efficient serialization** with System.Text.Json
- **Memory optimization** with Span<T> and Memory<T>

### Scalability Patterns
- **Horizontal scaling** with stateless design
- **Database read replicas** support
- **CQRS** for command/query separation
- **Event sourcing** capabilities
- **Background job processing** with Hangfire

## 🆘 Troubleshooting

### Common Issues

1. **Services won't start**
   ```bash
   # Check Docker daemon
   docker info
   
   # Verify ports are available
   netstat -tulpn | grep -E ':(5001|5002|5003|6379|5672)'
   
   # Check service logs
   docker-compose logs [service-name]
   ```

2. **Database connection issues**
   ```bash
   # Reset databases
   docker-compose down -v
   docker-compose up -d
   ```

3. **Performance issues**
   - Check Redis connectivity
   - Monitor memory usage
   - Review slow query logs
   - Verify health check endpoints

### Support Resources
- 📖 **Service Documentation**: Each service has detailed README
- 🔍 **Logs**: Centralized in Seq dashboard
- 📊 **Metrics**: Health checks and performance counters
- 🐛 **Issues**: Use GitHub issues for bug reports

## 🤝 Contributing

### Development Workflow
1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Choose the service to work on (`cd checkin-service`)
4. Make changes with tests
5. Commit changes (`git commit -m 'Add amazing feature'`)
6. Push to branch (`git push origin feature/amazing-feature`)
7. Open Pull Request

### Code Standards
- Follow .NET coding conventions
- Maintain test coverage >80%
- Update documentation for public APIs
- Use conventional commits
- Run security scanning
