namespace UserJourney.Domain.Entities;

/// <summary>
/// Represents a passenger with their booking and travel details
/// </summary>
public class Passenger
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
    public string FirstName { get; init; } = string.Empty;
    public bool IsCheckedIn { get; init; }
    public bool HasSpecialNeeds { get; init; }
    public bool IsFrequentFlyer { get; init; }
    public PassengerType Type { get; init; } = PassengerType.Adult;
    public DateTime FlightDepartureTime { get; init; }
    public FlightStatus FlightStatus { get; init; } = FlightStatus.Scheduled;
    public bool HasSeatAssigned { get; init; }
    public bool HasBaggageChecked { get; init; }
    public bool RequiresDocumentVerification { get; init; }
    public bool HasMobileBoardingPass { get; init; }
    public int CheckinWindowHours { get; init; } = 24;
    
    // New properties for NRules
    public CheckInStatus CheckInStatus { get; init; } = CheckInStatus.NotStarted;
    public bool HasBaggage { get; init; }
    public TimeSpan FlightDuration { get; init; } = TimeSpan.FromHours(1);
    public ServiceClass ServiceClass { get; init; } = ServiceClass.Economy;
    public bool HasSpecialRequests { get; init; }
    public bool HasEmergencyNotifications { get; init; }
    public bool RequiresSpecialAssistance { get; init; }
    public FlightType FlightType { get; init; } = FlightType.Domestic;
    public TripType TripType { get; init; } = TripType.OneWay;
}

/// <summary>
/// Represents the mobile screen that should be shown to the user
/// </summary>
public class MobileScreen
{
    public string ScreenId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public ScreenType Type { get; init; } = ScreenType.Information;
    public int Order { get; init; }
    public bool IsRequired { get; init; }
    public Dictionary<string, object> Parameters { get; init; } = new();
    public List<string> Actions { get; init; } = new();
}

/// <summary>
/// Represents the complete user journey with ordered screens
/// </summary>
public class UserJourneyResult
{
    public string Pnr { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
    public List<MobileScreen> Screens { get; init; } = new();
    public JourneyStatus Status { get; init; } = JourneyStatus.InProgress;
    public string Message { get; init; } = string.Empty;
    public DateTime GeneratedAt { get; init; } = DateTime.UtcNow;
}

/// <summary>
/// Context object used by NRules engine
/// </summary>
public class JourneyContext
{
    public Passenger Passenger { get; init; } = new();
    public List<MobileScreen> Screens { get; } = new();
    public DateTime CurrentTime { get; init; } = DateTime.UtcNow;
    
    public void AddScreen(MobileScreen screen)
    {
        if (!Screens.Any(s => s.ScreenId == screen.ScreenId))
        {
            Screens.Add(screen);
        }
    }
    
    public bool IsWithinCheckinWindow()
    {
        var checkinOpenTime = Passenger.FlightDepartureTime.AddHours(-Passenger.CheckinWindowHours);
        var checkinCloseTime = Passenger.FlightDepartureTime.AddHours(-1); // Close 1 hour before departure
        
        return CurrentTime >= checkinOpenTime && CurrentTime <= checkinCloseTime;
    }
    
    /// <summary>
    /// Helper method to determine if baggage prompt should be shown
    /// </summary>
    public bool ShouldPromptBaggage(JourneyContext context)
    {
        // Business logic to determine if baggage screen should be shown
        return context.Passenger.FlightType == FlightType.International ||
               context.Passenger.ServiceClass != ServiceClass.Basic ||
               context.Passenger.TripType == TripType.RoundTrip;
    }
}

public enum PassengerType
{
    Adult,
    Child,
    Infant,
    UnaccompaniedMinor
}

public enum FlightStatus
{
    Scheduled,
    Delayed,
    Cancelled,
    Boarding,
    Departed,
    OnTime,
    GateChanged
}

public enum ScreenType
{
    Information,
    Action,
    Verification,
    Confirmation,
    Error,
    Warning,
    Selection,
    Form,
    Document,
    Alert
}

public enum JourneyStatus
{
    InProgress,
    Complete,
    Blocked,
    Error
}

public enum CheckInStatus
{
    NotStarted,
    InProgress,
    Completed,
    ReadyForBoardingPass,
    Blocked
}

public enum ServiceClass
{
    Basic,
    Economy,
    Premium,
    Business,
    First
}

public enum FlightType
{
    Domestic,
    International
}

public enum TripType
{
    OneWay,
    RoundTrip,
    MultiCity
}
