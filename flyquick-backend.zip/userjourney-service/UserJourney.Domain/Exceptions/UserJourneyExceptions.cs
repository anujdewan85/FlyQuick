namespace UserJourney.Domain.Exceptions;

/// <summary>
/// Base exception for UserJourney service
/// </summary>
public abstract class UserJourneyException : Exception
{
    protected UserJourneyException(string message) : base(message) { }
    protected UserJourneyException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>
/// Exception thrown when passenger data is not found
/// </summary>
public class PassengerNotFoundException : UserJourneyException
{
    public string Pnr { get; }
    public string LastName { get; }
    
    public PassengerNotFoundException(string pnr, string lastName) 
        : base($"Passenger not found for PNR '{pnr}' and last name '{lastName}'")
    {
        Pnr = pnr;
        LastName = lastName;
    }
}

/// <summary>
/// Exception thrown when passenger validation fails
/// </summary>
public class PassengerValidationException : UserJourneyException
{
    public string Pnr { get; }
    
    public PassengerValidationException(string pnr, string message) 
        : base($"Validation failed for PNR '{pnr}': {message}")
    {
        Pnr = pnr;
    }
}

/// <summary>
/// Exception thrown when rules engine fails
/// </summary>
public class RulesEngineException : UserJourneyException
{
    public RulesEngineException(string message) : base($"Rules engine error: {message}") { }
    public RulesEngineException(string message, Exception innerException) 
        : base($"Rules engine error: {message}", innerException) { }
}

/// <summary>
/// Exception thrown when external service integration fails
/// </summary>
public class ExternalServiceException : UserJourneyException
{
    public string ServiceName { get; }
    
    public ExternalServiceException(string serviceName, string message) 
        : base($"External service '{serviceName}' error: {message}")
    {
        ServiceName = serviceName;
    }
    
    public ExternalServiceException(string serviceName, string message, Exception innerException) 
        : base($"External service '{serviceName}' error: {message}", innerException)
    {
        ServiceName = serviceName;
    }
}
