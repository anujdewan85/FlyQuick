using FluentResults;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using NRules;
using NRules.Fluent;
using UserJourney.Application.Queries;
using UserJourney.Domain.Entities;
using UserJourney.Domain.Exceptions;

namespace UserJourney.Application.Handlers;

/// <summary>
/// Handler for GetUserJourneyQuery that uses NRules to determine mobile screens
/// </summary>
public class GetUserJourneyQueryHandler : IRequestHandler<GetUserJourneyQuery, Result<UserJourneyResult>>
{
    private readonly IMediator _mediator;
    private readonly IMemoryCache _cache;
    private readonly ILogger<GetUserJourneyQueryHandler> _logger;
    private readonly ISession _rulesSession;

    public GetUserJourneyQueryHandler(
        IMediator mediator,
        IMemoryCache cache,
        ILogger<GetUserJourneyQueryHandler> logger)
    {
        _mediator = mediator;
        _cache = cache;
        _logger = logger;
        
        // Initialize NRules engine
        var repository = new RuleRepository();
        repository.Load(x => x.From(typeof(UserJourney.Domain.Entities.JourneyContext).Assembly));
        
        var factory = repository.Compile();
        _rulesSession = factory.CreateSession();
    }

    public async Task<Result<UserJourneyResult>> Handle(GetUserJourneyQuery request, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Processing user journey request for PNR: {Pnr}, LastName: {LastName}", 
                request.Pnr, request.LastName);

            // Get passenger information
            var passengerResult = await _mediator.Send(new GetPassengerInfoQuery 
            { 
                Pnr = request.Pnr, 
                LastName = request.LastName 
            }, cancellationToken);

            if (passengerResult.IsFailed)
            {
                _logger.LogWarning("Failed to retrieve passenger info for PNR: {Pnr}", request.Pnr);
                return passengerResult.ToResult<UserJourneyResult>();
            }

            var passenger = passengerResult.Value;
            
            // Check cache first
            var cacheKey = $"user_journey_{request.Pnr}_{request.LastName}_{passenger.FlightDepartureTime:yyyyMMddHHmm}";
            if (_cache.TryGetValue(cacheKey, out UserJourneyResult? cachedResult) && cachedResult != null)
            {
                _logger.LogDebug("Returning cached user journey for PNR: {Pnr}", request.Pnr);
                return Result.Ok(cachedResult);
            }

            // Create journey context for NRules
            var context = new JourneyContext
            {
                Passenger = passenger,
                CurrentTime = DateTime.UtcNow
            };

            // Execute rules engine
            _rulesSession.Insert(context);
            _rulesSession.Fire();

            // Sort screens by order
            var orderedScreens = context.Screens
                .OrderBy(s => s.Order)
                .ThenBy(s => s.ScreenId)
                .ToList();

            // Determine journey status
            var journeyStatus = DetermineJourneyStatus(passenger, orderedScreens);
            var journeyMessage = GetJourneyMessage(journeyStatus, passenger);

            var result = new UserJourneyResult
            {
                Pnr = request.Pnr,
                LastName = request.LastName,
                Screens = orderedScreens,
                Status = journeyStatus,
                Message = journeyMessage,
                GeneratedAt = DateTime.UtcNow
            };

            // Cache the result for 5 minutes
            _cache.Set(cacheKey, result, TimeSpan.FromMinutes(5));

            _logger.LogInformation("Successfully generated user journey with {ScreenCount} screens for PNR: {Pnr}", 
                orderedScreens.Count, request.Pnr);

            return Result.Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing user journey for PNR: {Pnr}", request.Pnr);
            return Result.Fail(new ExceptionalError("Failed to generate user journey", ex));
        }
    }

    private static JourneyStatus DetermineJourneyStatus(Passenger passenger, List<MobileScreen> screens)
    {
        // If passenger is already checked in
        if (passenger.IsCheckedIn)
        {
            return JourneyStatus.Complete;
        }

        // If flight is cancelled
        if (passenger.FlightStatus == FlightStatus.Cancelled)
        {
            return JourneyStatus.Blocked;
        }

        // If unaccompanied minor (requires counter service)
        if (passenger.Type == PassengerType.UnaccompaniedMinor)
        {
            return JourneyStatus.Blocked;
        }

        // If check-in is not available due to timing
        if (screens.Any(s => s.ScreenId == "checkin_not_available"))
        {
            return JourneyStatus.Blocked;
        }

        return JourneyStatus.InProgress;
    }

    private static string GetJourneyMessage(JourneyStatus status, Passenger passenger)
    {
        return status switch
        {
            JourneyStatus.Complete => "You are checked in. Your boarding pass is ready.",
            JourneyStatus.Blocked when passenger.FlightStatus == FlightStatus.Cancelled => 
                "Your flight has been cancelled. Please contact customer service.",
            JourneyStatus.Blocked when passenger.Type == PassengerType.UnaccompaniedMinor => 
                "Unaccompanied minors must check in at the counter.",
            JourneyStatus.Blocked => "Check-in is not currently available.",
            JourneyStatus.InProgress => "Follow the steps to complete your check-in.",
            _ => "Welcome to mobile check-in."
        };
    }
}
