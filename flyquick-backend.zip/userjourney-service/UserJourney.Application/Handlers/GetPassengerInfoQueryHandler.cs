using FluentResults;
using MediatR;
using Microsoft.Extensions.Logging;
using UserJourney.Application.Queries;
using UserJourney.Domain.Entities;
using UserJourney.Domain.Exceptions;

namespace UserJourney.Application.Handlers;

/// <summary>
/// Handler for GetPassengerInfoQuery - simulates passenger data retrieval
/// </summary>
public class GetPassengerInfoQueryHandler : IRequestHandler<GetPassengerInfoQuery, Result<Passenger>>
{
    private readonly ILogger<GetPassengerInfoQueryHandler> _logger;

    public GetPassengerInfoQueryHandler(ILogger<GetPassengerInfoQueryHandler> logger)
    {
        _logger = logger;
    }

    public async Task<Result<Passenger>> Handle(GetPassengerInfoQuery request, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Retrieving passenger info for PNR: {Pnr}, LastName: {LastName}", 
                request.Pnr, request.LastName);

            // Simulate async operation (in real implementation, this would call Passenger Service)
            await Task.Delay(100, cancellationToken);

            // Mock passenger data based on PNR patterns for testing
            var passenger = GenerateMockPassengerData(request.Pnr, request.LastName);

            if (passenger == null)
            {
                _logger.LogWarning("Passenger not found for PNR: {Pnr}, LastName: {LastName}", 
                    request.Pnr, request.LastName);
                return Result.Fail(new Error("Passenger not found").CausedBy(
                    new PassengerNotFoundException(request.Pnr, request.LastName)));
            }

            _logger.LogInformation("Successfully retrieved passenger info for PNR: {Pnr}", request.Pnr);
            return Result.Ok(passenger);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving passenger info for PNR: {Pnr}", request.Pnr);
            return Result.Fail(new ExceptionalError("Failed to retrieve passenger information", ex));
        }
    }

    private static Passenger? GenerateMockPassengerData(string pnr, string lastName)
    {
        // Mock data generation based on PNR patterns for testing
        return pnr.ToUpper() switch
        {
            "ABC123" when lastName.Equals("SMITH", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "JOHN",
                IsCheckedIn = false,
                HasSpecialNeeds = false,
                IsFrequentFlyer = true,
                Type = PassengerType.Adult,
                FlightDepartureTime = DateTime.UtcNow.AddHours(12),
                FlightStatus = FlightStatus.Scheduled,
                HasSeatAssigned = false,
                HasBaggageChecked = true,
                RequiresDocumentVerification = false,
                HasMobileBoardingPass = false,
                CheckinWindowHours = 24
            },
            
            "DEF456" when lastName.Equals("JOHNSON", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "SARAH",
                IsCheckedIn = true,
                HasSpecialNeeds = false,
                IsFrequentFlyer = false,
                Type = PassengerType.Adult,
                FlightDepartureTime = DateTime.UtcNow.AddHours(8),
                FlightStatus = FlightStatus.Scheduled,
                HasSeatAssigned = true,
                HasBaggageChecked = false,
                RequiresDocumentVerification = false,
                HasMobileBoardingPass = true,
                CheckinWindowHours = 24
            },
            
            "GHI789" when lastName.Equals("WILLIAMS", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "EMMA",
                IsCheckedIn = false,
                HasSpecialNeeds = true,
                IsFrequentFlyer = false,
                Type = PassengerType.Adult,
                FlightDepartureTime = DateTime.UtcNow.AddHours(6),
                FlightStatus = FlightStatus.Delayed,
                HasSeatAssigned = true,
                HasBaggageChecked = true,
                RequiresDocumentVerification = true,
                HasMobileBoardingPass = false,
                CheckinWindowHours = 24
            },
            
            "JKL012" when lastName.Equals("BROWN", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "MICHAEL",
                IsCheckedIn = false,
                HasSpecialNeeds = false,
                IsFrequentFlyer = false,
                Type = PassengerType.UnaccompaniedMinor,
                FlightDepartureTime = DateTime.UtcNow.AddHours(10),
                FlightStatus = FlightStatus.Scheduled,
                HasSeatAssigned = true,
                HasBaggageChecked = false,
                RequiresDocumentVerification = true,
                HasMobileBoardingPass = false,
                CheckinWindowHours = 24
            },
            
            "MNO345" when lastName.Equals("DAVIS", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "LISA",
                IsCheckedIn = false,
                HasSpecialNeeds = false,
                IsFrequentFlyer = true,
                Type = PassengerType.Adult,
                FlightDepartureTime = DateTime.UtcNow.AddHours(26), // Outside check-in window
                FlightStatus = FlightStatus.Scheduled,
                HasSeatAssigned = false,
                HasBaggageChecked = true,
                RequiresDocumentVerification = false,
                HasMobileBoardingPass = false,
                CheckinWindowHours = 24
            },
            
            "PQR678" when lastName.Equals("WILSON", StringComparison.OrdinalIgnoreCase) => new Passenger
            {
                Pnr = pnr,
                LastName = lastName.ToUpper(),
                FirstName = "ROBERT",
                IsCheckedIn = false,
                HasSpecialNeeds = false,
                IsFrequentFlyer = false,
                Type = PassengerType.Adult,
                FlightDepartureTime = DateTime.UtcNow.AddHours(4),
                FlightStatus = FlightStatus.Cancelled,
                HasSeatAssigned = true,
                HasBaggageChecked = false,
                RequiresDocumentVerification = false,
                HasMobileBoardingPass = false,
                CheckinWindowHours = 24
            },
            
            _ => null // Passenger not found
        };
    }
}
