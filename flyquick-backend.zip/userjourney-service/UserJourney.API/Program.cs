using Carter;
using FluentValidation;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Serilog;
using UserJourney.Application.Handlers;
using UserJourney.Application.Validators;
using UserJourney.Infrastructure.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog
builder.Host.UseSerilog((context, configuration) =>
    configuration.ReadFrom.Configuration(context.Configuration));

// Add services to the container
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() 
    { 
        Title = "UserJourney Service API", 
        Version = "v1",
        Description = "API for determining mobile user journey screens based on passenger information using NRules"
    });
});

// Add Carter for minimal APIs
builder.Services.AddCarter();

// Add MediatR
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetUserJourneyQueryHandler).Assembly));

// Add FluentValidation
builder.Services.AddValidatorsFromAssemblyContaining<GetUserJourneyQueryValidator>();

// Add memory caching
builder.Services.AddMemoryCache();

// Add Redis caching (optional)
if (!string.IsNullOrEmpty(builder.Configuration.GetConnectionString("Redis")))
{
    builder.Services.AddStackExchangeRedisCache(options =>
    {
        options.Configuration = builder.Configuration.GetConnectionString("Redis");
    });
}

// Add health checks
builder.Services.AddHealthChecks()
    .AddCheck("self", () => Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy())
    .AddProcessAllocatedMemoryHealthCheck(100_000_000) // 100MB limit
    .AddRedis(builder.Configuration.GetConnectionString("Redis") ?? "localhost:6379");

// Add Infrastructure services
builder.Services.AddInfrastructureServices(builder.Configuration);

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowMobileApps", policy =>
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader());
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "UserJourney Service API v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();

app.UseSerilogRequestLogging();

app.UseCors("AllowMobileApps");

// Add Carter endpoints
app.MapCarter();

// Add health check endpoints
app.MapHealthChecks("/health", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

app.MapHealthChecks("/health/ready", new HealthCheckOptions()
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

app.MapHealthChecks("/health/live", new HealthCheckOptions()
{
    Predicate = _ => false,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

// Add a simple root endpoint
app.MapGet("/", () => new
{
    Service = "UserJourney Service",
    Version = "1.0.0",
    Description = "Mobile user journey screens determination service using NRules",
    Documentation = "/swagger",
    Health = "/health"
}).ExcludeFromDescription();

try
{
    Log.Information("Starting UserJourney Service...");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "UserJourney Service terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}
