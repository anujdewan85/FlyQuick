using Checkin.Domain.Entities;
using Checkin.Domain.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace Checkin.Infrastructure.Services;

public class InMemoryCheckinRepository : ICheckinRepository
{
    private readonly ConcurrentDictionary<string, CheckinResult> _checkinResults = new();
    private readonly ILogger<InMemoryCheckinRepository> _logger;

    public InMemoryCheckinRepository(ILogger<InMemoryCheckinRepository> logger)
    {
        _logger = logger;
    }

    public Task<CheckinResult?> GetCheckinResultAsync(string pnr, CancellationToken cancellationToken = default)
    {
        _checkinResults.TryGetValue(pnr, out var result);
        _logger.LogDebug("Retrieved check-in result for PNR: {Pnr}, Found: {Found}", pnr, result != null);
        return Task.FromResult(result);
    }

    public Task<CheckinResult> SaveCheckinResultAsync(CheckinResult checkinResult, CancellationToken cancellationToken = default)
    {
        _checkinResults.AddOrUpdate(checkinResult.Pnr, checkinResult, (key, existing) => checkinResult);
        _logger.LogDebug("Saved check-in result for PNR: {Pnr}", checkinResult.Pnr);
        return Task.FromResult(checkinResult);
    }

    public Task<bool> DeleteCheckinResultAsync(string pnr, CancellationToken cancellationToken = default)
    {
        var removed = _checkinResults.TryRemove(pnr, out _);
        _logger.LogDebug("Deleted check-in result for PNR: {Pnr}, Success: {Success}", pnr, removed);
        return Task.FromResult(removed);
    }
}

public class BoardingPassService : IBoardingPassService
{
    private readonly ILogger<BoardingPassService> _logger;

    public BoardingPassService(ILogger<BoardingPassService> logger)
    {
        _logger = logger;
    }

    public async Task<BoardingPass> GenerateBoardingPassAsync(
        PassengerData passenger, 
        string seatNumber, 
        string gate, 
        CancellationToken cancellationToken = default)
    {
        await Task.Delay(50, cancellationToken); // Simulate processing

        var boardingPass = new BoardingPass(
            BoardingPassId: GenerateBoardingPassId(),
            Pnr: passenger.Pnr,
            PassengerName: $"{passenger.FirstName} {passenger.LastName}",
            FlightNumber: passenger.FlightNumber,
            DepartureTime: passenger.DepartureTime,
            SeatNumber: seatNumber,
            Gate: gate,
            BoardingTime: passenger.DepartureTime.AddMinutes(-30),
            QrCode: await GenerateQrCodeAsync(passenger.Pnr, cancellationToken)
        );

        _logger.LogInformation("Generated boarding pass {BoardingPassId} for PNR: {Pnr}", 
            boardingPass.BoardingPassId, passenger.Pnr);

        return boardingPass;
    }

    public async Task<string> GenerateQrCodeAsync(BoardingPass boardingPass, CancellationToken cancellationToken = default)
    {
        return await GenerateQrCodeAsync(boardingPass.Pnr, cancellationToken);
    }

    private static string GenerateBoardingPassId()
    {
        return $"BP{DateTime.UtcNow:yyyyMMddHHmmss}{Random.Shared.Next(1000, 9999)}";
    }

    private static Task<string> GenerateQrCodeAsync(string pnr, CancellationToken cancellationToken = default)
    {
        // Simulate QR code generation
        var qrData = $"{pnr}|{DateTime.UtcNow:yyyyMMddHHmmss}";
        return Task.FromResult(Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(qrData)));
    }
}
