using Checkin.Domain.Interfaces;
using Checkin.Infrastructure.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Extensions.Http;
using Refit;

namespace Checkin.Infrastructure.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Register repositories
        services.AddSingleton<ICheckinRepository, InMemoryCheckinRepository>();
        
        // Register cache service
        services.AddSingleton<ICacheService, RedisCacheService>();
        
        // Register HTTP clients with Refit
        services.AddRefitClient<IPassengerApiClient>()
            .ConfigureHttpClient(c => c.BaseAddress = new Uri(configuration["Services:PassengerService"] ?? "http://localhost:5002"))
            .AddPolicyHandler(GetRetryPolicy());

        services.AddRefitClient<IJourneyApiClient>()
            .ConfigureHttpClient(c => c.BaseAddress = new Uri(configuration["Services:JourneyService"] ?? "http://localhost:5003"))
            .AddPolicyHandler(GetRetryPolicy());
        
        // Register service implementations
        services.AddScoped<IPassengerService, PassengerServiceClient>();
        services.AddScoped<IJourneyService, JourneyServiceClient>();
        services.AddScoped<IBoardingPassService, BoardingPassService>();
        
        return services;
    }
    
    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(
                retryCount: 3,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    // Simple retry logging without context dependency
                    Console.WriteLine($"Retry {retryCount} after {timespan.TotalMilliseconds}ms");
                });
    }
}
