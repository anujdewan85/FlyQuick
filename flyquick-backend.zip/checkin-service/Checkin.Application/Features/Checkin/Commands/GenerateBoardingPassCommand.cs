using MediatR;
using Microsoft.Extensions.Logging;

namespace Checkin.Application.Features.Checkin.Commands;

public record GenerateBoardingPassCommand(string Pnr) : IRequest<BoardingPassResult>;

public class GenerateBoardingPassCommandHandler : IRequestHandler<GenerateBoardingPassCommand, BoardingPassResult>
{
    private readonly ILogger<GenerateBoardingPassCommandHandler> _logger;

    public GenerateBoardingPassCommandHandler(ILogger<GenerateBoardingPassCommandHandler> logger)
    {
        _logger = logger;
    }

    public async Task<BoardingPassResult> Handle(GenerateBoardingPassCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Generating boarding pass for PNR: {Pnr}", request.Pnr);

        // Simulate boarding pass generation
        await Task.Delay(50, cancellationToken);

        var boardingPass = new BoardingPassResult(
            Pnr: request.Pnr,
            BoardingPassId: GenerateBoardingPassId(),
            Gate: "A12",
            BoardingTime: DateTime.UtcNow.AddHours(1),
            SeatNumber: "12A",
            QrCode: GenerateQrCode()
        );

        _logger.LogInformation("Boarding pass generated for PNR: {Pnr}, ID: {BoardingPassId}", 
            request.Pnr, boardingPass.BoardingPassId);

        return boardingPass;
    }

    private static string GenerateBoardingPassId()
    {
        return $"BP{DateTime.UtcNow:yyyyMMddHHmmss}{Random.Shared.Next(1000, 9999)}";
    }

    private static string GenerateQrCode()
    {
        return Convert.ToBase64String(Guid.NewGuid().ToByteArray());
    }
}

public record BoardingPassResult(
    string Pnr,
    string BoardingPassId,
    string Gate,
    DateTime BoardingTime,
    string SeatNumber,
    string QrCode);
