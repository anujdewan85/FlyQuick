using Microsoft.Extensions.Diagnostics.HealthChecks;
using Polly;
using Polly.Extensions.Http;
using StackExchange.Redis;

namespace Checkin.API.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Health checks
        services.AddHealthChecks()
            .AddCheck("self", () => HealthCheckResult.Healthy())
            .AddRedis(configuration.GetConnectionString("Redis") ?? "localhost:6379")
            .AddUrlGroup(new Uri($"{configuration["Services:PassengerService"]}/health"), "passenger-service")
            .AddUrlGroup(new Uri($"{configuration["Services:JourneyService"]}/health"), "journey-service");

        // Distributed caching
        services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = configuration.GetConnectionString("Redis");
        });

        // Memory cache
        services.AddMemoryCache();

        // HTTP clients with Polly
        services.AddHttpClient("PassengerService", client =>
        {
            client.BaseAddress = new Uri(configuration["Services:PassengerService"] ?? "http://localhost:5002");
        }).AddPolicyHandler(GetRetryPolicy());

        services.AddHttpClient("JourneyService", client =>
        {
            client.BaseAddress = new Uri(configuration["Services:JourneyService"] ?? "http://localhost:5003");
        }).AddPolicyHandler(GetRetryPolicy());

        return services;
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(
                retryCount: 3,
                sleepDurationProvider: retryAttempt =>
                    TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }
}
