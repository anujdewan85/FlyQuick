using Carter;
using Checkin.API.Middleware;
using Checkin.Application.Features.Checkin.Commands;
using Checkin.Application.Features.Checkin.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Checkin.API.Endpoints;

public class CheckinEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/checkin")
            .WithTags("Checkin")
            .WithOpenApi();

        group.MapPost("/", CheckinPassenger)
            .WithName("CheckinPassenger")
            .WithSummary("Check-in passenger")
            .WithDescription("Initiate passenger check-in process using PNR and last name")
            .Produces<CheckinResponse>(200)
            .Produces<ErrorResponse>(400)
            .Produces<ErrorResponse>(404)
            .Produces<ErrorResponse>(500);

        group.MapGet("/status/{pnr}", GetCheckinStatus)
            .WithName("GetCheckinStatus")
            .WithSummary("Get check-in status")
            .WithDescription("Get current check-in status for a PNR")
            .Produces<CheckinStatusResponse>(200)
            .Produces<ErrorResponse>(404);

        group.MapPost("/boarding-pass/{pnr}", GenerateBoardingPass)
            .WithName("GenerateBoardingPass")
            .WithSummary("Generate boarding pass")
            .WithDescription("Generate boarding pass for checked-in passenger")
            .Produces<BoardingPassResponse>(200)
            .Produces<ErrorResponse>(400)
            .Produces<ErrorResponse>(404);
    }

    private static async Task<IResult> CheckinPassenger(
        [FromBody] CheckinRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = new CheckinPassengerCommand(request.Pnr, request.LastName, request.SeatPreference);
        var result = await mediator.Send(command, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> GetCheckinStatus(
        string pnr,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetCheckinStatusQuery(pnr);
        var result = await mediator.Send(query, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> GenerateBoardingPass(
        string pnr,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = new GenerateBoardingPassCommand(pnr);
        var result = await mediator.Send(command, cancellationToken);
        return Results.Ok(result);
    }
}

public record CheckinRequest(string Pnr, string LastName, string? SeatPreference);
public record CheckinResponse(string Pnr, string Status, DateTime CheckinTime, string? BoardingPass);
public record CheckinStatusResponse(string Pnr, string Status, DateTime? CheckinTime);
public record BoardingPassResponse(string Pnr, string BoardingPass, string Gate, DateTime BoardingTime);
