using System.Net;
using System.Text.Json;
using Checkin.Application.Exceptions;

namespace Checkin.API.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An unhandled exception has occurred: {ExceptionMessage}", ex.Message);
            await HandleExceptionAsync(context, ex);
        }
    }

    private static async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var response = context.Response;
        response.ContentType = "application/json";

        var errorResponse = exception switch
        {
            PnrNotFoundException ex => new ErrorResponse(
                "PNR_NOT_FOUND",
                ex.Message,
                HttpStatusCode.NotFound,
                new { ex.Pnr }),

            PassengerValidationException ex => new ErrorResponse(
                "PASSENGER_VALIDATION_FAILED",
                ex.Message,
                HttpStatusCode.BadRequest,
                new { ex.LastName }),

            NavitaireIntegrationException ex => new ErrorResponse(
                "EXTERNAL_SERVICE_ERROR",
                "An error occurred while communicating with external service",
                HttpStatusCode.BadGateway,
                new { Service = "Navitaire PSS" }),

            CheckinWorkflowException ex => new ErrorResponse(
                "WORKFLOW_ERROR",
                ex.Message,
                HttpStatusCode.InternalServerError,
                new { ex.WorkflowId }),

            ArgumentException ex => new ErrorResponse(
                "INVALID_ARGUMENT",
                ex.Message,
                HttpStatusCode.BadRequest),

            _ => new ErrorResponse(
                "INTERNAL_SERVER_ERROR",
                "An internal server error has occurred",
                HttpStatusCode.InternalServerError)
        };

        response.StatusCode = (int)errorResponse.StatusCode;
        var jsonResponse = JsonSerializer.Serialize(errorResponse);
        await response.WriteAsync(jsonResponse);
    }
}

public record ErrorResponse(
    string Code,
    string Message,
    HttpStatusCode StatusCode,
    object? Details = null);
