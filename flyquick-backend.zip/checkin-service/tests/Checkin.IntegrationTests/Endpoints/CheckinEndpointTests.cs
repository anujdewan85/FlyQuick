using Checkin.IntegrationTests.Infrastructure;
using FluentAssertions;
using System.Net;
using System.Text;
using System.Text.Json;

namespace Checkin.IntegrationTests.Endpoints;

public class CheckinEndpointTests : IClassFixture<CheckinWebApplicationFactory>
{
    private readonly CheckinWebApplicationFactory _factory;
    private readonly HttpClient _client;

    public CheckinEndpointTests(CheckinWebApplicationFactory factory)
    {
        _factory = factory;
        _client = _factory.CreateClient();
    }

    [Fact]
    public async Task CheckinPassenger_WithValidRequest_ReturnsOk()
    {
        // Arrange
        var request = new
        {
            Pnr = "ABC123",
            LastName = "Smith",
            SeatPreference = "12A"
        };

        var json = JsonSerializer.Serialize(request);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        // Act
        var response = await _client.PostAsync("/api/checkin", content);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var responseContent = await response.Content.ReadAsStringAsync();
        responseContent.Should().NotBeEmpty();

        var result = JsonSerializer.Deserialize<JsonElement>(responseContent);
        result.GetProperty("pnr").GetString().Should().Be("ABC123");
        result.GetProperty("status").GetString().Should().Be("CheckedIn");
    }

    [Fact]
    public async Task CheckinPassenger_WithInvalidPnr_ReturnsBadRequest()
    {
        // Arrange
        var request = new
        {
            Pnr = "ABC", // Invalid PNR (too short)
            LastName = "Smith"
        };

        var json = JsonSerializer.Serialize(request);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        // Act
        var response = await _client.PostAsync("/api/checkin", content);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task GetCheckinStatus_WithValidPnr_ReturnsOk()
    {
        // Arrange
        var pnr = "ABC123";

        // Act
        var response = await _client.GetAsync($"/api/checkin/status/{pnr}");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var responseContent = await response.Content.ReadAsStringAsync();
        responseContent.Should().NotBeEmpty();

        var result = JsonSerializer.Deserialize<JsonElement>(responseContent);
        result.GetProperty("pnr").GetString().Should().Be(pnr);
    }

    [Fact]
    public async Task GenerateBoardingPass_WithValidPnr_ReturnsOk()
    {
        // Arrange
        var pnr = "ABC123";

        // Act
        var response = await _client.PostAsync($"/api/checkin/boarding-pass/{pnr}", null);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var responseContent = await response.Content.ReadAsStringAsync();
        responseContent.Should().NotBeEmpty();

        var result = JsonSerializer.Deserialize<JsonElement>(responseContent);
        result.GetProperty("pnr").GetString().Should().Be(pnr);
        result.GetProperty("boardingPass").GetString().Should().NotBeNullOrEmpty();
    }

    [Fact]
    public async Task HealthCheck_ReturnsHealthy()
    {
        // Act
        var response = await _client.GetAsync("/health");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var content = await response.Content.ReadAsStringAsync();
        content.Should().Be("Healthy");
    }
}
