using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Testcontainers.Redis;
using WireMock.Server;

namespace Checkin.IntegrationTests.Infrastructure;

public class CheckinWebApplicationFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly RedisContainer _redisContainer = new RedisBuilder()
        .WithImage("redis:7-alpine")
        .Build();

    private WireMockServer? _passengerServiceMock;
    private WireMockServer? _journeyServiceMock;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Configure test-specific services
        });

        builder.UseEnvironment("Testing");
        
        // Configure test appsettings
        builder.ConfigureAppConfiguration((context, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:Redis"] = _redisContainer.GetConnectionString(),
                ["Services:PassengerService"] = _passengerServiceMock?.Url ?? "http://localhost:5002",
                ["Services:JourneyService"] = _journeyServiceMock?.Url ?? "http://localhost:5003",
                ["Serilog:MinimumLevel:Default"] = "Warning"
            });
        });
    }

    public async Task InitializeAsync()
    {
        // Start containers
        await _redisContainer.StartAsync();

        // Start WireMock servers
        _passengerServiceMock = WireMockServer.Start();
        _journeyServiceMock = WireMockServer.Start();

        // Setup default mock responses
        SetupDefaultMockResponses();
    }

    public new async Task DisposeAsync()
    {
        await _redisContainer.DisposeAsync();
        _passengerServiceMock?.Stop();
        _journeyServiceMock?.Stop();
        await base.DisposeAsync();
    }

    private void SetupDefaultMockResponses()
    {
        // Setup Passenger Service mock responses
        _passengerServiceMock?.Given(WireMock.RequestBuilders.Request.Create()
            .WithPath("/api/passengers/pnr/*")
            .UsingGet())
            .RespondWith(WireMock.ResponseBuilders.Response.Create()
                .WithStatusCode(200)
                .WithBodyAsJson(new
                {
                    Pnr = "ABC123",
                    LastName = "Smith",
                    FirstName = "John",
                    FlightNumber = "6E123",
                    DepartureTime = DateTime.UtcNow.AddHours(2),
                    Origin = "BOM",
                    Destination = "DEL",
                    Status = "Eligible"
                }));

        // Setup Journey Service mock responses
        _journeyServiceMock?.Given(WireMock.RequestBuilders.Request.Create()
            .WithPath("/api/flights/*")
            .UsingGet())
            .RespondWith(WireMock.ResponseBuilders.Response.Create()
                .WithStatusCode(200)
                .WithBodyAsJson(new
                {
                    FlightNumber = "6E123",
                    DepartureTime = DateTime.UtcNow.AddHours(2),
                    Origin = "BOM",
                    Destination = "DEL",
                    Aircraft = "A320",
                    Gate = "A12"
                }));
    }
}
