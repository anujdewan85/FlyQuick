using AutoFixture;
using AutoFixture.Xunit2;
using Checkin.Application.Features.Checkin.Commands;
using Checkin.Domain.Entities;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;

namespace Checkin.UnitTests.Features.Checkin.Commands;

public class CheckinPassengerCommandHandlerTests
{
    private readonly IFixture _fixture;
    private readonly Mock<ILogger<CheckinPassengerCommandHandler>> _loggerMock;
    private readonly CheckinPassengerCommandHandler _handler;

    public CheckinPassengerCommandHandlerTests()
    {
        _fixture = new Fixture();
        _loggerMock = new Mock<ILogger<CheckinPassengerCommandHandler>>();
        _handler = new CheckinPassengerCommandHandler(_loggerMock.Object);
    }

    [Theory, AutoData]
    public async Task Handle_ValidCommand_ReturnsCheckinResult(
        string pnr, 
        string lastName, 
        string seatPreference)
    {
        // Arrange
        var command = new CheckinPassengerCommand(pnr, lastName, seatPreference);
        var cancellationToken = CancellationToken.None;

        // Act
        var result = await _handler.Handle(command, cancellationToken);

        // Assert
        result.Should().NotBeNull();
        result.Pnr.Should().Be(pnr);
        result.Status.Should().Be(CheckinStatus.CheckedIn);
        result.CheckinTime.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromMinutes(1));
        result.SeatNumber.Should().Be(seatPreference);
        result.BoardingPass.Should().NotBeNullOrEmpty();
        result.BoardingPass.Should().StartWith("BP");
    }

    [Theory, AutoData]
    public async Task Handle_NoSeatPreference_AssignsDefaultSeat(
        string pnr,
        string lastName)
    {
        // Arrange
        var command = new CheckinPassengerCommand(pnr, lastName, null);
        var cancellationToken = CancellationToken.None;

        // Act
        var result = await _handler.Handle(command, cancellationToken);

        // Assert
        result.Should().NotBeNull();
        result.SeatNumber.Should().Be("12A"); // Default seat
    }

    [Fact]
    public async Task Handle_ValidCommand_LogsInformation()
    {
        // Arrange
        var command = _fixture.Create<CheckinPassengerCommand>();
        var cancellationToken = CancellationToken.None;

        // Act
        await _handler.Handle(command, cancellationToken);

        // Assert
        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Starting check-in process")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);

        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains("Check-in completed")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
}
