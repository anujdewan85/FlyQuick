using Checkin.Application.Features.Checkin.Commands;
using FluentAssertions;
using FluentValidation.TestHelper;

namespace Checkin.UnitTests.Features.Checkin.Commands;

public class CheckinPassengerCommandValidatorTests
{
    private readonly CheckinPassengerCommandValidator _validator;

    public CheckinPassengerCommandValidatorTests()
    {
        _validator = new CheckinPassengerCommandValidator();
    }

    [Fact]
    public void Should_Have_Error_When_Pnr_Is_Empty()
    {
        // Arrange
        var command = new CheckinPassengerCommand("", "Smith");

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.Pnr);
    }

    [Fact]
    public void Should_Have_Error_When_Pnr_Is_Not_Six_Characters()
    {
        // Arrange
        var command = new CheckinPassengerCommand("ABC12", "Smith");

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.Pnr);
    }

    [Fact]
    public void Should_Have_Error_When_Pnr_Contains_Invalid_Characters()
    {
        // Arrange
        var command = new CheckinPassengerCommand("ABC12!", "Smith");

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.Pnr);
    }

    [Fact]
    public void Should_Have_Error_When_LastName_Is_Empty()
    {
        // Arrange
        var command = new CheckinPassengerCommand("ABC123", "");

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.LastName);
    }

    [Fact]
    public void Should_Have_Error_When_LastName_Exceeds_MaxLength()
    {
        // Arrange
        var longLastName = new string('A', 51);
        var command = new CheckinPassengerCommand("ABC123", longLastName);

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.LastName);
    }

    [Fact]
    public void Should_Have_Error_When_SeatPreference_Is_Invalid_Format()
    {
        // Arrange
        var command = new CheckinPassengerCommand("ABC123", "Smith", "InvalidSeat");

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldHaveValidationErrorFor(x => x.SeatPreference);
    }

    [Theory]
    [InlineData("ABC123", "Smith", "12A")]
    [InlineData("XYZ789", "Johnson", "1F")]
    [InlineData("DEF456", "Brown", null)]
    public void Should_Not_Have_Error_When_Command_Is_Valid(string pnr, string lastName, string? seatPreference)
    {
        // Arrange
        var command = new CheckinPassengerCommand(pnr, lastName, seatPreference);

        // Act & Assert
        var result = _validator.TestValidate(command);
        result.ShouldNotHaveAnyValidationErrors();
    }
}
