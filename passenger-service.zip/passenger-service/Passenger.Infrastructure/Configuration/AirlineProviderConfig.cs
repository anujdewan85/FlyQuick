using System.ComponentModel.DataAnnotations;

namespace Passenger.Infrastructure.Configuration;

/// <summary>
/// Configuration options for all airline system providers
/// Implements Options Pattern with validation
/// </summary>
public class AirlineSystemOptions : IValidatableObject
{
    public const string SectionName = "AirlineSystemProviders";

    [Required(ErrorMessage = "Default provider must be specified")]
    public string Default { get; set; } = string.Empty;

    [Required(ErrorMessage = "At least one provider must be configured")]
    public Dictionary<string, AirlineProviderConfig> Providers { get; set; } = new();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        var results = new List<ValidationResult>();

        // Validate that default provider exists in providers dictionary
        if (!string.IsNullOrEmpty(Default) && !Providers.ContainsKey(Default))
        {
            results.Add(new ValidationResult(
                $"Default provider '{Default}' is not configured in the Providers section",
                new[] { nameof(Default) }));
        }

        // Validate each provider configuration
        foreach (var kvp in Providers)
        {
            var providerName = kvp.Key;
            var providerConfig = kvp.Value;

            if (string.IsNullOrEmpty(providerConfig.BaseUrl))
            {
                results.Add(new ValidationResult(
                    $"BaseUrl is required for provider '{providerName}'",
                    new[] { $"{nameof(Providers)}[{providerName}].{nameof(AirlineProviderConfig.BaseUrl)}" }));
            }
            else if (!Uri.TryCreate(providerConfig.BaseUrl, UriKind.Absolute, out _))
            {
                results.Add(new ValidationResult(
                    $"BaseUrl for provider '{providerName}' must be a valid absolute URL",
                    new[] { $"{nameof(Providers)}[{providerName}].{nameof(AirlineProviderConfig.BaseUrl)}" }));
            }

            // Validate required endpoints exist
            var requiredEndpoints = new[] { "GetPassenger", "GetPassengers", "CreatePassenger" };
            foreach (var endpoint in requiredEndpoints)
            {
                if (!providerConfig.Endpoints.ContainsKey(endpoint))
                {
                    results.Add(new ValidationResult(
                        $"Required endpoint '{endpoint}' is missing for provider '{providerName}'",
                        new[] { $"{nameof(Providers)}[{providerName}].{nameof(AirlineProviderConfig.Endpoints)}" }));
                }
            }
        }

        return results;
    }

    /// <summary>
    /// Gets the configuration for the default provider
    /// </summary>
    public AirlineProviderConfig GetDefaultProvider()
    {
        if (!Providers.TryGetValue(Default, out var provider))
        {
            throw new InvalidOperationException($"Default provider '{Default}' not found in configuration");
        }
        return provider;
    }

    /// <summary>
    /// Validates production-specific requirements
    /// </summary>
    public void ValidateForProduction()
    {
        var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        if (environment?.Equals("Production", StringComparison.OrdinalIgnoreCase) != true)
            return;

        foreach (var kvp in Providers)
        {
            var providerName = kvp.Key;
            var config = kvp.Value;

            // Production should not use localhost or dev URLs
            if (config.BaseUrl.Contains("localhost", StringComparison.OrdinalIgnoreCase) ||
                config.BaseUrl.Contains("dev", StringComparison.OrdinalIgnoreCase) ||
                config.BaseUrl.Contains("test", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    $"Production environment cannot use development/test URLs. Provider '{providerName}' has URL: {config.BaseUrl}");
            }

            // Production should have proper API keys (not test/demo keys)
            if (config.ApiKey.Contains("test", StringComparison.OrdinalIgnoreCase) ||
                config.ApiKey.Contains("demo", StringComparison.OrdinalIgnoreCase) ||
                config.ApiKey.Contains("sample", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    $"Production environment cannot use test/demo API keys. Provider '{providerName}' has invalid key.");
            }
        }
    }
}

/// <summary>
/// Configuration model for individual airline system providers
/// </summary>
public class AirlineProviderConfig
{
    [Required(ErrorMessage = "Provider name is required")]
    public string ProviderName { get; set; } = string.Empty;

    [Required(ErrorMessage = "BaseUrl is required")]
    [Url(ErrorMessage = "BaseUrl must be a valid URL")]
    public string BaseUrl { get; set; } = string.Empty;

    [Required(ErrorMessage = "ApiKey is required")]
    public string ApiKey { get; set; } = string.Empty;

    [Required(ErrorMessage = "AuthType is required")]
    public string AuthType { get; set; } = string.Empty;

    [Required(ErrorMessage = "At least one endpoint must be configured")]
    public Dictionary<string, string> Endpoints { get; set; } = new();

    public Dictionary<string, string> Headers { get; set; } = new();

    [Range(5, 300, ErrorMessage = "TimeoutSeconds must be between 5 and 300")]
    public int TimeoutSeconds { get; set; } = 30;

    [Range(0, 10, ErrorMessage = "RetryCount must be between 0 and 10")]
    public int RetryCount { get; set; } = 3;
}

/// <summary>
/// Enum for supported airline system providers
/// </summary>
public enum AirlineSystemProvider
{
    Navitaire,
    Amadeus,
    Sabre,
    Travelport
}
