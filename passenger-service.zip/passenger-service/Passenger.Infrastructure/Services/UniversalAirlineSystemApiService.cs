using Passenger.Application.Abstractions;
using Passenger.Application.DTOs;
using Passenger.Infrastructure.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text;
using System.Text.Json;

namespace Passenger.Infrastructure.Services;

/// <summary>
/// Universal airline system API service that works with any configured provider
/// Replaces multiple provider-specific services with configuration-driven approach
/// </summary>
public class UniversalAirlineSystemApiService : IAirlineSystemApiService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<UniversalAirlineSystemApiService> _logger;
    private readonly AirlineProviderConfig _config;
    private readonly JsonSerializerOptions _jsonOptions;

    public UniversalAirlineSystemApiService(
        HttpClient httpClient,
        IOptions<AirlineSystemOptions> options,
        ILogger<UniversalAirlineSystemApiService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
        
        // Get airline system options with validation
        var airlineOptions = options.Value;
        
        // Perform additional production validation
        airlineOptions.ValidateForProduction();
        
        // Get the default provider configuration
        _config = airlineOptions.GetDefaultProvider();
        _config.ProviderName = airlineOptions.Default;

        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true
        };

        ConfigureHttpClient();
        
        _logger.LogInformation("Configured Universal Airline API Service for provider: {Provider} at {BaseUrl}", 
            _config.ProviderName, _config.BaseUrl);
    }

    private void ConfigureHttpClient()
    {
        _httpClient.BaseAddress = new Uri(_config.BaseUrl);
        _httpClient.Timeout = TimeSpan.FromSeconds(_config.TimeoutSeconds);
        
        // Configure headers from configuration
        foreach (var header in _config.Headers)
        {
            var headerValue = header.Value.Replace("{ApiKey}", _config.ApiKey);
            
            // Handle Authorization header specially
            if (header.Key.Equals("Authorization", StringComparison.OrdinalIgnoreCase))
            {
                _httpClient.DefaultRequestHeaders.Authorization = 
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _config.ApiKey);
            }
            else if (header.Key.Equals("X-API-Key", StringComparison.OrdinalIgnoreCase))
            {
                _httpClient.DefaultRequestHeaders.Add("X-API-Key", _config.ApiKey);
            }
            else
            {
                _httpClient.DefaultRequestHeaders.Add(header.Key, headerValue);
            }
        }

        _logger.LogInformation("Configured HTTP client for {Provider} at {BaseUrl}", 
            _config.ProviderName, _config.BaseUrl);
    }

    public async Task<PassengerDto?> GetPassengerAsync(string passengerId, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("GetPassenger", out var endpointTemplate))
        {
            throw new InvalidOperationException($"GetPassenger endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{passengerId}", passengerId);
        
        return await ExecuteGetRequestAsync<PassengerDto>(
            endpoint, 
            $"passenger {passengerId}", 
            cancellationToken);
    }

    public async Task<IEnumerable<PassengerDto>> GetPassengersAsync(CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("GetPassengers", out var endpoint))
        {
            throw new InvalidOperationException($"GetPassengers endpoint not configured for provider {_config.ProviderName}");
        }
        
        var result = await ExecuteGetRequestAsync<IEnumerable<PassengerDto>>(
            endpoint, 
            "all passengers", 
            cancellationToken);
            
        return result ?? Enumerable.Empty<PassengerDto>();
    }

    public async Task<PassengerDto> CreatePassengerAsync(CreatePassengerRequest request, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("CreatePassenger", out var endpoint))
        {
            throw new InvalidOperationException($"CreatePassenger endpoint not configured for provider {_config.ProviderName}");
        }
        
        return await ExecutePostRequestAsync<CreatePassengerRequest, PassengerDto>(
            endpoint, 
            request, 
            $"passenger {request.Email}", 
            cancellationToken);
    }

    public async Task<FlightReservationDto?> GetFlightReservationAsync(string reservationId, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("GetReservation", out var endpointTemplate))
        {
            throw new InvalidOperationException($"GetReservation endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{reservationId}", reservationId);
        
        return await ExecuteGetRequestAsync<FlightReservationDto>(
            endpoint, 
            $"reservation {reservationId}", 
            cancellationToken);
    }

    public async Task<FlightReservationDto?> GetFlightReservationByPnrAsync(string pnr, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("GetReservationByPnr", out var endpointTemplate))
        {
            throw new InvalidOperationException($"GetReservationByPnr endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{pnr}", pnr);
        
        return await ExecuteGetRequestAsync<FlightReservationDto>(
            endpoint, 
            $"reservation PNR {pnr}", 
            cancellationToken);
    }

    public async Task<FlightReservationDto> UpdateFlightReservationAsync(string reservationId, UpdateFlightReservationRequest request, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("UpdateReservation", out var endpointTemplate))
        {
            throw new InvalidOperationException($"UpdateReservation endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{reservationId}", reservationId);
        
        return await ExecutePutRequestAsync<UpdateFlightReservationRequest, FlightReservationDto>(
            endpoint, 
            request, 
            $"reservation {reservationId}", 
            cancellationToken);
    }

    public async Task<FlightReservationDto> CreateFlightReservationAsync(CreateFlightReservationRequest request, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("CreateReservation", out var endpoint))
        {
            throw new InvalidOperationException($"CreateReservation endpoint not configured for provider {_config.ProviderName}");
        }
        
        return await ExecutePostRequestAsync<CreateFlightReservationRequest, FlightReservationDto>(
            endpoint, 
            request, 
            $"reservation for flight {request.FlightNumber}", 
            cancellationToken);
    }

    public async Task<CheckInStatusDto?> GetCheckInStatusAsync(string passengerId, string flightNumber, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("GetCheckInStatus", out var endpointTemplate))
        {
            throw new InvalidOperationException($"GetCheckInStatus endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{passengerId}", passengerId)
                                      .Replace("{flightNumber}", flightNumber);
        
        return await ExecuteGetRequestAsync<CheckInStatusDto>(
            endpoint, 
            $"check-in status for passenger {passengerId} on flight {flightNumber}", 
            cancellationToken);
    }

    public async Task<CheckInResultDto> CheckInPassengerAsync(CheckInPassengerRequest request, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("CheckInPassenger", out var endpoint))
        {
            throw new InvalidOperationException($"CheckInPassenger endpoint not configured for provider {_config.ProviderName}");
        }
        
        return await ExecutePostRequestAsync<CheckInPassengerRequest, CheckInResultDto>(
            endpoint, 
            request, 
            $"check-in for passenger {request.PassengerId} on flight {request.FlightNumber}", 
            cancellationToken);
    }

    public async Task<PassengerDto> UpdatePassengerAsync(string passengerId, UpdatePassengerRequest request, CancellationToken cancellationToken = default)
    {
        if (!_config.Endpoints.TryGetValue("UpdatePassenger", out var endpointTemplate))
        {
            throw new InvalidOperationException($"UpdatePassenger endpoint not configured for provider {_config.ProviderName}");
        }

        var endpoint = endpointTemplate.Replace("{passengerId}", passengerId);
        
        return await ExecutePutRequestAsync<UpdatePassengerRequest, PassengerDto>(
            endpoint, 
            request, 
            $"passenger {passengerId}", 
            cancellationToken);
    }

    // Generic HTTP operation methods (DRY principle)
    private async Task<T?> ExecuteGetRequestAsync<T>(string endpoint, string resourceDescription, CancellationToken cancellationToken) where T : class
    {
        try
        {
            _logger.LogInformation("Fetching {Resource} from {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            
            var response = await _httpClient.GetAsync(endpoint, cancellationToken);
            
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogWarning("{Resource} not found in {Provider} API", resourceDescription, _config.ProviderName);
                return null;
            }
            
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<T>(content, _jsonOptions);
            
            _logger.LogDebug("Successfully fetched {Resource} from {Provider} API", resourceDescription, _config.ProviderName);
            return result;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error fetching {Resource} from {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogError(ex, "Timeout fetching {Resource} from {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error fetching {Resource} from {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
    }

    private async Task<TResponse> ExecutePostRequestAsync<TRequest, TResponse>(
        string endpoint, 
        TRequest request, 
        string resourceDescription, 
        CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Creating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(endpoint, content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<TResponse>(responseContent, _jsonOptions);
            
            _logger.LogDebug("Successfully created {Resource} in {Provider} API", resourceDescription, _config.ProviderName);
            return result!;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error creating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogError(ex, "Timeout creating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error creating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
    }

    private async Task<TResponse> ExecutePutRequestAsync<TRequest, TResponse>(
        string endpoint, 
        TRequest request, 
        string resourceDescription, 
        CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Updating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PutAsync(endpoint, content, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<TResponse>(responseContent, _jsonOptions);
            
            _logger.LogDebug("Successfully updated {Resource} in {Provider} API", resourceDescription, _config.ProviderName);
            return result!;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error updating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogError(ex, "Timeout updating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error updating {Resource} in {Provider} API: {Endpoint}", 
                resourceDescription, _config.ProviderName, endpoint);
            throw;
        }
    }
}
