using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.ComponentModel.DataAnnotations;
using Passenger.Application.Abstractions;
using Passenger.Infrastructure.Services;
using Passenger.Infrastructure.Configuration;

namespace Passenger.Infrastructure.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // NOTE: Database and repositories are available but not used in CQRS handlers
        // Uncomment below if you want to use them for caching, audit logging, etc.
        /*
        // Add Entity Framework (optional - for caching, audit logging, or backup)
        services.AddDbContext<PassengerDbContext>(options =>
            options.UseSqlite(configuration.GetConnectionString("DefaultConnection")));

        // Add repositories (optional - can be used alongside external APIs)
        services.AddScoped<IPassengerRepository, PassengerRepository>();
        services.AddScoped<IFlightReservationRepository, FlightReservationRepository>();
        */

        // Configure Options Pattern for airline system providers
        services.AddOptions<AirlineSystemOptions>()
            .Bind(configuration.GetSection(AirlineSystemOptions.SectionName))
            .Validate(options => 
            {
                // Custom validation using IValidatableObject
                var validationContext = new ValidationContext(options);
                var validationResults = options.Validate(validationContext).ToList();
                
                if (validationResults.Any())
                {
                    var errors = string.Join("; ", validationResults.Select(r => r.ErrorMessage));
                    throw new InvalidOperationException($"AirlineSystemOptions validation failed: {errors}");
                }
                
                // Additional production validation
                try
                {
                    options.ValidateForProduction();
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException($"Production validation failed: {ex.Message}");
                }
                
                return true;
            })
            .ValidateOnStart(); // Fail fast at application startup

        // Configure HTTP client for the default provider
        services.AddHttpClient<UniversalAirlineSystemApiService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<AirlineSystemOptions>>();
            var defaultProvider = options.Value.GetDefaultProvider();
            
            client.BaseAddress = new Uri(defaultProvider.BaseUrl);
            client.Timeout = TimeSpan.FromSeconds(defaultProvider.TimeoutSeconds);
        });

        // Register the universal service as Singleton (configuration-based, stateless service)
        services.AddSingleton<IAirlineSystemApiService, UniversalAirlineSystemApiService>();
        /*
        Characteristics of the Service:
            Stateless: No instance state that changes between requests
            Configuration-driven: Uses IOptions<AirlineSystemOptions> which is essentially static
            HTTP client: Already managed by HttpClientFactory
            Read-only operations: Only reads configuration and makes HTTP calls
        Benefits of Singleton:
            Performance: No object creation overhead per request
            Memory efficiency: Single instance shared across all requests
            Configuration stability: Airline provider configurations rarely change
            Thread-safe: Service operations are inherently thread-safe
            Cost-effective: Reduces GC pressure             
        */
        return services;
    }
}
