# Architectural Refactoring: Models Migration to Domain Layer

## Overview

This document explains the architectural refactoring performed to move domain models from the Application layer to the proper Domain layer, ensuring correct Clean Architecture boundaries.

## Problem Identified

The user correctly identified that models were incorrectly placed in `Passenger.Application.Models` when they should be in `Passenger.Domain` according to Clean Architecture principles.

## ❌ **Before Refactoring (Incorrect Architecture)**

```
Passenger.Application/
├── Models/                    ❌ WRONG LAYER
│   ├── ValidationResult.cs   ❌ Domain concept in Application layer
│   └── CheckInContext.cs     ❌ Domain concept in Application layer
└── Services/
    └── CheckInDomainService.cs (depended on Application.Models)

Passenger.Domain/
├── Entities/                  ✅ Correct
├── ValueObjects/              ✅ Correct
└── Events/                    ✅ Correct
```

### Issues with Previous Architecture:
1. **Domain concepts in Application layer** - Violates Clean Architecture
2. **Mixed dependencies** - CheckInContext used Application DTOs instead of Domain entities
3. **Layer confusion** - Domain services depending on Application models
4. **Poor testability** - Domain logic mixed with application concerns

## ✅ **After Refactoring (Correct Architecture)**

```
Passenger.Domain/
├── Entities/                  ✅ Domain entities
├── ValueObjects/              ✅ Domain value objects
│   ├── ValidationResult.cs   ✅ MOVED HERE
│   ├── CheckInContext.cs     ✅ MOVED HERE (refactored)
│   └── CheckInStatus.cs      ✅ Existing
└── Events/                    ✅ Domain events

Passenger.Application/
├── Services/                  ✅ Application services
│   └── CheckInDomainService.cs (now uses Domain.ValueObjects)
├── Features/                  ✅ CQRS handlers
└── DTOs/                      ✅ External API DTOs
```

## 🔧 **Key Changes Made**

### 1. **ValidationResult Migration**
- **From:** `Passenger.Application.Models.ValidationResult`
- **To:** `Passenger.Domain.ValueObjects.ValidationResult`
- **Improvements:**
  - Pure domain concept (no external dependencies)
  - Enhanced with result combination methods
  - Proper value object semantics

### 2. **CheckInContext Refactoring**
- **From:** `Passenger.Application.Models.CheckInContext`
- **To:** `Passenger.Domain.ValueObjects.CheckInContext`
- **Key Changes:**
  - **Before:** Used Application DTOs (`PassengerDto`, `FlightReservationDto`)
  - **After:** Uses Domain entities (`Passenger`, `PassengerFlightReservation`)
  - **Added:** Rich computed properties for business logic
  - **Added:** Factory methods for clean object creation
  - **Added:** Immutable record with `with` expressions

### 3. **CheckInDomainService Updates**
- **Dependencies:** Now properly uses repositories instead of mixing API services with domain data
- **Constructor:** Added `IPassengerRepository` and `IFlightReservationRepository`
- **Data Loading:** Uses repository pattern for domain entities
- **External APIs:** Still uses `IAirlineSystemApiService` for airline-specific data
- **Method Signatures:** Updated to use `ValidationResult.Failure()` instead of `Failed()`

### 4. **CQRS Handler Updates**
- Updated namespace imports to use `Passenger.Domain.ValueObjects`
- Fixed `CheckInContext.Create()` calls to match new signature
- Maintained clean separation between domain logic and application orchestration

## 🏗️ **Improved Architecture Benefits**

### **Clean Architecture Compliance**
```
┌─────────────────────────────────────────┐
│              Passenger.API              │  ← Presentation
│  • Carter Endpoints                    │
│  • DTOs for external communication     │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│           Passenger.Application         │  ← Application
│  • CQRS Handlers (orchestration)       │
│  • Domain Services (business logic)    │
│  • External API DTOs                   │
│  • Repository interfaces               │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│            Passenger.Domain             │  ← Domain
│  • Entities (Passenger, Reservation)   │
│  • Value Objects (ValidationResult)    │  ✅ NOW CORRECT
│  • Domain Events                       │
│  • Business Rules                      │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│          Passenger.Infrastructure       │  ← Infrastructure
│  • Entity Framework Core               │
│  • Repository implementations          │
│  • External service implementations    │
└─────────────────────────────────────────┘
```

### **Domain Purity**
- ✅ Domain layer has no dependencies on Application or Infrastructure
- ✅ Domain models use only other domain concepts
- ✅ Business rules encapsulated in domain objects
- ✅ Rich domain model with computed properties

### **Repository Pattern Alignment**
- ✅ Domain services use repositories for domain data
- ✅ Clear separation between domain persistence and external APIs
- ✅ Proper dependency injection with interfaces
- ✅ Testable with mock repositories

### **Improved Testability**
```csharp
// Before: Mixed concerns, harder to test
CheckInContext context = new(dtoData...);

// After: Pure domain model, easy to test
var context = CheckInContext.Create(passengerId, pnr, flightNumber, date, time)
    .WithPassenger(passenger)
    .WithReservation(reservation);

Assert.True(context.IsCheckInWindowOpen);
Assert.True(context.HasValidPassenger);
```

## 📋 **Files Modified**

### **Created**
- `Passenger.Domain/ValueObjects/ValidationResult.cs`
- `Passenger.Domain/ValueObjects/CheckInContext.cs`

### **Updated**
- `Passenger.Application/Services/CheckInDomainService.cs`
- `Passenger.Application/Features/CheckInOperations/Commands/CheckInPassengerApiCommand.cs`
- `Passenger.Application.Tests/Services/CheckInDomainServiceTests.cs`

### **Removed**
- `Passenger.Application/Models/ValidationResult.cs`
- `Passenger.Application/Models/CheckInContext.cs`
- `Passenger.Application/Models/` (empty folder)

## 🚀 **Impact and Benefits**

### **For Developers**
- **Clearer boundaries** - Know exactly where domain logic belongs
- **Better IntelliSense** - Domain concepts grouped logically
- **Easier navigation** - Related concepts in the same layer
- **Consistent patterns** - All value objects in one place

### **For Architecture**
- **Clean Architecture compliance** - Proper dependency flow
- **Domain-driven design** - Rich domain model
- **Separation of concerns** - Each layer has clear responsibility
- **Maintainability** - Easier to evolve business rules

### **For Testing**
- **Unit testable domain** - No external dependencies
- **Mock-friendly services** - Repository interfaces
- **Behavior verification** - Rich domain model methods
- **Isolated testing** - Pure domain logic tests

## 📚 **Lessons Learned**

### **Architectural Principles**
1. **Domain concepts belong in Domain layer** - Even if they're "simple" models
2. **Value objects are powerful** - Rich behavior, immutability, computed properties
3. **Repository pattern separation** - Domain data vs external API data
4. **Dependency direction matters** - Always toward the domain core

### **Clean Architecture Rules**
1. **Inner layers know nothing of outer layers**
2. **Domain layer is dependency-free**
3. **Application layer orchestrates, doesn't contain business logic**
4. **Infrastructure implements interfaces defined in Application**

### **Design Patterns Applied**
- **Value Object Pattern** - `ValidationResult`, `CheckInContext`
- **Repository Pattern** - Data access abstraction
- **Domain Services Pattern** - Complex business logic coordination
- **Factory Pattern** - `CheckInContext.Create()` methods

## 🎯 **Next Steps for Similar Refactoring**

When identifying similar architectural issues:

1. **Audit layer boundaries** - Check what's in each layer
2. **Identify misplaced concepts** - Domain models in wrong layers
3. **Check dependencies** - Ensure proper dependency flow
4. **Refactor systematically** - Move models, update references, test
5. **Document changes** - Explain architectural decisions

This refactoring demonstrates the importance of **continuous architectural review** and **adherence to Clean Architecture principles** for maintainable, testable, and scalable microservices.
