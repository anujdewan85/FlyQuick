using Passenger.Domain.Common;
using Passenger.Domain.ValueObjects;

namespace Passenger.Domain.Events;

public class PassengerCheckedInEvent : IDomainEvent
{
    public string EventId { get; }
    public DateTime OccurredOn { get; }
    public string PassengerId { get; }
    public string FlightNumber { get; }
    public string Pnr { get; }
    public DateTime CheckInTime { get; }
    public CheckInStatus PreviousStatus { get; }
    public CheckInStatus NewStatus { get; }

    public PassengerCheckedInEvent(
        string passengerId, 
        string flightNumber, 
        string pnr,
        DateTime checkInTime,
        CheckInStatus previousStatus,
        CheckInStatus newStatus)
    {
        EventId = Guid.NewGuid().ToString();
        OccurredOn = DateTime.UtcNow;
        PassengerId = passengerId;
        FlightNumber = flightNumber;
        Pnr = pnr;
        CheckInTime = checkInTime;
        PreviousStatus = previousStatus;
        NewStatus = newStatus;
    }
}
