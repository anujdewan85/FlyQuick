using Passenger.Domain.ValueObjects;
using Passenger.Domain.Common;
using Passenger.Domain.Events;

namespace Passenger.Domain.Entities;

/// <summary>
/// Represents a passenger's reservation on a specific flight
/// </summary>
public class PassengerFlightReservation : AggregateRoot
{
    public string Id { get; private set; } = string.Empty;
    public string Pnr { get; private set; } = string.Empty;
    public string PassengerId { get; private set; } = string.Empty;
    public string FlightNumber { get; private set; } = string.Empty;
    public DateTime DepartureTime { get; private set; }
    public string Origin { get; private set; } = string.Empty;
    public string Destination { get; private set; } = string.Empty;
    public CheckInStatus Status { get; private set; }
    public string SeatNumber { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }
    public DateTime? CheckInTime { get; private set; }

    // Navigation property
    public Passenger? Passenger { get; private set; }

    // Private constructor for EF Core
    private PassengerFlightReservation() { }

    public PassengerFlightReservation(
        string passengerId,
        string pnr,
        string flightNumber,
        DateTime departureTime,
        string origin,
        string destination)
    {
        Id = Guid.NewGuid().ToString();
        PassengerId = passengerId ?? throw new ArgumentNullException(nameof(passengerId));
        Pnr = pnr ?? throw new ArgumentNullException(nameof(pnr));
        FlightNumber = flightNumber ?? throw new ArgumentNullException(nameof(flightNumber));
        DepartureTime = departureTime;
        Origin = origin ?? throw new ArgumentNullException(nameof(origin));
        Destination = destination ?? throw new ArgumentNullException(nameof(destination));
        Status = CheckInStatus.NotCheckedIn;
        CreatedAt = DateTime.UtcNow;
    }

    public CheckInResult CheckIn()
    {
        if (!IsEligibleForCheckIn())
        {
            return CheckInResult.Failure("Passenger is not eligible for check-in");
        }

        Status = CheckInStatus.CheckedIn;
        CheckInTime = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
        
        return CheckInResult.Success();
    }

    public void CancelCheckIn()
    {
        if (Status == CheckInStatus.CheckedIn)
        {
            Status = CheckInStatus.NotCheckedIn;
            CheckInTime = null;
            UpdatedAt = DateTime.UtcNow;
        }
    }

    public void UpdateCheckInStatus(CheckInStatus newStatus)
    {
        if (newStatus == Status)
            return;

        if (!CanTransitionTo(newStatus))
            throw new InvalidOperationException($"Cannot transition from {Status} to {newStatus}");

        var previousStatus = Status;
        Status = newStatus;
        UpdatedAt = DateTime.UtcNow;

        // Raise domain event for check-in status changes
        if (newStatus == CheckInStatus.CheckedIn)
        {
            CheckInTime = DateTime.UtcNow;
            AddDomainEvent(new PassengerCheckedInEvent(
                PassengerId, 
                FlightNumber, 
                Pnr, 
                CheckInTime.Value,
                previousStatus,
                newStatus));
        }
    }

    public void AssignSeat(string seatNumber)
    {
        if (string.IsNullOrWhiteSpace(seatNumber))
            throw new ArgumentNullException(nameof(seatNumber));

        SeatNumber = seatNumber;
        UpdatedAt = DateTime.UtcNow;
    }

    private bool CanTransitionTo(CheckInStatus newStatus)
    {
        return Status switch
        {
            CheckInStatus.NotCheckedIn => newStatus is CheckInStatus.CheckedIn or CheckInStatus.Cancelled or CheckInStatus.NoShow,
            CheckInStatus.CheckedIn => newStatus is CheckInStatus.BoardingPassIssued or CheckInStatus.Cancelled,
            CheckInStatus.BoardingPassIssued => newStatus is CheckInStatus.Boarded or CheckInStatus.Cancelled,
            CheckInStatus.Boarded => false,
            CheckInStatus.NoShow => false,
            CheckInStatus.Cancelled => false,
            _ => false
        };
    }

    public bool IsEligibleForCheckIn()
    {
        return Status == CheckInStatus.NotCheckedIn &&
               DepartureTime > DateTime.UtcNow.AddMinutes(-30) &&
               DepartureTime <= DateTime.UtcNow.AddHours(24);
    }

    public bool CanIssueBoardingPass()
    {
        return Status == CheckInStatus.CheckedIn && !string.IsNullOrEmpty(SeatNumber);
    }
}
