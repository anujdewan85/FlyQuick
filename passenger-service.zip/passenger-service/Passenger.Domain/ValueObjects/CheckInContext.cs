using Passenger.Domain.Entities;

namespace Passenger.Domain.ValueObjects;

/// <summary>
/// Context object containing all data needed for check-in business rule evaluation
/// Uses domain entities instead of DTOs for proper layering
/// </summary>
public record CheckInContext
{
    public string PassengerId { get; init; }
    public string Pnr { get; init; }
    public string FlightNumber { get; init; }
    public DateTime FlightDate { get; init; }
    public DateTime FlightTime { get; init; }
    public DateTime CheckInTime { get; init; }
    public Entities.Passenger? Passenger { get; init; }
    public PassengerFlightReservation? Reservation { get; init; }
    public string? SeatPreference { get; init; }
    public bool HasSpecialServices { get; init; }

    public CheckInContext(
        string passengerId,
        string pnr,
        string flightNumber,
        DateTime flightDate,
        DateTime flightTime,
        DateTime checkInTime,
        Entities.Passenger? passenger = null,
        PassengerFlightReservation? reservation = null,
        string? seatPreference = null,
        bool hasSpecialServices = false)
    {
        PassengerId = passengerId;
        Pnr = pnr;
        FlightNumber = flightNumber;
        FlightDate = flightDate;
        FlightTime = flightTime;
        CheckInTime = checkInTime;
        Passenger = passenger;
        Reservation = reservation;
        SeatPreference = seatPreference;
        HasSpecialServices = hasSpecialServices;
    }

    /// <summary>
    /// Factory method to create context from basic parameters
    /// </summary>
    public static CheckInContext Create(
        string passengerId,
        string pnr,
        string flightNumber,
        DateTime flightDate,
        DateTime flightTime,
        DateTime? checkInTime = null)
    {
        return new CheckInContext(
            passengerId,
            pnr,
            flightNumber,
            flightDate,
            flightTime,
            checkInTime ?? DateTime.UtcNow);
    }

    /// <summary>
    /// Creates a new context with passenger information
    /// </summary>
    public CheckInContext WithPassenger(Entities.Passenger passenger)
        => this with { Passenger = passenger };

    /// <summary>
    /// Creates a new context with reservation information
    /// </summary>
    public CheckInContext WithReservation(PassengerFlightReservation reservation)
        => this with { Reservation = reservation };

    /// <summary>
    /// Creates a new context with special services flag
    /// </summary>
    public CheckInContext WithSpecialServices(bool hasSpecialServices)
        => this with { HasSpecialServices = hasSpecialServices };

    // Computed properties for business rule evaluation
    public TimeSpan TimeUntilDeparture => FlightTime - CheckInTime;
    
    public bool IsCheckInWindowOpen => TimeUntilDeparture.TotalHours is >= 1 and <= 48;
    
    public bool HasValidPassenger => Passenger != null && !string.IsNullOrEmpty(Passenger.PassportNumber);
    
    public bool HasValidReservation => Reservation != null && Reservation.Status != CheckInStatus.Cancelled;
    
    public string BookingReference => Reservation?.Pnr ?? Pnr;
    
    public bool IsEarlyCheckIn => TimeUntilDeparture.TotalHours > 24;
    
    public bool IsLateCheckIn => TimeUntilDeparture.TotalHours < 2;

    /// <summary>
    /// Gets passenger's full name if available
    /// </summary>
    public string? GetPassengerFullName()
        => Passenger != null ? $"{Passenger.FirstName} {Passenger.LastName}" : null;

    /// <summary>
    /// Checks if all required data is present for check-in
    /// </summary>
    public bool IsComplete()
        => HasValidPassenger && HasValidReservation && !string.IsNullOrEmpty(FlightNumber);
}
