using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Passenger.Application.Abstractions;
using Passenger.Domain.ValueObjects;
using Passenger.Application.DTOs;
using PassengerEntity = Passenger.Domain.Entities.Passenger;
using Passenger.Domain.Entities;

namespace Passenger.Application.Services;

/// <summary>
/// Domain service for check-in business logic validation
/// Integrates with existing API services and maintains business rules
/// </summary>
public class CheckInDomainService
{
    private readonly IAirlineSystemApiService _apiService;
    private readonly IPassengerRepository _passengerRepository;
    private readonly IFlightReservationRepository _reservationRepository;
    private readonly IMemoryCache _cache;
    private readonly IConfiguration _configuration;
    private readonly ILogger<CheckInDomainService> _logger;

    // Configuration-driven rule parameters
    private readonly int _minHoursBeforeFlight;
    private readonly int _maxHoursBeforeFlight;
    private readonly bool _requireDocumentValidation;
    private readonly bool _enableFlightStatusCheck;

    public CheckInDomainService(
        IAirlineSystemApiService apiService,
        IPassengerRepository passengerRepository,
        IFlightReservationRepository reservationRepository,
        IMemoryCache cache,
        IConfiguration configuration,
        ILogger<CheckInDomainService> logger)
    {
        _apiService = apiService ?? throw new ArgumentNullException(nameof(apiService));
        _passengerRepository = passengerRepository ?? throw new ArgumentNullException(nameof(passengerRepository));
        _reservationRepository = reservationRepository ?? throw new ArgumentNullException(nameof(reservationRepository));
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        // Load configuration-driven business rules
        _minHoursBeforeFlight = _configuration.GetValue<int>("BusinessRules:CheckIn:MinHoursBeforeFlight", 2);
        _maxHoursBeforeFlight = _configuration.GetValue<int>("BusinessRules:CheckIn:MaxHoursBeforeFlight", 24);
        _requireDocumentValidation = _configuration.GetValue<bool>("BusinessRules:CheckIn:RequireDocumentValidation", true);
        _enableFlightStatusCheck = _configuration.GetValue<bool>("BusinessRules:CheckIn:EnableFlightStatusCheck", true);
    }

    /// <summary>
    /// Validates all check-in business rules for the given context
    /// </summary>
    public async Task<ValidationResult> ValidateCheckInAsync(CheckInContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Starting check-in validation for passenger {PassengerId} on flight {FlightNumber}", 
                context.PassengerId, context.FlightNumber);

            var validationResults = new List<ValidationResult>();

            // 1. Check-in window validation (fast, in-memory)
            validationResults.Add(ValidateCheckInWindow(context));

            // 2. Document validation (fast, in-memory)
            if (_requireDocumentValidation)
            {
                validationResults.Add(ValidateDocuments(context));
            }

            // 3. Reservation validation (fast, in-memory)
            validationResults.Add(ValidateReservation(context));

            // 4. Flight status validation (cached external call)
            if (_enableFlightStatusCheck)
            {
                var flightStatusResult = await ValidateFlightStatusAsync(context, cancellationToken);
                validationResults.Add(flightStatusResult);
            }

            // 5. Special services validation (if applicable)
            if (context.HasSpecialServices)
            {
                var specialServicesResult = await ValidateSpecialServicesAsync(context, cancellationToken);
                validationResults.Add(specialServicesResult);
            }

            var combinedResult = ValidationResult.Combine(validationResults.ToArray());

            _logger.LogInformation("Check-in validation completed for passenger {PassengerId}. Valid: {IsValid}, Errors: {ErrorCount}", 
                context.PassengerId, combinedResult.IsValid, combinedResult.Errors.Count());

            return combinedResult;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during check-in validation for passenger {PassengerId}", context.PassengerId);
            return ValidationResult.Failure("An error occurred during check-in validation. Please try again.");
        }
    }

    /// <summary>
    /// Validates check-in timing window (ultra-fast, in-memory)
    /// </summary>
    private ValidationResult ValidateCheckInWindow(CheckInContext context)
    {
        var hoursUntilFlight = context.TimeUntilDeparture.TotalHours;

        if (hoursUntilFlight < _minHoursBeforeFlight)
        {
            return ValidationResult.Failure($"Check-in is closed. Check-in closes {_minHoursBeforeFlight} hours before departure.");
        }

        if (hoursUntilFlight > _maxHoursBeforeFlight)
        {
            return ValidationResult.Failure($"Check-in is not yet available. Check-in opens {_maxHoursBeforeFlight} hours before departure.");
        }

        var warnings = new List<string>();
        if (hoursUntilFlight < 4)
        {
            warnings.Add("Check-in is closing soon. Please complete check-in promptly.");
        }

        return ValidationResult.Success(warnings);
    }

    /// <summary>
    /// Validates passenger documents (fast, in-memory)
    /// </summary>
    private ValidationResult ValidateDocuments(CheckInContext context)
    {
        if (context.Passenger == null)
        {
            return ValidationResult.Failure("Passenger information not available for document validation.");
        }

        if (!context.HasValidPassenger)
        {
            return ValidationResult.Failure("Valid travel document is required for check-in.");
        }

        // Additional document validation rules can be added here
        var documentNumber = context.Passenger.PassportNumber;
        if (documentNumber != null && documentNumber.Length < 6)
        {
            return ValidationResult.Failure("Document number appears to be invalid.");
        }

        return ValidationResult.Success();
    }

    /// <summary>
    /// Validates flight reservation status (fast, in-memory)
    /// </summary>
    private ValidationResult ValidateReservation(CheckInContext context)
    {
        if (context.Reservation == null)
        {
            return ValidationResult.Failure("Flight reservation not found. Please verify your PNR.");
        }

        if (!context.HasValidReservation)
        {
            return ValidationResult.Failure("Reservation is not confirmed. Check-in not allowed.");
        }

        return ValidationResult.Success();
    }

    /// <summary>
    /// Validates flight status using cached external API calls
    /// </summary>
    private async Task<ValidationResult> ValidateFlightStatusAsync(CheckInContext context, CancellationToken cancellationToken)
    {
        try
        {
            var cacheKey = $"flight_status_{context.FlightNumber}_{context.FlightDate:yyyyMMdd}";

            if (!_cache.TryGetValue(cacheKey, out string? flightStatus))
            {
                _logger.LogDebug("Flight status cache miss for {FlightNumber}. Fetching from API.", context.FlightNumber);

                // Use existing API service to get flight information
                var reservation = await _apiService.GetFlightReservationByPnrAsync(context.Pnr, cancellationToken);
                flightStatus = reservation?.Status ?? "Unknown";

                // Cache for 5 minutes to avoid repeated API calls
                _cache.Set(cacheKey, flightStatus, TimeSpan.FromMinutes(5));
            }
            else
            {
                _logger.LogDebug("Flight status cache hit for {FlightNumber}: {Status}", context.FlightNumber, flightStatus);
            }

            return flightStatus?.ToLowerInvariant() switch
            {
                "cancelled" => ValidationResult.Failure("Flight has been cancelled. Check-in not available."),
                "delayed" => ValidationResult.Success(new[] { "Flight is delayed. Please check for updates." }),
                "ontime" or "confirmed" => ValidationResult.Success(),
                "unknown" => ValidationResult.Success(new[] { "Unable to verify flight status. Please check with airline." }),
                _ => ValidationResult.Success()
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unable to validate flight status for {FlightNumber}. Proceeding with check-in.", context.FlightNumber);
            return ValidationResult.Success(new[] { "Unable to verify flight status. Please check with airline staff." });
        }
    }

    /// <summary>
    /// Validates special services requirements
    /// </summary>
    private async Task<ValidationResult> ValidateSpecialServicesAsync(CheckInContext context, CancellationToken cancellationToken)
    {
        try
        {
            // This could be extended to check for wheelchair assistance, unaccompanied minors, etc.
            // For now, we'll use a simple placeholder

            await Task.Delay(1, cancellationToken); // Placeholder for async operation

            var warnings = new List<string>();
            
            if (context.HasSpecialServices)
            {
                warnings.Add("Special services requested. Please arrive at airport early and contact airline staff.");
            }

            return ValidationResult.Success(warnings);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unable to validate special services for passenger {PassengerId}.", context.PassengerId);
            return ValidationResult.Success(new[] { "Unable to verify special services. Please contact airline staff." });
        }
    }

    /// <summary>
    /// Pre-loads and caches data needed for check-in validation
    /// </summary>
    public async Task<CheckInContext> EnrichContextAsync(CheckInContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            // Load passenger and reservation data in parallel if not already available
            var tasks = new List<Task>();
            
            Task<PassengerEntity?> passengerTask = Task.FromResult(context.Passenger);
            Task<PassengerFlightReservation?> reservationTask = Task.FromResult(context.Reservation);

            if (context.Passenger == null)
            {
                passengerTask = _passengerRepository.GetByIdAsync(context.PassengerId, cancellationToken);
                tasks.Add(passengerTask);
            }

            if (context.Reservation == null)
            {
                reservationTask = _reservationRepository.GetByPnrAsync(context.Pnr, cancellationToken);
                tasks.Add(reservationTask);
            }

            if (tasks.Any())
            {
                await Task.WhenAll(tasks);
            }

            // Create enriched context
            return context with
            {
                Passenger = await passengerTask,
                Reservation = await reservationTask
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unable to fully enrich check-in context for passenger {PassengerId}. Proceeding with available data.", context.PassengerId);
            return context;
        }
    }
}
