using Passenger.Application.DTOs;

namespace Passenger.Application.Abstractions;

/// <summary>
/// Service interface for external airline system API operations
/// </summary>
public interface IAirlineSystemApiService
{
    // Query operations (GET calls)
    Task<PassengerDto?> GetPassengerAsync(string passengerId, CancellationToken cancellationToken = default);
    Task<IEnumerable<PassengerDto>> GetPassengersAsync(CancellationToken cancellationToken = default);
    Task<FlightReservationDto?> GetFlightReservationAsync(string reservationId, CancellationToken cancellationToken = default);
    Task<FlightReservationDto?> GetFlightReservationByPnrAsync(string pnr, CancellationToken cancellationToken = default);
    Task<CheckInStatusDto?> GetCheckInStatusAsync(string passengerId, string flightNumber, CancellationToken cancellationToken = default);
    
    // Command operations (POST/PUT calls)
    Task<PassengerDto> CreatePassengerAsync(CreatePassengerRequest request, CancellationToken cancellationToken = default);
    Task<FlightReservationDto> CreateFlightReservationAsync(CreateFlightReservationRequest request, CancellationToken cancellationToken = default);
    Task<FlightReservationDto> UpdateFlightReservationAsync(string reservationId, UpdateFlightReservationRequest request, CancellationToken cancellationToken = default);
    Task<CheckInResultDto> CheckInPassengerAsync(CheckInPassengerRequest request, CancellationToken cancellationToken = default);
    Task<PassengerDto> UpdatePassengerAsync(string passengerId, UpdatePassengerRequest request, CancellationToken cancellationToken = default);
}

// DTOs for API requests
public record CreatePassengerRequest(
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public record CreateFlightReservationRequest(
    string PassengerId,
    string FlightNumber,
    DateTime DepartureDate,
    string Origin,
    string Destination);

public record CheckInPassengerRequest(
    string PassengerId,
    string FlightNumber,
    string SeatPreference);

public record UpdatePassengerRequest(
    string FirstName,
    string LastName,
    string Email,
    string Phone);
