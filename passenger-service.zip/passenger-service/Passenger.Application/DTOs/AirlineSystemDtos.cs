namespace Passenger.Application.DTOs;

/// <summary>
/// DTOs for external airline system API responses
/// </summary>
public record PassengerDto(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public record FlightReservationDto(
    string ReservationId,
    string PassengerId,
    string FlightNumber,
    DateTime DepartureDate,
    string Origin,
    string Destination,
    string Status);

public record UpdateFlightReservationRequest(
    string? SeatNumber,
    DateTime? DepartureTime,
    string? Status);

public record CheckInStatusDto(
    string PassengerId,
    string FlightNumber,
    bool IsCheckedIn,
    string? SeatNumber,
    DateTime? CheckInTime);

public record CheckInResultDto(
    bool Success,
    string? SeatNumber,
    string? BoardingPass,
    string? ErrorMessage);
