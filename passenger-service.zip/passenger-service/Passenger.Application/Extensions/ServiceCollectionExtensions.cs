using MediatR;
using Microsoft.Extensions.DependencyInjection;
using FluentValidation;
using System.Reflection;
using Passenger.Application.Common.Behaviors;
using Passenger.Application.Services;

namespace Passenger.Application.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
        
        // Add FluentValidation
        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        
        // Add pipeline behaviors - Transient is correct (lightweight, stateless decorators)
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));

        // Domain Services - Should be Singleton (stateless, configuration-driven)
        // CheckInDomainService is stateless, uses injected options and services
        // It does not hold any instance state, so Singleton is appropriate
        // This allows it to be reused across requests without unnecessary instantiation
        // Benefits: Best performance, memory efficient, thread-safe
        // CheckInDomainService Should Be Singleton:
        // Stateless: Contains only business logic, no instance state
        // Configuration-driven: Uses injected options and services
        // Thread-safe: All operations are read-only or use thread-safe dependencies
        // Performance: expensive-to-create objects. Expensive business rule evaluation should be cached at instance level
        services.AddSingleton<CheckInDomainService>();
        
        return services;
    }
}
