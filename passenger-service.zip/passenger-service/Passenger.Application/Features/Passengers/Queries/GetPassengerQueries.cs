using MediatR;
using Passenger.Application.Abstractions;
using Passenger.Application.Common.Exceptions;

namespace Passenger.Application.Features.Passengers.Queries;

public record GetPassengerByPnrQuery(string Pnr, string LastName) : IRequest<PassengerDto>;
public record GetPassengerByIdQuery(string PassengerId) : IRequest<PassengerDto>;

public record PassengerDto(
    string PassengerId,
    string Pnr,
    string FirstName,
    string LastName,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);

public class GetPassengerByPnrQueryHandler : IRequestHandler<GetPassengerByPnrQuery, PassengerDto>
{
    private readonly IFlightReservationRepository _reservationRepository;

    public GetPassengerByPnrQueryHandler(IFlightReservationRepository reservationRepository)
    {
        _reservationRepository = reservationRepository;
    }

    public async Task<PassengerDto> Handle(GetPassengerByPnrQuery request, CancellationToken cancellationToken)
    {
        var reservation = await _reservationRepository.GetByPnrAndLastNameAsync(request.Pnr, request.LastName, cancellationToken);
        if (reservation == null)
        {
            throw new NotFoundException($"No reservation found for PNR {request.Pnr} and last name {request.LastName}");
        }

        return new PassengerDto(
            reservation.PassengerId,
            reservation.Pnr,
            reservation.Passenger?.FirstName ?? "N/A",
            reservation.Passenger?.LastName ?? "N/A",
            reservation.FlightNumber,
            reservation.DepartureTime,
            reservation.Origin,
            reservation.Destination,
            reservation.Status.ToString()
        );
    }
}

public class GetPassengerByIdQueryHandler : IRequestHandler<GetPassengerByIdQuery, PassengerDto>
{
    private readonly IPassengerRepository _passengerRepository;
    private readonly IFlightReservationRepository _reservationRepository;

    public GetPassengerByIdQueryHandler(
        IPassengerRepository passengerRepository,
        IFlightReservationRepository reservationRepository)
    {
        _passengerRepository = passengerRepository;
        _reservationRepository = reservationRepository;
    }

    public async Task<PassengerDto> Handle(GetPassengerByIdQuery request, CancellationToken cancellationToken)
    {
        var passenger = await _passengerRepository.GetByIdAsync(request.PassengerId, cancellationToken);
        if (passenger == null)
        {
            throw new NotFoundException($"Passenger with ID {request.PassengerId} not found");
        }

        // Get the most recent reservation for this passenger
        var reservations = await _reservationRepository.GetByPassengerIdAsync(request.PassengerId, cancellationToken);
        var latestReservation = reservations.OrderByDescending(r => r.DepartureTime).FirstOrDefault();

        if (latestReservation == null)
        {
            throw new NotFoundException($"No reservations found for passenger {request.PassengerId}");
        }

        return new PassengerDto(
            passenger.Id,
            latestReservation.Pnr,
            passenger.FirstName,
            passenger.LastName,
            latestReservation.FlightNumber,
            latestReservation.DepartureTime,
            latestReservation.Origin,
            latestReservation.Destination,
            latestReservation.Status.ToString()
        );
    }
}
