using MediatR;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.FlightReservations.Commands;

public record CreatePassengerFlightReservationCommand(
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination) : IRequest<CreatePassengerFlightReservationResult>;

public record CreatePassengerFlightReservationResult(
    string ReservationId,
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);

public class CreatePassengerFlightReservationCommandHandler(IFlightReservationRepository repository)
        : IRequestHandler<CreatePassengerFlightReservationCommand, CreatePassengerFlightReservationResult>
{
    private readonly IFlightReservationRepository _repository = repository;

    public async Task<CreatePassengerFlightReservationResult> Handle(
        CreatePassengerFlightReservationCommand request, 
        CancellationToken cancellationToken)
    {
        var reservation = new Domain.Entities.PassengerFlightReservation(
            request.PassengerId,
            request.Pnr,
            request.FlightNumber,
            request.DepartureTime,
            request.Origin,
            request.Destination);

        await _repository.AddAsync(reservation, cancellationToken);

        return new CreatePassengerFlightReservationResult(
            reservation.Id,
            reservation.PassengerId,
            reservation.Pnr,
            reservation.FlightNumber,
            reservation.DepartureTime,
            reservation.Origin,
            reservation.Destination,
            reservation.Status.ToString());
    }
}
