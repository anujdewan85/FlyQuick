using MediatR;
using Passenger.Application.Abstractions;
using Passenger.Application.DTOs;
using Microsoft.Extensions.Logging;

namespace Passenger.Application.Features.FlightReservations.Queries;

public record GetFlightReservationByPnrQuery(string Pnr) : IRequest<FlightReservationDto?>;

public class GetFlightReservationByPnrQueryHandler : IRequestHandler<GetFlightReservationByPnrQuery, FlightReservationDto?>
{
    private readonly IAirlineSystemApiService _airlineSystemApiService;
    private readonly ILogger<GetFlightReservationByPnrQueryHandler> _logger;

    public GetFlightReservationByPnrQueryHandler(
        IAirlineSystemApiService airlineSystemApiService,
        ILogger<GetFlightReservationByPnrQueryHandler> logger)
    {
        _airlineSystemApiService = airlineSystemApiService;
        _logger = logger;
    }

    public async Task<FlightReservationDto?> Handle(GetFlightReservationByPnrQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Retrieving flight reservation by PNR: {Pnr}", request.Pnr);

        try
        {
            // Call external airline system API to get reservation by PNR
            var reservation = await _airlineSystemApiService.GetFlightReservationByPnrAsync(request.Pnr, cancellationToken);
            
            if (reservation == null)
            {
                _logger.LogWarning("Flight reservation not found for PNR: {Pnr}", request.Pnr);
                return null;
            }

            _logger.LogInformation("Successfully retrieved flight reservation for PNR: {Pnr}", request.Pnr);
            return reservation;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve flight reservation for PNR: {Pnr}", request.Pnr);
            throw;
        }
    }
}
