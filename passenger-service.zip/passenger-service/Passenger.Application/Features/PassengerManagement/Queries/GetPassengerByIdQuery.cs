using MediatR;
using Passenger.Application.Abstractions;

namespace Passenger.Application.Features.PassengerManagement.Queries;

public record GetPassengerByIdQuery(string PassengerId) : IRequest<PassengerDto?>;

public record PassengerDto(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public class GetPassengerByIdQueryHandler : IRequestHandler<GetPassengerByIdQuery, PassengerDto?>
{
    private readonly IPassengerRepository _repository;

    public GetPassengerByIdQueryHandler(IPassengerRepository repository)
    {
        _repository = repository;
    }

    public async Task<PassengerDto?> Handle(GetPassengerByIdQuery request, CancellationToken cancellationToken)
    {
        var passenger = await _repository.GetByIdAsync(request.PassengerId, cancellationToken);
        
        if (passenger == null)
            return null;

        return new PassengerDto(
            passenger.Id,
            passenger.FirstName,
            passenger.LastName,
            passenger.Email,
            passenger.Phone,
            passenger.DateOfBirth,
            passenger.PassportNumber
        );
    }
}
