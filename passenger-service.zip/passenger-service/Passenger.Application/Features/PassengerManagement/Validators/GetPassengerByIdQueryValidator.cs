using FluentValidation;
using Passenger.Application.Features.PassengerManagement.Queries;

namespace Passenger.Application.Features.PassengerManagement.Validators;

public class GetPassengerByIdQueryValidator : AbstractValidator<GetPassengerByIdQuery>
{
    public GetPassengerByIdQueryValidator()
    {
        RuleFor(x => x.PassengerId)
            .NotEmpty()
            .WithMessage("Passenger ID is required")
            .MinimumLength(1)
            .WithMessage("Passenger ID cannot be empty");
    }
}
