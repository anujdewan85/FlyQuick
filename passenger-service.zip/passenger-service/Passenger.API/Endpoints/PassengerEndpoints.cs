using Carter;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Passenger.Application.Features.Passengers.Queries;
using Passenger.Application.Features.Passengers.Commands;

namespace Passenger.API.Endpoints;

public class PassengerEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/passengers")
            .WithTags("Passengers")
            .WithOpenApi();

        group.MapGet("/pnr/{pnr}", GetPassengerByPnr)
            .WithName("GetPassengerByPnr")
            .WithSummary("Get passenger by PNR")
            .Produces<PassengerResponse>(200)
            .Produces(404);
        //  .RequireAuthorization("PassengerRead");

        group.MapPut("/{pnr}/checkin-status", UpdateCheckinStatus)
            .WithName("UpdateCheckinStatus")
            .WithSummary("Update passenger check-in status")
            .Produces<PassengerResponse>(200);
        //  .RequireAuthorization("CheckInOperations");

        group.MapGet("/{passengerId}", GetPassengerById)
            .WithName("GetPassengerById")
            .WithSummary("Get passenger by ID")
            .Produces<PassengerResponse>(200);
           // .RequireAuthorization("PassengerRead");
    }

    private static async Task<IResult> GetPassengerByPnr(
        string pnr,
        [FromQuery] string lastName,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetPassengerByPnrQuery(pnr, lastName);
        var result = await mediator.Send(query, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> UpdateCheckinStatus(
        string pnr,
        [FromBody] UpdateStatusRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = new UpdateCheckinStatusCommand(pnr, request.Status);
        var result = await mediator.Send(command, cancellationToken);
        return Results.Ok(result);
    }

    private static async Task<IResult> GetPassengerById(
        string passengerId,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetPassengerByIdQuery(passengerId);
        var result = await mediator.Send(query, cancellationToken);
        return Results.Ok(result);
    }
}

public record UpdateStatusRequest(string Status);
public record PassengerResponse(
    string PassengerId,
    string Pnr,
    string FirstName,
    string LastName,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);
