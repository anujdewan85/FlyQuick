using Carter;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Passenger.Application.Features.PassengerManagement.Queries;
using Passenger.Application.Features.PassengerManagement.Commands;
using Passenger.API.DTOs;
using Mapster;

namespace Passenger.API.Endpoints;

public class PassengerManagementEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/passengers")
            .WithTags("Passenger Management")
            .WithOpenApi();

        group.MapPost("/", CreatePassenger)
            .WithName("CreatePassenger")
            .WithSummary("Create a new passenger profile")
            .Produces<CreatePassengerResponse>(201)
            .Produces(400);

        group.MapGet("/{passengerId}", GetPassengerById)
            .WithName("GetPassengerById")
            .WithSummary("Get passenger by ID")
            .Produces<GetPassengerByIdResponse>(200)
            .Produces(404);
    }

    private static async Task<IResult> CreatePassenger(
        [FromBody] CreatePassengerRequest request,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var command = request.Adapt<CreatePassengerCommand>();
        var result = await mediator.Send(command, cancellationToken);
        var response = result.Adapt<CreatePassengerResponse>();
        return Results.Created($"/api/passengers/{response.PassengerId}", response);
    }

    private static async Task<IResult> GetPassengerById(
        string passengerId,
        IMediator mediator,
        CancellationToken cancellationToken)
    {
        var query = new GetPassengerByIdQuery(passengerId);
        var result = await mediator.Send(query, cancellationToken);
        
        if (result == null)
            return Results.NotFound($"Passenger not found with ID: {passengerId}");
            
        var response = result.Adapt<GetPassengerByIdResponse>();
        return Results.Ok(response);
    }
}
