namespace Passenger.API.DTOs;

// ===== PASSENGER MANAGEMENT DTOs =====
// These DTOs handle person identity and profile management

public record CreatePassengerRequest(
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber = "");

public record CreatePassengerResponse(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public record GetPassengerByIdResponse(
    string PassengerId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    DateTime DateOfBirth,
    string PassportNumber);

public record UpdatePassengerContactRequest(
    string Email,
    string Phone);

public record UpdatePassengerContactResponse(
    string PassengerId,
    string Email,
    string Phone,
    DateTime UpdatedAt);
