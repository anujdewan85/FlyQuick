namespace Passenger.API.DTOs;

// ===== FLIGHT RESERVATION DTOs =====
// These DTOs handle flight booking and reservation management

public record CreateFlightReservationRequest(
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination);

public record UpdateFlightReservationRequest(
    string? SeatNumber,
    DateTime? DepartureTime,
    string? Status);

public record CreatePassengerFlightReservationResponse(
    string ReservationId,
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);

public record FlightReservationResponse(
    string ReservationId,
    string PassengerId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status,
    DateTime? CheckInTime);

public record GetReservationsByPassengerRequest(
    string PassengerId);

public record GetReservationsByPassengerResponse(
    string PassengerId,
    List<FlightReservationSummary> Reservations);

public record FlightReservationSummary(
    string ReservationId,
    string Pnr,
    string FlightNumber,
    DateTime DepartureTime,
    string Origin,
    string Destination,
    string Status);
