using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Passenger.Application.Abstractions;
using Passenger.Infrastructure.Extensions;
using Passenger.Infrastructure.Configuration;
using Passenger.Infrastructure.Services;
using Xunit;
using Xunit.Abstractions;

namespace Passenger.Infrastructure.Tests.Services;

/// <summary>
/// Integration tests demonstrating the Universal Airline System API Service
/// </summary>
public class UniversalAirlineSystemApiServiceTests
{
    private readonly ITestOutputHelper _output;

    public UniversalAirlineSystemApiServiceTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Fact]
    public void Should_Configure_Service_For_Navitaire_Provider()
    {
        // Arrange
        var configuration = CreateTestConfiguration("Navitaire");
        var services = new ServiceCollection();
        
        services.AddLogging(builder => builder.AddXUnit(_output));
        services.AddSingleton(configuration);
        services.AddInfrastructureServices(configuration);

        var serviceProvider = services.BuildServiceProvider();

        // Act
        var airlineService = serviceProvider.GetRequiredService<IAirlineSystemApiService>();
        var options = serviceProvider.GetRequiredService<IOptions<AirlineSystemOptions>>();

        // Assert
        Assert.NotNull(airlineService);
        Assert.IsType<UniversalAirlineSystemApiService>(airlineService);
        Assert.Equal("Navitaire", options.Value.Default);
        Assert.True(options.Value.Providers.ContainsKey("Navitaire"));
    }

    [Fact]
    public void Should_Configure_Service_For_Amadeus_Provider()
    {
        // Arrange
        var configuration = CreateTestConfiguration("Amadeus");
        var services = new ServiceCollection();
        
        services.AddLogging(builder => builder.AddXUnit(_output));
        services.AddSingleton(configuration);
        services.AddInfrastructureServices(configuration);

        var serviceProvider = services.BuildServiceProvider();

        // Act
        var airlineService = serviceProvider.GetRequiredService<IAirlineSystemApiService>();
        var options = serviceProvider.GetRequiredService<IOptions<AirlineSystemOptions>>();

        // Assert
        Assert.NotNull(airlineService);
        Assert.IsType<UniversalAirlineSystemApiService>(airlineService);
        Assert.Equal("Amadeus", options.Value.Default);
        Assert.True(options.Value.Providers.ContainsKey("Amadeus"));
    }

    [Fact]
    public void Should_Validate_Configuration_On_Startup()
    {
        // Arrange - Invalid configuration (missing default provider)
        var invalidConfig = CreateInvalidConfiguration();
        var services = new ServiceCollection();
        
        services.AddLogging(builder => builder.AddXUnit(_output));
        services.AddSingleton(invalidConfig);
        
        // Act & Assert
        var exception = Assert.Throws<InvalidOperationException>(() =>
        {
            services.AddInfrastructureServices(invalidConfig);
            var serviceProvider = services.BuildServiceProvider();
            
            // This should trigger validation and throw
            var options = serviceProvider.GetRequiredService<IOptions<AirlineSystemOptions>>();
            var value = options.Value; // This triggers validation
        });
        
        Assert.Contains("validation failed", exception.Message);
    }

    [Fact]
    public void Should_Switch_Providers_Based_On_Configuration()
    {
        // Arrange - Test configuration switching
        var navitaireConfig = CreateTestConfiguration("Navitaire");
        var amadeusConfig = CreateTestConfiguration("Amadeus");

        // Act & Assert - Both should work with the same service implementation
        Assert.Equal("Navitaire", navitaireConfig["AirlineSystemProviders:Default"]);
        Assert.Equal("Amadeus", amadeusConfig["AirlineSystemProviders:Default"]);
        
        // Verify endpoints are different
        var navitaireEndpoint = navitaireConfig["AirlineSystemProviders:Navitaire:Endpoints:GetPassenger"];
        var amadeusEndpoint = amadeusConfig["AirlineSystemProviders:Amadeus:Endpoints:GetPassenger"];
        
        Assert.Equal("/api/passengers/{passengerId}", navitaireEndpoint);
        Assert.Equal("/v1/travelers/{passengerId}", amadeusEndpoint);
    }

    private IConfiguration CreateTestConfiguration(string defaultProvider)
    {
        var configData = new Dictionary<string, string>
        {
            { $"{AirlineSystemOptions.SectionName}:Default", defaultProvider },
            
            // Navitaire configuration
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:BaseUrl", "https://api.navitaire.com" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:ApiKey", "test-navitaire-key" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:AuthType", "ApiKey" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:TimeoutSeconds", "30" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:Endpoints:GetPassenger", "/api/passengers/{passengerId}" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:Endpoints:GetPassengers", "/api/passengers" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:Endpoints:CreatePassenger", "/api/passengers" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:Headers:X-API-Key", "{ApiKey}" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:Headers:Accept", "application/json" },
            
            // Amadeus configuration
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:BaseUrl", "https://api.amadeus.com" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:ApiKey", "test-amadeus-token" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:AuthType", "Bearer" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:TimeoutSeconds", "30" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:Endpoints:GetPassenger", "/v1/travelers/{passengerId}" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:Endpoints:GetPassengers", "/v1/travelers" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:Endpoints:CreatePassenger", "/v1/travelers" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:Headers:Authorization", "Bearer {ApiKey}" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Amadeus:Headers:Accept", "application/json" },
        };

        return new ConfigurationBuilder()
            .AddInMemoryCollection(configData!)
            .Build();
    }
    
    private IConfiguration CreateInvalidConfiguration()
    {
        var configData = new Dictionary<string, string>
        {
            // Missing Default provider and invalid configuration
            { $"{AirlineSystemOptions.SectionName}:Default", "NonExistentProvider" },
            { $"{AirlineSystemOptions.SectionName}:Providers:Navitaire:BaseUrl", "" }, // Invalid empty URL
        };

        return new ConfigurationBuilder()
            .AddInMemoryCollection(configData!)
            .Build();
    }
}
