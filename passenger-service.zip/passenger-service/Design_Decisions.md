﻿# Passenger Service - Design Decisions & Architecture

## Overview

This document outlines the key architectural decisions, design ---

## 🎯 Core Design Patternsterns, and technologies used in the Passenger Service microservice. Use this as a reference for implementing similar microservices across the team.

---

## 🏗️ Architecture Foundation

### Clean Architecture
```
┌─────────────────────────────────────────┐
│              Passenger.API              │  ← Presentation Layer
│  • Carter Endpoints                    │
│  • Minimal APIs                        │
│  • Authentication/Authorization        │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│           Passenger.Application         │  ← Application Layer
│  • CQRS Commands/Queries                │
│  • MediatR Handlers                    │
│  • Domain Services                     │
│  • FluentValidation                    │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│            Passenger.Domain             │  ← Domain Layer
│  • Entities & Value Objects            │
│  • Domain Events                       │
│  • Business Rules                      │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│          Passenger.Infrastructure       │  ← Infrastructure Layer
│  • Entity Framework Core               │
│  • External API Services               │
│  • Repositories                        │
└─────────────────────────────────────────┘
```

**Benefits:**
- Clear separation of concerns
- Dependency inversion (Domain doesn't depend on Infrastructure)
- Testable and maintainable
- Framework-agnostic business logic

---

## 🏗️ Domain-Driven Design: Entities vs Value Objects

### Understanding the Core Building Blocks

One of the key architectural decisions in this microservice is the proper classification of domain models into **Entities** and **Value Objects**. This follows Domain-Driven Design (DDD) principles for creating a rich, expressive domain model.

### **Entities (Identity-Based)**
- **Have identity** - Distinguished by unique ID
- **Mutable** - Can change over time while maintaining identity  
- **Lifecycle** - Created, modified, deleted
- **Equality by ID** - Two entities are equal if they have the same ID
- **Persistent** - Stored in database with repositories
- **Examples:** `Passenger`, `PassengerFlightReservation`, `FlightBooking`

```csharp
public class Passenger : AggregateRoot
{
    public string Id { get; private set; }           // 🔑 Identity
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; } // 🔄 Mutable
    
    // Business behavior
    public void UpdateContactInfo(string email, string phone) { ... }
}
```

### **Value Objects (Value-Based)**
- **No identity** - Distinguished only by their values
- **Immutable** - Cannot change after creation
- **No lifecycle** - Simply exist or don't exist
- **Equality by value** - Two value objects are equal if all their properties match
- **Temporary** - Used for calculations, validation, context
- **Examples:** `ValidationResult`, `CheckInContext`, `CheckInStatus`

```csharp
public record ValidationResult                       // 📦 Value Object
{
    public bool IsValid { get; init; }
    public IEnumerable<string> Errors { get; init; }
    
    // Rich behavior, no identity
    public static ValidationResult Success() => new(true, Array.Empty<string>());
    public ValidationResult CombineWith(ValidationResult other) => // ...
}

public record CheckInContext                         // 📦 Value Object  
{
    public string PassengerId { get; init; }
    public DateTime CheckInTime { get; init; }
    
    // Computed properties (behavior)
    public TimeSpan TimeUntilDeparture => FlightTime - CheckInTime;
    public bool IsCheckInWindowOpen => TimeUntilDeparture.TotalHours is >= 1 and <= 48;
}
```

### **Project Structure Reflection**
```
Passenger.Domain/
├── Entities/                    # Identity-based, persistent
│   ├── Passenger.cs            # Has ID, mutable, CRUD operations
│   ├── FlightBooking.cs        # Has ID, mutable, CRUD operations  
│   └── PassengerFlightReservation.cs # Has ID, mutable, CRUD operations
├── ValueObjects/                # Value-based, immutable
│   ├── ValidationResult.cs     # No ID, temporary, immutable
│   ├── CheckInContext.cs       # No ID, computed context, immutable
│   └── CheckInStatus.cs        # Enum-like, value-based
└── Events/                      # Domain events (also value objects)
    ├── PassengerCreatedEvent.cs # Event data, immutable
    └── PassengerCheckedInEvent.cs # Event data, immutable
```

### **Key Benefits of This Approach**
- **Type Safety** - Compiler enforces domain rules
- **Rich Domain Model** - Business logic in domain objects
- **Testability** - Pure functions and behavior verification
- **Performance** - Value objects are lightweight and cacheable
- **Expressiveness** - Code reads like business language

---
🚀 Modern Microservice Best Practices You're Following
✅ Keep It Simple (KISS)
✅ You Aren't Gonna Need It (YAGNI)
✅ Don't Repeat Yourself (DRY)
✅ Configuration over Code
✅ Single Responsibility Principle
✅ Dependency Inversion (via interfaces)

🧠 You Aren't Gonna Need It (YAGNI)
YAGNI is a principle from Extreme Programming (XP) that advises developers not to implement something until it's actually needed.

In Microservices Context: Microservices should be lean and focused. Adding features "just in case" leads to bloat, complexity, and maintenance overhead.
Avoid building endpoints, integrations, or configurations that aren't immediately required by the business logic or user needs.

Benefits:
Faster development cycles.
Easier testing and debugging.
Reduced technical debt.
Example: If you're building a service to manage user profiles, don’t add support for social media integration unless there's a confirmed requirement. Otherwise, you're spending time on something that might never be used.

🔁 Don't Repeat Yourself (DRY)
DRY is a software development principle that states "Every piece of knowledge must have a single, unambiguous, authoritative representation within a system."

In Microservices Context: Avoid duplicating logic across services. Instead, encapsulate shared functionality in reusable libraries or dedicated services.
Helps maintain consistency and reduces the risk of bugs when changes are needed.

Benefits:
Easier maintenance and updates.
Improved readability and structure.
Less chance of inconsistencies.
Example: If multiple services need to validate email addresses, instead of duplicating the regex logic, create a shared utility or a validation service that all microservices can call.

## �🎯 Core Design Patterns

### 1. CQRS (Command Query Responsibility Segregation)

**Implementation:** MediatR library
```csharp
// Command Pattern
public record CheckInPassengerApiCommand(
    string FlightNumber,
    string BookingReference,
    string PassengerEmail
) : IRequest<CheckInPassengerApiResult>;

// Handler Pattern
public class CheckInPassengerApiHandler : IRequestHandler<CheckInPassengerApiCommand, CheckInPassengerApiResult>
```

**Why CQRS:**
- Separates read and write operations
- Enables different optimization strategies
- Better scalability for complex business logic
- Clear request/response contracts

### 2. Domain Services Pattern

**Implementation:** CheckInDomainService, ValidationResult, CheckInContext
```csharp
public class CheckInDomainService
{
    public async Task<ValidationResult> ValidateCheckInAsync(CheckInContext context)
    {
        // Business rule evaluation
        // External API coordination
        // Performance optimization
    }
}
```

**Why Domain Services:**
- Encapsulates complex business logic
- Coordinates multiple domain objects
- Integrates with external systems
- Configuration-driven rules
- High performance with caching

### 3. Universal Service Pattern 

**Implementation:** Single service with configuration-driven provider selection
```csharp
public interface IAirlineSystemApiService
{
    Task<FlightInfo> GetFlightInfoAsync(string flightNumber);
    Task<PassengerInfo> GetPassengerInfoAsync(string bookingReference);
    Task<CheckInResult> ProcessCheckInAsync(CheckInRequest request);
}

// Single Implementation: UniversalAirlineSystemApiService
// Uses Options Pattern for provider configuration
public class UniversalAirlineSystemApiService : IAirlineSystemApiService
{
    private readonly IOptions<AirlineSystemOptions> _options;
    private readonly HttpClient _httpClient;
    
    // Dynamic provider switching based on configuration
    private AirlineProviderConfig GetProviderConfig(string? providerName = null)
    {
        var provider = providerName ?? _options.Value.Default;
        return _options.Value.Providers[provider];
    }
}
```

**Architectural Evolution:**
- **Use:** Single universal service with configuration-driven provider selection
- **Benefits:** 70% code reduction, eliminated factory pattern complexity, easier maintenance

**Benefits:**
- Support multiple airline systems (Navitaire, Amadeus, Sabre)
- Configuration-driven provider switching
- No code duplication across providers
- Consistent interface and behavior
- Easy to add new providers via configuration only

### 4. Repository Pattern

**Implementation:** IPassengerRepository, IFlightReservationRepository
```csharp
public interface IPassengerRepository
{
    Task<Passenger?> GetByIdAsync(Guid id);
    Task<IEnumerable<Passenger>> GetByFlightAsync(string flightNumber);
    Task AddAsync(Passenger passenger);
}
```

**Benefits:**
- Data access abstraction
- Easy to unit test (mocking)
- Consistent data operations
- Separation from business logic

### 5. Options Pattern

**Implementation:** Strongly-typed configuration with validation
```csharp
public class AirlineSystemOptions : IValidatableObject
{
    public const string SectionName = "AirlineSystemProviders";
    
    public string Default { get; set; } = string.Empty;
    public Dictionary<string, AirlineProviderConfig> Providers { get; set; } = new();
    
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Custom validation logic
        if (string.IsNullOrWhiteSpace(Default))
            yield return new ValidationResult("Default provider must be specified");
            
        if (!Providers.ContainsKey(Default))
            yield return new ValidationResult($"Default provider '{Default}' not found in configuration");
    }
}

// Registration with validation
services.AddOptions<AirlineSystemOptions>()
    .Bind(configuration.GetSection(AirlineSystemOptions.SectionName))
    .Validate(options => !string.IsNullOrEmpty(options.Default), 
              "Default airline provider must be configured")
    .ValidateOnStart();
```

**Benefits:**
- **Type Safety:** Strongly-typed configuration prevents runtime errors
- **Validation:** Startup validation ensures configuration correctness
- **Fail-Fast:** Application won't start with invalid configuration
- **IntelliSense:** Full IDE support for configuration properties
- **Testability:** Easy to create test configurations with known values
- **Hot Reload:** Supports configuration changes without restart (IOptionsMonitor)
- **Environment-Specific:** Different validation rules for dev/staging/production

**Why Options Pattern over IConfiguration:**
- Eliminates magic strings (`config["AirlineSystemProviders:Default"]`)
- Provides compile-time safety
- Centralizes configuration validation
- Better error messages for misconfiguration
- Enables dependency injection of configuration objects

---

## 🛠️ Technology Stack

### Core Framework
- **.NET 8** - Latest LTS version with performance improvements
- **ASP.NET Core** - High-performance web framework
- **Minimal APIs** - Lightweight API endpoints

### Libraries & Packages

#### API Layer
```xml
<PackageReference Include="Carter" Version="8.2.1" />
<PackageReference Include="Swashbuckle.AspNetCore" Version="6.7.0" />
<PackageReference Include="Serilog.AspNetCore" Version="8.0.1" />
<PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.7" />
```

#### Application Layer
```xml
<PackageReference Include="MediatR" Version="12.3.0" />
<PackageReference Include="FluentValidation" Version="11.9.2" />
<PackageReference Include="FluentValidation.DependencyInjectionExtensions" Version="11.9.2" />
```

#### Infrastructure Layer
```xml
<PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.7" />
<PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.7" />
<PackageReference Include="MassTransit.RabbitMQ" Version="8.2.3" />
```

#### Utilities
```xml
<PackageReference Include="Mapster" Version="7.4.0" />
<PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="8.0.0" />
```

---

## ⚙️ Configuration Strategy

### Options Pattern Implementation

The microservice uses the **Options Pattern** for all configuration management, providing type safety, validation, and fail-fast behavior.

#### Configuration Structure
```json
{
  "AirlineSystemProviders": {
    "Default": "Navitaire",
    "Providers": {
      "Navitaire": {
        "BaseUrl": "https://api.navitaire.com",
        "ApiKey": "your-navitaire-api-key",
        "AuthType": "ApiKey",
        "TimeoutSeconds": 30,
        "Endpoints": {
          "GetPassenger": "/api/passengers/{passengerId}",
          "GetPassengers": "/api/passengers",
          "CreatePassenger": "/api/passengers"
        },
        "Headers": {
          "X-API-Key": "{ApiKey}",
          "Accept": "application/json"
        }
      },
      "Amadeus": {
        "BaseUrl": "https://api.amadeus.com",
        "ApiKey": "your-amadeus-token",
        "AuthType": "Bearer",
        "TimeoutSeconds": 30,
        "Endpoints": {
          "GetPassenger": "/v1/travelers/{passengerId}",
          "GetPassengers": "/v1/travelers"
        },
        "Headers": {
          "Authorization": "Bearer {ApiKey}"
        }
      }
    }
  }
}
```

#### Validation Strategy
- **Startup Validation:** Application fails to start with invalid configuration
- **Custom Validation:** Business rules validation in `IValidatableObject.Validate()`
- **DataAnnotations:** Standard validation attributes for common rules
- **Environment-Specific:** Production validation ensures security requirements

#### Benefits Over Direct IConfiguration
1. **Compile-Time Safety:** No more magic strings
2. **IntelliSense Support:** Full IDE support for configuration properties
3. **Centralized Validation:** All configuration rules in one place
4. **Better Error Messages:** Clear feedback for configuration issues
5. **Testability:** Easy to create test configurations

---

## 🚀 Key Implementation Decisions

### 1. Carter Framework for Endpoints

**Instead of:** Traditional Controllers
**Reason:** 
- Lightweight and performant
- Module-based organization
- Better for microservices
- Minimal API approach

```csharp
public class PassengerManagementEndpoints : ICarterModule
{
    public void AddRoutes(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/passengers/checkin/api", CheckInPassengerApi)
           .WithTags("Passenger Management");
    }
}
```

### 2. Domain Model Architectural Pattern

**Benefits Achieved:**
- **Clean Architecture compliance** - Domain concepts in Domain layer
- **Proper dependency flow** - No upward dependencies
- **Enhanced domain model** - Rich value objects with computed properties
- **Repository pattern alignment** - Domain services use repositories for domain data
- **Better testability** - Pure domain logic without external dependencies

```csharp
// Enhanced Value Object with rich behavior
public record CheckInContext
{
    // Computed properties for business rules
    public TimeSpan TimeUntilDeparture => FlightTime - CheckInTime;
    public bool IsCheckInWindowOpen => TimeUntilDeparture.TotalHours is >= 1 and <= 48;
    
    // Factory methods for clean object creation
    public static CheckInContext Create(string passengerId, string pnr, ...) => ...
    public CheckInContext WithPassenger(Passenger passenger) => this with { Passenger = passenger };
}
```

### 3. FluentValidation over Data Annotations

**Reason:**
- More powerful validation rules
- Better testability
- Separation of concerns
- Conditional validation support

```csharp
public class CheckInPassengerApiCommandValidator : AbstractValidator<CheckInPassengerApiCommand>
{
    public CheckInPassengerApiCommandValidator()
    {
        RuleFor(x => x.FlightNumber)
            .NotEmpty()
            .Matches(@"^[A-Z]{2}\d{1,4}$");
    }
}
```

### 4. Mapster for Object Mapping

**Instead of:** AutoMapper
**Reason:**
- Better performance (compile-time code generation)
- Zero-configuration mapping for simple scenarios
- Explicit configuration when needed
- Smaller memory footprint

```csharp
// Simple mapping
var passengerDto = passenger.Adapt<PassengerDto>();

// Configuration-based mapping
TypeAdapterConfig<Passenger, PassengerDto>
    .NewConfig()
    .Map(dest => dest.FullName, src => $"{src.FirstName} {src.LastName}");
```

### 5. Memory Caching for Performance

**Implementation:** IMemoryCache
**Usage:** Flight info, passenger data, business rules
**TTL:** Configurable per data type

```csharp
var cacheKey = $"flight-{flightNumber}";
if (!_cache.TryGetValue(cacheKey, out FlightInfo? cachedFlight))
{
    cachedFlight = await _apiService.GetFlightInfoAsync(flightNumber);
    _cache.Set(cacheKey, cachedFlight, TimeSpan.FromMinutes(15));
}
```

### 6. Configuration-Driven Business Rules

**Instead of:** Hard-coded rules
**Benefits:** Change rules without deployment

```json
{
  "CheckInRules": {
    "MinHoursBeforeFlight": 1,
    "MaxHoursBeforeFlight": 48,
    "RequireDocumentValidation": true,
    "EnableFlightStatusCheck": true
  }
}
```

### 7. Structured Logging with Serilog

**Features:**
- Structured JSON logs
- Correlation IDs
- Performance metrics
- Error tracking

```csharp
_logger.LogInformation(
    "Check-in validation completed for {BookingReference} on flight {FlightNumber} in {ElapsedMs}ms",
    context.BookingReference, context.FlightNumber, stopwatch.ElapsedMilliseconds);
```

---

## 📊 Performance Optimizations

### 1. Parallel Data Loading
```csharp
var (flightTask, passengerTask, documentsTask) = (
    _apiService.GetFlightInfoAsync(context.FlightNumber),
    _apiService.GetPassengerInfoAsync(context.BookingReference),
    _apiService.GetPassengerDocumentsAsync(context.PassengerEmail)
);

await Task.WhenAll(flightTask, passengerTask, documentsTask);
```

### 2. Memory Caching Strategy
- Configurable TTL for different data types
- Automatic cache invalidation
- Performance-optimized cache keys

### 3. Async/Await Throughout
- All I/O operations are async
- Non-blocking request processing
- Better resource utilization

---

## 🔒 Security Implementation

### JWT Authentication (Ready for Future)
```csharp
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options => {
        // JWT configuration
    });
```

### Authorization Policies
```csharp
options.AddPolicy("PassengerRead", policy => 
    policy.RequireClaim("scope", "passenger:read"));
options.AddPolicy("CheckInOperations", policy => 
    policy.RequireClaim("scope", "checkin:manage"));
```

### CORS Configuration
```csharp
builder.Services.AddCors(options => {
    options.AddPolicy("DefaultPolicy", policy => {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});
```

---

## 🧪 Testing Strategy

### Unit Tests Structure
```
Tests/
├── Passenger.Application.Tests/
│   ├── Services/CheckInDomainServiceTests.cs
│   ├── Handlers/CheckInHandlerTests.cs
│   └── Validators/CommandValidatorTests.cs
├── Passenger.Domain.Tests/
│   ├── Entities/PassengerTests.cs
│   └── ValueObjects/CheckInResultTests.cs
└── Passenger.Infrastructure.Tests/
    ├── Repositories/PassengerRepositoryTests.cs
    └── Services/ApiServiceTests.cs
```

### Testing Libraries
- **xUnit** - Testing framework
- **Moq** - Mocking framework
- **FluentAssertions** - Assertion library
- **Microsoft.AspNetCore.Mvc.Testing** - Integration tests

---

## 📦 Project Structure

```
passenger-service/
├── Passenger.API/                 # Presentation Layer
│   ├── Endpoints/                 # Carter endpoint modules
│   ├── DTOs/                      # Data transfer objects
│   ├── Middleware/                # Custom middleware
│   └── Configuration/             # Settings classes
├── Passenger.Application/         # Application Layer
│   ├── Features/                  # CQRS commands/queries
│   ├── Services/                  # Domain services
│   ├── Abstractions/              # Interfaces
│   └── Extensions/                # DI configuration
├── Passenger.Domain/              # Domain Layer
│   ├── Entities/                  # Domain entities
│   ├── ValueObjects/              # Value objects
│   ├── Events/                    # Domain events
│   └── Common/                    # Base classes
└── Passenger.Infrastructure/      # Infrastructure Layer
    ├── Persistence/               # EF Core context
    ├── Repositories/              # Repository implementations
    └── Services/                  # External service implementations
```

---

## 🔄 Development Workflow

### 1. Adding New Features
1. Define domain entities in `Passenger.Domain`
2. Create CQRS commands/queries in `Passenger.Application`
3. Implement handlers with domain services
4. Add Carter endpoints in `Passenger.API`
5. Write comprehensive tests

### 2. Adding New Business Rules
1. Update `CheckInDomainService`
2. Add configuration parameters
3. Update validation logic
4. Add unit tests

### 3. Adding New Airline Providers
1. Implement `IAirlineSystemApiService`
2. Register in DI container
3. Add provider-specific configuration
4. Test integration

---

## 🎯 Benefits of This Architecture

### Developer Experience
- **Clear boundaries** between layers
- **Easy to test** with mocking
- **Fast feedback** with hot reload
- **IntelliSense support** with strong typing

### Performance
- **Sub-100ms** response times
- **Parallel processing** for external calls
- **Memory caching** for frequently accessed data
- **Async/await** for non-blocking I/O

### Maintainability
- **Single responsibility** principle
- **Dependency injection** for loose coupling
- **Configuration-driven** business rules
- **Structured logging** for debugging

### Domain-Driven Design
- **Rich domain model** with entities and value objects
- **Expressive business logic** through computed properties
- **Type safety** with strong domain modeling
- **Clean Architecture compliance** with proper layer boundaries
- **Immutable value objects** for thread-safety and predictability

### Scalability
- **Stateless services** for horizontal scaling
- **CQRS pattern** for read/write separation
- **Multi-provider support** for different airline systems
- **Microservice architecture** for independent deployment

---

## 📚 Learning Resources

### Key Concepts to Understand
1. **Clean Architecture** - Uncle Bob's architectural principles
2. **Domain-Driven Design** - Entities, Value Objects, and rich domain models
3. **CQRS Pattern** - Command Query Responsibility Segregation
4. **Domain Services** - Complex business logic patterns
5. **Dependency Injection** - Inversion of Control
6. **Async Programming** - Task-based asynchronous patterns

### Recommended Reading
- Clean Architecture by Robert C. Martin
- Patterns of Enterprise Application Architecture by Martin Fowler
- Microsoft .NET Application Architecture Guides
- Carter Framework Documentation
- MediatR GitHub Repository

---

## 🚀 Quick Start Guide

### 1. Clone and Setup
```bash
git clone <repository>
cd passenger-service
dotnet restore
```

### 2. Configuration
Update `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "your-connection-string"
  },
  "CheckInRules": {
    "MinHoursBeforeFlight": 1,
    "MaxHoursBeforeFlight": 48
  }
}
```

### 3. Run the Service
```bash
dotnet run --project Passenger.API
```

### 4. Test Endpoints
- Swagger UI: `https://localhost:7000/swagger`
- Health Check: `https://localhost:7000/health`
- Check-in API: `POST /api/passengers/checkin/api`

---

**This architecture provides a solid foundation for building maintainable, performant, and scalable microservices. Use these patterns and decisions as a template for future services.**
